# India Food Commodity Insights Monitor

A Streamlit dashboard that tracks Indian food-commodity prices from mandi to all-India level, flags abnormal moves
(> 5% week-on-week, > 10% month-on-month), links them to regional news, policy and international developments, and
produces downloadable weekly and monthly insight reports (PDF, Word, Excel). No paid AI service is used.

## What is in the box

| Path | Purpose |
|---|---|
| `app.py`, `views/` | The nine pages (Overview with Major Insights of the Day, Price Alerts, Commodity Explorer, State & District Explorer, India News Map, Local Market News, Policy & International, Weekly & Monthly Insights, Data Sources & Uploads) |
| `fci/analytics.py` | Complete-period comparisons, matched-market aggregation, alerts, confidence labels, state pressure score |
| `fci/daily.py` | 'Major Insights of the Day' (up to five rule-based points shown at the top of the Overview) |
| `fci/signals.py` | Rules-based early-warning score (Normal / Watch / Elevated / Significant) |
| `fci/reports.py` | Rule-based narrative reports → PDF / DOCX / XLSX |
| `fci/sources/` | Adapters: `doca.py` (DoCA daily all-India), `datagov.py` (AGMARKNET via data.gov.in), `uploads.py` (auto-detecting file import), `news.py` (RSS news, policy, international), `sample.py` (clearly-marked sample mandi data) |
| `fci/store.py`, `fci/persist.py` | File store in `data/` and optional commit-back to GitHub |
| `scripts/` | `ingest_folder.py` (load a folder of files), `refresh.py` (scheduled refresh / back-fill) |
| `data/` | `doca_national.csv.gz` (real DoCA data), `mandi/` (real mandi data, monthly files), `sample_mandi.csv.gz`, `geo/` (state and district boundaries), `refresh_log.csv` |
| `tests/` | 48 tests: price maths, dates, thresholds, aggregation, uploads, news parsing, signals, reports, every page |

## Data currently loaded

- **Real:** DoCA all-India daily retail and wholesale averages, 25 Mar 2025 – 14 Nov 2026 (42 commodities).
- **Real:** NECC egg prices for 34 centres, 1–15 Nov 2026 (Rs per 100 eggs).
- **Not yet loaded:** AGMARKNET mandi prices. Until the data.gov.in key is added, the state/district views cover
  eggs only. `data/sample_mandi.csv.gz` (clearly-marked sample rows) is used only when `data/mandi/` is empty.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
pytest -q            # optional (pip install pytest)
```

## Deploy (GitHub + Streamlit Community Cloud)

1. Create a GitHub repository and upload the contents of this folder (keep the folder structure, including `.github`
   and `.streamlit`). A public repo is fine: it contains no keys.
2. Go to https://share.streamlit.io → **Create app** → pick the repo, branch `main`, main file `app.py` → **Deploy**.
3. In the app's **Settings → Secrets** paste (see `.streamlit/secrets.toml.example`):
   ```toml
   DATA_GOV_API_KEY = "..."      # free key from data.gov.in → My Account
   GITHUB_REPO = "you/your-repo" # optional, makes in-app uploads permanent
   GITHUB_TOKEN = "..."          # optional, fine-grained token, Contents: read/write on this repo only
   ```
4. In GitHub: **Settings → Secrets and variables → Actions → New repository secret** `DATA_GOV_API_KEY` (same key),
   then **Actions → Daily data refresh → Run workflow** once to test. It then runs daily at 19:00 IST, saves new mandi
   prices and a news snapshot into `data/`, commits them, and Streamlit redeploys automatically.

## Keeping data up to date

| Data | How |
|---|---|
| Mandi prices (AGMARKNET) | Automatic via the GitHub Action; or *Data Sources → Fetch latest daily mandi prices now*; history: `python scripts/refresh.py --backfill 2021-01-01 2021-01-31` (run month by month, then commit `data/mandi/`) |
| DoCA daily all-India | Scraped automatically each day from https://fcainfoweb.nic.in/Reports/DB/Dailyprices.aspx by the GitHub Action (each page also carries the previous 5 days, so a missed day is recovered). Manual: *Data Sources → Fetch DoCA all-India daily prices*, upload saved workbooks, or `python scripts/ingest_folder.py <folder>` |
| NECC egg prices | Scraped automatically each day from https://www.e2necc.com/home/eggprice (the page shows the whole current month, so missed days are recovered within the month). Manual: *Data Sources → Fetch NECC egg prices* |
| AGMARKNET monthly, e-NAM, state boards | Download from the portal and upload; columns are detected automatically |
| News / policy / international | Fetched live (cached one hour); the Action also stores a snapshot as fallback and appends each day to `data/news_archive.csv.gz`, which is what lets the India News Map slider go back beyond the live feed window |

Storage: the Git repository is the durable store. Streamlit Cloud's own disk is temporary, so an upload made in the
hosted app survives restarts only if `GITHUB_REPO`/`GITHUB_TOKEN` are set (it is then committed) or you add the file
to the repo yourself.

## Method notes

- Weeks are Monday–Sunday, months are calendar months; only complete periods are compared unless the *provisional*
  toggle is on. Weekly figures always come from daily observations, never from monthly averages.
- Mandi price = mean of daily modal prices. Comparisons use matched series only (same market, commodity, variety,
  grade, market type, unit, source in both periods).
- District / state / all-India: arrival-weighted mean when ≥ 80% of series report arrivals in both periods, otherwise
  unweighted mean; market counts are always shown. These averages are not an official price index.
- Confidence: mandi High = 3+ reporting days in both periods; district/state High = 5+ matched markets,
  Medium = 2–4, Low = 1; *Concentrated* = average crossed the threshold but the median market did not;
  *Check data* = change beyond ±60% (excluded from aggregates).
- State pressure score = priority-weighted share of a state's matched series rising above the threshold.
- News tags, evidence labels, policy mechanisms and international links are keyword rules applied to headlines; they
  are interpretations and are labelled as such. Article pages are not scraped.

## Troubleshooting

| Symptom | Check |
|---|---|
| Geographic pages say SAMPLE | No file in `data/mandi/`. Add the API key and run the Action, or upload AGMARKNET files |
| "data.gov.in request failed" | Key missing/invalid, daily quota reached, or the portal is down. See *Data Sources → Refresh log*. If the field names of the resource have changed, adjust `records_to_frame` in `fci/sources/datagov.py` |
| News pages empty | Feed failures are listed in an expander on the news pages; the stored snapshot is used when live feeds fail |
| A commodity is missing or mis-grouped | *Data Sources → Commodity priorities, exclusions and additions* |
| Upload not recognised | The file needs commodity, date and a price column; the detection table on the upload panel shows what was found |
| DoCA or NECC scrape shows FAILED in the refresh log | The parsers were written against the pages as served on 15 Nov 2026 and tested on copies of that structure, but the requests themselves have only been made from a browser in India. If the sites refuse GitHub's servers (some government sites block foreign addresses), run `python scripts/refresh.py` on your own computer and commit `data/`, or use the fetch buttons in the hosted app |
| Not yet verified | The data.gov.in adapter and live RSS fetching could not be exercised from the build environment (no access to those hosts); both are covered by offline tests and fail visibly, not silently |
