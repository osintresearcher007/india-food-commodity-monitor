"""Load every price file in a folder into the store.

    python scripts/ingest_folder.py "C:/Users/you/Desktop/daily prices"

DoCA daily all-India workbooks go to data/doca_national.csv.gz; mandi-level tables go to data/mandi/.
Original files are only read, never modified.
"""
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fci import store  # noqa: E402
from fci.sources import uploads  # noqa: E402


def main(folder: str) -> None:
    files = sorted(p for p in Path(folder).rglob("*") if p.suffix.lower() in {".csv", ".xls", ".xlsx", ".xlsm"})
    frames, failed = [], []
    for p in files:
        try:
            df, _ = uploads.parse_upload(p.name, p.read_bytes())
            frames.append(df)
        except Exception as e:  # report and continue with the remaining files
            failed.append((p.name, str(e)[:120]))
    if not frames:
        print("No readable price files found"); return
    allrows = pd.concat(frames, ignore_index=True)
    nat, mandi = allrows[allrows["level"] == "national"], allrows[allrows["level"] != "national"]
    if len(nat):
        r = store.save_national(nat); store.log_refresh("Folder import (national)", "OK", folder, r["rows_added"]); print("national", r)
    if len(mandi):
        r = store.save_mandi(mandi); store.log_refresh("Folder import (mandi)", "OK", folder, r["rows_added"]); print("mandi", r)
    print(f"{len(files)} files read, {len(failed)} failed")
    for f in failed:
        print("  FAILED", *f)


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else ".")
