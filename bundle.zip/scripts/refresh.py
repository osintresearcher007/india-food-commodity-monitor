"""Scheduled refresh (run by GitHub Actions, or by hand).

    python scripts/refresh.py                          # DoCA daily page, NECC egg sheet, mandi prices, news snapshot
    python scripts/refresh.py --agmarknet-months 12    # also back-fill AGMARKNET monthly prices for 12 months

No API key is needed. Every outcome is written to data/refresh_log.csv.
"""
import os, sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fci import store  # noqa: E402
from fci.config import DATA  # noqa: E402
from fci.sources import agmarknet, doca, necc, news  # noqa: E402

def scrape(label: str, fetch, save) -> None:
    """Run one page scraper; record success, empty result or failure in the refresh log."""
    try:
        got = fetch()
        r = save(got)
        span = f"{got['date'].min():%d %b %Y} to {got['date'].max():%d %b %Y}" if len(got) else "no rows"
        store.log_refresh(label, "OK" if len(got) else "EMPTY", span, r["rows_added"])
        print(label, r)
    except Exception as e:
        store.log_refresh(label, "FAILED", f"{type(e).__name__}: {e}")
        print(label, "FAILED", e)


def news_snapshot() -> None:
    try:
        df, fails = news.collect(days=10)
        if len(df):
            df.to_csv(DATA / "news.csv.gz", index=False)
            arch = DATA / "news_archive.csv.gz"  # running history for the news map's date slider (13 months)
            if arch.exists():
                df = news.dedupe(pd.concat([df, pd.read_csv(arch, parse_dates=["published"]).fillna("")], ignore_index=True))
            df[df["published"] >= pd.Timestamp.now() - pd.Timedelta(days=400)].to_csv(arch, index=False)
        store.log_refresh("News feeds", "OK" if len(df) else "EMPTY", f"{len(fails)} feed failures", len(df))
        print("news", len(df), "items;", len(fails), "failures")
    except Exception as e:
        store.log_refresh("News feeds", "FAILED", f"{type(e).__name__}: {e}")


def agmarknet_monthly(months_back: int = 1) -> None:
    """Fetch AGMARKNET market-wise monthly averages for whatever is not stored yet (slow: one request at a time)."""
    from fci import autoload
    y, m = agmarknet.last_complete_month()
    for _ in range(months_back):
        print(f"AGMARKNET {y}-{m:02d}", autoload.sync_month(y, m, rounds=3, cooldown=90))
        y, m = (y, m - 1) if m > 1 else (y - 1, 12)


if __name__ == "__main__":
    months = int(sys.argv[sys.argv.index("--agmarknet-months") + 1]) if "--agmarknet-months" in sys.argv else 1
    agmarknet_monthly(months)
    scrape(doca.SOURCE, doca.fetch, store.save_national)
    scrape(necc.SOURCE, necc.fetch, store.save_mandi)
    news_snapshot()
