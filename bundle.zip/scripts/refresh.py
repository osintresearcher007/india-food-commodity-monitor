"""Scheduled refresh (run by GitHub Actions, or by hand).

    python scripts/refresh.py                          # DoCA daily page, NECC egg sheet, mandi prices, news snapshot
    python scripts/refresh.py --backfill 2024-01-01 2024-01-31   # historical mandi prices, day by day

Needs the DATA_GOV_API_KEY environment variable for mandi prices. Every outcome is written to data/refresh_log.csv.
"""
import os, sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fci import store  # noqa: E402
from fci.config import DATA, classify_commodity, load_user_config  # noqa: E402
from fci.sources import datagov, doca, necc, news  # noqa: E402

KEEP_GROUPS_OUT = {"Other"}  # non-food / unclassified AGMARKNET items are not stored


def keep_food(df: pd.DataFrame) -> pd.DataFrame:
    cfg = load_user_config()
    grp = {c: classify_commodity(c, cfg)[1] for c in df["commodity"].dropna().unique()}
    return df[~df["commodity"].map(grp).isin(KEEP_GROUPS_OUT)]


def mandi(key: str, days: list | None = None) -> None:
    for day in days or [None]:
        label = datagov.SOURCE + (f" {day:%Y-%m-%d}" if day is not None else " (daily)")
        try:
            got = datagov.fetch(key) if day is None else datagov.fetch_day(key, day)
            got = keep_food(got)
            r = store.save_mandi(got)
            store.log_refresh(label, "OK" if len(got) else "EMPTY", f"{len(got)} rows fetched", r["rows_added"])
            print(label, r)
        except Exception as e:
            store.log_refresh(label, "FAILED", f"{type(e).__name__}: {e}")
            print(label, "FAILED", e)


def scrape(label: str, fetch, save) -> None:
    """Run one page scraper; record success, empty result or failure in the refresh log."""
    try:
        got = fetch()
        r = save(got)
        span = f"{got['date'].min():%d %b %Y} to {got['date'].max():%d %b %Y}" if len(got) else "no rows"
        store.log_refresh(label, "OK" if len(got) else "EMPTY", span, r["rows_added"])
        print(label, r)
    except Exception as e:
        store.log_refresh(label, "FAILED", f"{type(e).__name__}: {e}")
        print(label, "FAILED", e)


def news_snapshot() -> None:
    try:
        df, fails = news.collect(days=10)
        if len(df):
            df.to_csv(DATA / "news.csv.gz", index=False)
            arch = DATA / "news_archive.csv.gz"  # running history for the news map's date slider (13 months)
            if arch.exists():
                df = news.dedupe(pd.concat([df, pd.read_csv(arch, parse_dates=["published"]).fillna("")], ignore_index=True))
            df[df["published"] >= pd.Timestamp.now() - pd.Timedelta(days=400)].to_csv(arch, index=False)
        store.log_refresh("News feeds", "OK" if len(df) else "EMPTY", f"{len(fails)} feed failures", len(df))
        print("news", len(df), "items;", len(fails), "failures")
    except Exception as e:
        store.log_refresh("News feeds", "FAILED", f"{type(e).__name__}: {e}")


if __name__ == "__main__":
    key = os.environ.get("DATA_GOV_API_KEY", "")
    if "--backfill" in sys.argv:
        i = sys.argv.index("--backfill")
        mandi(key, list(pd.date_range(sys.argv[i + 1], sys.argv[i + 2], freq="D")))
    else:
        if key:
            mandi(key)
        else:
            store.log_refresh(datagov.SOURCE, "SKIPPED", "DATA_GOV_API_KEY not set")
        scrape(doca.SOURCE, doca.fetch, store.save_national)
        scrape(necc.SOURCE, necc.fetch, store.save_mandi)
        news_snapshot()
