"""Page - Data Upload & Fetch: bring data in by upload or on-demand fetch. Source names are not shown publicly."""
import pandas as pd
import streamlit as st
from fci import autoload, persist, store, ui
from fci.config import GROUP_ORDER, load_user_config, save_user_config
from fci.sources import agmarknet, doca, necc, uploads


def kind(source: str) -> str:
    """Public label for a stored source."""
    if source == doca.SOURCE:
        return "All-India prices"
    if source.startswith(agmarknet.SOURCE):
        return "Mandi prices"
    if source == necc.SOURCE:
        return "Egg prices"
    if source.startswith("News"):
        return "News"
    return "Uploaded file" if "pload" in source or "import" in source else "Other"


def page():
    ctx = st.session_state["ctx"]
    df = ctx["all"]
    st.title("Data Upload & Fetch")

    with ui.card("Fetch latest data"):
        st.caption("Data refreshes by itself when the app starts and every few hours while it is in use. Use these to fetch now.")
        a, b, c = st.columns(3)
        for col, label, src, fetch, save in ((a, "Fetch All-India prices", doca.SOURCE, doca.fetch, store.save_national),
                                             (c, "Fetch egg prices", necc.SOURCE, necc.fetch, store.save_mandi)):
            if col.button(label, key=f"scr_{label}", use_container_width=True, type="primary"):
                try:
                    with st.spinner("Fetching..."):
                        got = fetch()
                    r = save(got)
                    store.log_refresh(src, "OK" if len(got) else "EMPTY", f"manual; {len(got)} rows read", r["rows_added"])
                    st.cache_data.clear()
                    col.success(f"Done: {len(got):,} rows read, {r['rows_added']:,} new; latest date {got['date'].max():%d %b %Y}." if len(got) else "No rows returned.")
                except Exception as e:
                    store.log_refresh(src, "FAILED", f"{type(e).__name__}: {e}")
                    col.error(f"Fetch failed: {type(e).__name__}: {str(e)[:160]}. Nothing was changed.")
        if b.button("Fetch Mandi prices", key="scr_mandi", use_container_width=True, type="primary"):
            state = autoload.start_if_needed(force="mandi")
            st.session_state["agmarknet_load"] = state
            b.info("Mandi download started in the background. It takes 10 to 15 minutes; progress shows at the top of the Overview page.")
        load = autoload.STATE
        if load["status"] != "idle":
            b.caption(f"Mandi download: {load['status']} — {load['detail']}")
        q = autoload.QUICK
        if q["all_india"] or q["eggs"] or q["news"]:
            st.caption(f"Last automatic refresh — All-India prices: {q['all_india'] or 'pending'}; egg prices: {q['eggs'] or 'pending'}; news: {q['news'] or 'pending'}.")

    with ui.card("Latest data in the app"):
        rows = []
        for src, g in df.groupby("source"):
            monthly = (g["grade"] == "Monthly average").all()
            rows.append({"Data": kind(src) + (" (sample)" if g["is_sample"].any() else ""), "Latest": f"{g['date'].max():%B %Y}" if monthly else f"{g['date'].max():%d %b %Y}",
                         "From": f"{g['date'].min():%b %Y}", "Rows": len(g), "Commodities": g["commodity"].nunique(),
                         "Markets": g["market"].replace("", pd.NA).nunique(), "States": g["state"].replace("All India", pd.NA).nunique()})
        ui.show(pd.DataFrame(rows), height=None)

    with ui.card("Upload price files"):
        st.caption("Drag and drop one or many CSV, XLS, XLSX or XLSM files. Columns, dates, units and geography are detected "
                   "automatically; macros are never run; your original files are not changed.")
        files = st.file_uploader("Price files", type=["csv", "xls", "xlsx", "xlsm", "txt"], accept_multiple_files=True, key="up_files")
        if files:
            frames, reps = [], []
            for fl in files:
                try:
                    out, rep = uploads.parse_upload(fl.name, fl.getvalue())
                    frames.append(out)
                    reps += [{"file": fl.name, **{k: str(v) for k, v in r.items()}} for r in rep]
                except Exception as e:
                    reps.append({"file": fl.name, "error": f"{type(e).__name__}: {str(e)[:150]}"})
            ui.show(pd.DataFrame(reps), hide_index=True, use_container_width=True)
            new = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
            if len(new):
                std = store.standardise(new)
                _, dup = store.dedupe(std)
                q = store.quality_flags(store.add_taxonomy(std, load_user_config()))
                a, b, c, e = st.columns(4)
                a.metric("Rows read", len(std)); b.metric("Duplicates within upload", dup)
                c.metric("Failing quality checks", int((q["quality"] != "OK").sum())); e.metric("Commodities", q["commodity"].nunique())
                ui.show(q.head(200), hide_index=True, use_container_width=True, height=240)
                if st.button("Save to data store", type="primary", key="up_save"):
                    n, mnd = std[std["level"] == "national"], std[std["level"] != "national"]
                    msgs, changed = [], []
                    if len(n):
                        r = store.save_national(n); msgs.append(f"All-India: {r['rows_added']} new rows ({r['duplicates']} duplicates skipped)"); changed.append(store.NATIONAL)
                        store.log_refresh("Upload (all-India)", "OK", ", ".join(f.name for f in files)[:200], r["rows_added"])
                    if len(mnd):
                        r = store.save_mandi(mnd); msgs.append(f"Mandi: {r['rows_added']} new rows ({r['duplicates']} duplicates skipped)")
                        changed += sorted(store.MANDI_DIR.glob("*.csv.gz"))[-len(mnd['date'].dt.strftime('%Y-%m').unique()):]
                        store.log_refresh("Upload (mandi)", "OK", ", ".join(f.name for f in files)[:200], r["rows_added"])
                    repo, tok = ui.secret("GITHUB_REPO"), ui.secret("GITHUB_TOKEN")
                    if repo and tok:
                        msgs += persist.commit_many(changed + [store.LOG], repo, tok, ui.secret("GITHUB_BRANCH", "main"))
                    else:
                        msgs.append("Saved on this server only. On Streamlit Cloud this is temporary: set GITHUB_REPO and GITHUB_TOKEN secrets "
                                    "to commit uploads permanently, or add the files to the repository's data folder.")
                    st.cache_data.clear()
                    st.success(" · ".join(msgs))
            else:
                st.error("No price rows could be read from these files. Check that each has commodity, date and price columns.")

    with ui.card("Commodity priorities, exclusions and additions"):
        cfg = load_user_config()
        tax = df[["commodity", "group", "priority"]].drop_duplicates().sort_values(["group", "commodity"]).reset_index(drop=True)
        ed = st.data_editor(tax, hide_index=True, use_container_width=True, height=300, disabled=["commodity", "group"], key="cfg_ed",
                            column_config={"priority": st.column_config.SelectboxColumn("Priority", options=["High", "Medium", "Low"])})
        excl = st.multiselect("Excluded commodities", sorted(set(tax["commodity"]) | set(cfg["exclude"])), default=cfg["exclude"], key="cfg_ex")
        with st.expander("Add a commodity that is not recognised yet"):
            a, b, c, e = st.columns(4)
            pat = a.text_input("Text that appears in its name (e.g. 'bottle gourd')", key="cfg_pat")
            nm = b.text_input("Display name", key="cfg_nm")
            gp = c.selectbox("Group", GROUP_ORDER, key="cfg_gp")
            pr = e.selectbox("Priority", ["High", "Medium", "Low"], index=1, key="cfg_pr")
        if st.button("Save commodity settings", key="cfg_save"):
            cfg["priority"].update({r.commodity: r.priority for r in ed.itertuples()})
            cfg["exclude"] = excl
            if pat and nm:
                cfg["extra"] = [x for x in cfg["extra"] if x["name"] != nm] + [{"pattern": pat.lower(), "name": nm, "group": gp, "priority": pr}]
            save_user_config(cfg)
            repo, tok = ui.secret("GITHUB_REPO"), ui.secret("GITHUB_TOKEN")
            note = "; ".join(persist.commit_many([store.DATA / "user_config.json"], repo, tok, ui.secret("GITHUB_BRANCH", "main"))) if repo and tok else "saved on this server"
            st.cache_data.clear()
            st.success(f"Settings saved ({note}). Reload the page to apply.")

    with ui.card("Update history"):
        log = store.read_log().head(60)
        if len(log):
            log = log.assign(Data=log["source"].map(kind)).rename(columns={"time_utc": "Time (UTC)", "status": "Status", "rows": "New rows", "detail": "Detail"})
            log["Detail"] = log["Detail"].astype(str).str.replace(r"https?://\S+|[\w.-]+\.(gov\.in|nic\.in|com)\S*", "", regex=True)
            ui.show(log[["Time (UTC)", "Data", "Status", "New rows", "Detail"]], height=320)
        bad = int((df["quality"] != "OK").sum())
        st.caption(f"{bad:,} of {len(df):,} stored observations fail quality checks and are excluded from calculations.")
