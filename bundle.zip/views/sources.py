"""Page 8 - Data Sources & Uploads: import, refresh, quality and source management."""
import difflib
import pandas as pd
import streamlit as st
from fci import persist, store, ui
from fci.config import GROUP_ORDER, load_user_config, save_user_config
from fci.sources import datagov, doca, necc, uploads

CATALOGUE = [
    ("DoCA Price Monitoring – all-India daily retail & wholesale averages", "https://fcainfoweb.nic.in/Reports/DB/Dailyprices.aspx",
     "Scraped daily from the live report page by the GitHub Action (button below for an immediate fetch). History came from your saved workbooks."),
    ("AGMARKNET daily mandi prices (data.gov.in API)", "https://data.gov.in/catalog/current-daily-price-various-commodities-various-markets-mandi",
     "Automated: needs a free DATA_GOV_API_KEY. Collected daily by the GitHub Action; can also be fetched with the button below."),
    ("AGMARKNET variety-wise historical prices (data.gov.in API)", "https://data.gov.in/resource/variety-wise-daily-market-prices-data-commodity",
     "Automated back-fill by date: python scripts/refresh.py --backfill 2021-01-01 2021-12-31"),
    ("AGMARKNET monthly wholesale analysis", "https://agmarknet.gov.in/marketallwholesalemonthanalysis",
     "No public API: download the Excel/CSV from the portal and upload it here. Used for monthly analysis only."),
    ("e-NAM, state marketing boards, civil-supplies bulletins", "https://www.enam.gov.in/",
     "No stable public API: upload their downloadable files; columns are detected automatically."),
    ("Egg prices (NECC)", "https://www.e2necc.com/home/eggprice",
     "Scraped daily from the NECC sheet (Rs per 100 eggs, by centre; NECC-suggested and prevailing prices kept as separate varieties). "
     "DoCA retail egg prices (per dozen) are a separate series."),
    ("News, policy and international feeds", "https://news.google.com/", "Google News search RSS (11 languages) and PIB RSS; fetched live, cached 1 hour."),
]


def page():
    ctx = st.session_state["ctx"]
    df = ctx["all"]
    st.title("Data Sources & Uploads")
    nat, man = df[df["level"] == "national"], df[df["level"] != "national"]
    real_man = man[~man["is_sample"]]

    st.subheader("Data freshness")
    today = pd.Timestamp.today().normalize()
    rows = []
    for src, g in df.groupby("source"):
        age = (today - g["date"].max()).days
        rows.append({"Source": src, "Market types": ", ".join(sorted(g["market_type"].unique())), "Rows": len(g),
                     "From": g["date"].min().date(), "To": g["date"].max().date(), "Reporting days": g["date"].nunique(),
                     "Markets": g["market"].replace("", pd.NA).nunique(), "Age (days)": age,
                     "Status": "Sample only" if g["is_sample"].any() else "Current" if age <= 3 else "Stale" if age <= 10 else "Out of date"})
    st.dataframe(pd.DataFrame(rows), hide_index=True, use_container_width=True)
    if real_man.empty:
        st.warning("No real mandi-level data is loaded. Add a data.gov.in API key or upload AGMARKNET files below to enable real geographic analysis.")
    elif set(real_man["commodity"]) == {"Eggs"}:
        st.info("The only real centre-level data so far is NECC egg prices, so state and district views currently cover eggs only. "
                "Add the data.gov.in API key to bring in AGMARKNET mandi prices for other commodities.")

    st.subheader("Upload price files")
    st.caption("Drag and drop one or many CSV, XLS, XLSX or XLSM files. Columns, dates, units, wholesale/retail and geography are "
               "detected automatically; macros are never run; your original files are not changed.")
    files = st.file_uploader("Price files", type=["csv", "xls", "xlsx", "xlsm", "txt"], accept_multiple_files=True, key="up_files")
    if files:
        frames, reps = [], []
        for fl in files:
            try:
                out, rep = uploads.parse_upload(fl.name, fl.getvalue())
                frames.append(out)
                reps += [{"file": fl.name, **{k: str(v) for k, v in r.items()}} for r in rep]
            except Exception as e:
                reps.append({"file": fl.name, "error": f"{type(e).__name__}: {str(e)[:150]}"})
        st.dataframe(pd.DataFrame(reps), hide_index=True, use_container_width=True)
        new = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
        if len(new):
            std = store.standardise(new)
            _, dup = store.dedupe(std)
            q = store.quality_flags(store.add_taxonomy(std, load_user_config()))
            a, b, c, e = st.columns(4)
            a.metric("Rows read", len(std)); b.metric("Duplicates within upload", dup)
            c.metric("Failing quality checks", int((q["quality"] != "OK").sum())); e.metric("Commodities", q["commodity"].nunique())
            st.dataframe(q.head(200), hide_index=True, use_container_width=True, height=240)
            if st.button("Save to data store", type="primary", key="up_save"):
                n, mnd = std[std["level"] == "national"], std[std["level"] != "national"]
                msgs, changed = [], []
                if len(n):
                    r = store.save_national(n); msgs.append(f"All-India: {r['rows_added']} new rows ({r['duplicates']} duplicates skipped)"); changed.append(store.NATIONAL)
                    store.log_refresh("Upload (all-India)", "OK", ", ".join(f.name for f in files)[:200], r["rows_added"])
                if len(mnd):
                    r = store.save_mandi(mnd); msgs.append(f"Mandi: {r['rows_added']} new rows ({r['duplicates']} duplicates skipped)")
                    changed += sorted(store.MANDI_DIR.glob("*.csv.gz"))[-len(mnd['date'].dt.strftime('%Y-%m').unique()):]
                    store.log_refresh("Upload (mandi)", "OK", ", ".join(f.name for f in files)[:200], r["rows_added"])
                repo, tok = ui.secret("GITHUB_REPO"), ui.secret("GITHUB_TOKEN")
                if repo and tok:
                    msgs += persist.commit_many(changed + [store.LOG], repo, tok, ui.secret("GITHUB_BRANCH", "main"))
                else:
                    msgs.append("Saved on this server only. On Streamlit Cloud this is temporary: set GITHUB_REPO and GITHUB_TOKEN secrets "
                                "to commit uploads permanently, or add the files to the repository's data folder.")
                st.cache_data.clear()
                st.success(" · ".join(msgs))
        else:
            st.error("No price rows could be read from these files. Check that each has commodity, date and price columns.")

    st.subheader("Fetch today's pages now")
    st.caption("These run automatically every day in the scheduled GitHub Action. Use the buttons for an immediate update.")
    a, b = st.columns(2)
    for col, label, src, fetch, save, path in (
            (a, "Fetch DoCA all-India daily prices", doca.SOURCE, doca.fetch, store.save_national, lambda: [store.NATIONAL]),
            (b, "Fetch NECC egg prices", necc.SOURCE, necc.fetch, store.save_mandi, lambda: sorted(store.MANDI_DIR.glob("*.csv.gz"))[-1:])):
        if col.button(label, key=f"scr_{label}", use_container_width=True):
            try:
                with st.spinner("Reading the source page..."):
                    got = fetch()
                r = save(got)
                store.log_refresh(src, "OK" if len(got) else "EMPTY", f"{len(got)} rows read", r["rows_added"])
                repo, tok = ui.secret("GITHUB_REPO"), ui.secret("GITHUB_TOKEN")
                note = "; ".join(persist.commit_many(path() + [store.LOG], repo, tok, ui.secret("GITHUB_BRANCH", "main"))) if repo and tok else "kept on this server until restart"
                st.cache_data.clear()
                col.success(f"{len(got):,} rows read, {r['rows_added']:,} new ({note}).")
            except Exception as e:
                store.log_refresh(src, "FAILED", f"{type(e).__name__}: {e}")
                col.error(f"Could not read the page: {type(e).__name__}: {str(e)[:160]}. Nothing was changed.")

    st.subheader("Fetch mandi prices from data.gov.in (AGMARKNET)")
    key = ui.secret("DATA_GOV_API_KEY")
    if not key:
        st.info("Add `DATA_GOV_API_KEY` in the app's Secrets (Streamlit Cloud → App → Settings → Secrets) to enable this. "
                "The key is free: register at data.gov.in and copy it from 'My Account'.")
    elif st.button("Fetch latest daily mandi prices now", key="dg_fetch"):
        try:
            with st.spinner("Calling data.gov.in..."):
                got = datagov.fetch(key)
            r = store.save_mandi(got)
            store.log_refresh(datagov.SOURCE, "OK", f"{got['date'].min():%d %b %Y} to {got['date'].max():%d %b %Y}" if len(got) else "no rows", r["rows_added"])
            st.cache_data.clear()
            st.success(f"Fetched {len(got):,} rows; {r['rows_added']:,} new.")
        except Exception as e:
            store.log_refresh(datagov.SOURCE, "FAILED", f"{type(e).__name__}: {e}")
            st.error(f"data.gov.in request failed: {type(e).__name__}: {str(e)[:200]}. Nothing was changed.")

    st.subheader("Commodity priorities, exclusions and additions")
    cfg = load_user_config()
    tax = df[["commodity", "group", "priority"]].drop_duplicates().sort_values(["group", "commodity"]).reset_index(drop=True)
    ed = st.data_editor(tax, hide_index=True, use_container_width=True, height=300, disabled=["commodity", "group"], key="cfg_ed",
                        column_config={"priority": st.column_config.SelectboxColumn("Priority", options=["High", "Medium", "Low"])})
    excl = st.multiselect("Excluded commodities", sorted(set(tax["commodity"]) | set(cfg["exclude"])), default=cfg["exclude"], key="cfg_ex")
    with st.expander("Add a commodity that is not recognised yet"):
        a, b, c, e = st.columns(4)
        pat = a.text_input("Text that appears in its name (e.g. 'bottle gourd')", key="cfg_pat")
        nm = b.text_input("Display name", key="cfg_nm")
        gp = c.selectbox("Group", GROUP_ORDER, key="cfg_gp")
        pr = e.selectbox("Priority", ["High", "Medium", "Low"], index=1, key="cfg_pr")
    if st.button("Save commodity settings", key="cfg_save"):
        cfg["priority"].update({r.commodity: r.priority for r in ed.itertuples()})
        cfg["exclude"] = excl
        if pat and nm:
            cfg["extra"] = [x for x in cfg["extra"] if x["name"] != nm] + [{"pattern": pat.lower(), "name": nm, "group": gp, "priority": pr}]
        save_user_config(cfg)
        repo, tok = ui.secret("GITHUB_REPO"), ui.secret("GITHUB_TOKEN")
        note = "; ".join(persist.commit_many([store.DATA / "user_config.json"], repo, tok, ui.secret("GITHUB_BRANCH", "main"))) if repo and tok else "saved on this server"
        st.cache_data.clear()
        st.success(f"Settings saved ({note}). Reload the page to apply.")

    st.subheader("Data-quality checks")
    a, b = st.columns(2)
    with a:
        miss = store.missing_dates(nat[nat["date"] >= nat["date"].max() - pd.Timedelta(days=240)]) if len(nat) else []
        st.markdown(f"**All-India series: {len(miss)} calendar days without a report in the last 240 days**")
        st.write(", ".join(f"{x:%d %b}" for x in miss) or "None")
        st.markdown(f"**Observations failing checks:** {int((df['quality'] != 'OK').sum()):,} of {len(df):,}")
        st.dataframe(df[df["quality"] != "OK"]["quality"].value_counts().rename_axis("Check").reset_index(name="Rows"), hide_index=True)
    with b:
        st.markdown("**Possibly inconsistent market names (same district, similar spelling)**")
        pairs = []
        for (s, dname), g in real_man.groupby(["state", "district"]) if len(real_man) else []:
            names = sorted(g["market"].unique())
            for i, x in enumerate(names):
                for y in names[i + 1:]:
                    if difflib.SequenceMatcher(None, x.lower(), y.lower()).ratio() > 0.86:
                        pairs.append({"State": s, "District": dname, "Name A": x, "Name B": y})
        st.dataframe(pd.DataFrame(pairs), hide_index=True, use_container_width=True) if pairs else st.write("None found" if len(real_man) else "No real mandi data loaded")

    st.subheader("Refresh log")
    st.dataframe(store.read_log().head(200), hide_index=True, use_container_width=True)

    st.subheader("Source catalogue")
    st.dataframe(pd.DataFrame(CATALOGUE, columns=["Source", "Link", "How it is used here"]), hide_index=True, use_container_width=True,
                 column_config={"Link": st.column_config.LinkColumn("Link", display_text="open")})
    st.caption("Retail and wholesale series, and each source, are stored and analysed separately. Every observation keeps its "
               "source, reporting date, unit and market type.")
