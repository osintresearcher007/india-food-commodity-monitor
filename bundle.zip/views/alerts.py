"""Page 2 - Price Alerts at mandi, district and state level (plus all-India), weekly and monthly."""
import pandas as pd
import streamlit as st
from fci import analytics as A, ui

COLS = {"commodity": "Commodity", "variety": "Variety", "market_type": "Type", "state": "State", "district": "District",
        "market": "Centre / mandi", "price_cur": "Current avg", "price_prev": "Previous avg", "change_abs": "Change (Rs)",
        "change_pct": "Change %", "unit": "Unit", "obs_cur": "Days (cur)", "obs_prev": "Days (prev)",
        "n_markets": "Markets", "arrivals_change_pct": "Arrivals %", "method": "Method", "confidence": "Confidence",
        "source": "Source", "status": "Status"}


def page():
    ctx = st.session_state["ctx"]
    d, f = ctx["df"], ctx["filters"]
    st.title("Price Alerts")
    w, m = ui.compute(d, f)
    ui.sample_banner(d)
    a, b, c = st.columns([1, 2, 2])
    freq = a.radio("Comparison", ["Weekly (> 5%)", "Monthly (> 10%)"], key="al_freq")
    run = w if freq.startswith("W") else m
    move = b.radio("Price movement", ["Increases", "Decreases", "Both", "All observations"], horizontal=True, key="al_move")
    conf = c.multiselect("Confidence", ["High", "Medium", "Low", "Concentrated", "Check data"], default=["High", "Medium", "Low", "Concentrated"], key="al_conf")
    st.caption(f"All-India retail: **{ui.period_caption(run)}** (latest day against the same day a week or month earlier). "
               f"Mandi prices: **{ui.period_caption(run, 'mandi')}** (period averages, matched markets only).")
    tabs = st.tabs(["All-India retail", "State", "District", "Centre / mandi", "All centres combined", "Excluded / data checks"])
    levels = ["official", "state", "district", "mandi", "national"]
    for tab, lv in zip(tabs, levels):
        with tab:
            st.markdown(f"**{ui.as_on(run, 'official' if lv == 'official' else 'mandi').capitalize()}**")
            t = run.get(lv, pd.DataFrame())
            if t is None or not len(t):
                st.info("No comparable observations at this level for the current filters.")
                continue
            if lv in ("mandi", "district"):
                x, y = st.columns(2)
                dsel = x.multiselect("District", sorted(t["district"].unique()), key=f"al_d_{lv}")
                t = t[t["district"].isin(dsel)] if dsel else t
                if lv == "mandi":
                    msel = y.multiselect("Mandi", sorted(t["market"].unique()), key="al_m")
                    t = t[t["market"].isin(msel)] if msel else t
            t = t[t["confidence"].isin(conf)]
            total = len(t)
            if move == "Increases":
                t = t[t["status"].str.startswith("Inc")]
            elif move == "Decreases":
                t = t[t["status"].str.startswith("Dec")]
            elif move == "Both":
                t = t[t["status"] != "Within range"]
            x, y, z = st.columns(3)
            x.metric("Rows shown", len(t)); y.metric("Compared series / groups", total)
            z.metric("Share beyond threshold", f"{100 * (run[lv]['status'] != 'Within range').mean():.0f}%")
            out = t.sort_values("change_pct", ascending=move == "Decreases")
            keep = [c for c in COLS if c in out.columns and c not in ("variety", "market_type", "obs_cur", "obs_prev", "method", "source", "change_abs")]
            if lv == "official":
                keep = [c for c in keep if c not in ("state", "district", "market")]
            out = out[keep].rename(columns=COLS)
            ui.show(ui.style_changes(out, ["Change %"], {"Change %": run["threshold"]}), hide_index=True,
                         use_container_width=True, height=460)
            ui.download(out, f"alerts_{run['freq']}_{lv}.csv")
    with tabs[5]:
        st.markdown("**Changes beyond ±60% (possible data-entry errors) — excluded from district/state aggregates**")
        sus = run["mandi"][run["mandi"]["confidence"] == "Check data"] if len(run["mandi"]) else pd.DataFrame()
        ui.show(sus[[c for c in COLS if c in sus.columns]].rename(columns=COLS) if len(sus) else sus, hide_index=True, use_container_width=True)
        bad = d[d["quality"] != "OK"]
        st.markdown(f"**Observations failing quality checks: {len(bad):,}**")
        ui.show(bad[["date", "state", "district", "market", "commodity", "modal_price", "unit", "source", "quality"]].head(500),
                     hide_index=True, use_container_width=True)
        st.caption("Confidence — mandi: High = 3+ reporting days in both periods, Medium = 2, Low = 1. "
                   "District/state: High = 5+ matched markets, Medium = 2–4, Low = 1. Concentrated = the average crossed the threshold but the median market did not (driven by a few markets). A single-market move is never a state-wide finding.")
