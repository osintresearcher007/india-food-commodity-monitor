"""Page 5 - Local Market News (regional and regional-language coverage)."""
import streamlit as st
from fci import ui
from fci.sources import news as N


def page():
    st.title("Local Market News")
    a, b = st.columns([3, 1])
    langs = a.multiselect("Languages searched", list(N.LANG_NAMES), default=st.session_state.get("news_langs", list(N.LANG_NAMES)),
                          format_func=N.LANG_NAMES.get, key="nw_langs")
    days = b.slider("Window (days)", 3, 30, 10, key="nw_days")
    st.session_state["news_langs"] = langs or ["en"]
    nw, fails, origin = ui.get_news(days)
    local = nw[nw["section"] == "Local"] if len(nw) else nw
    st.caption(f"Source: {origin}. Google News search RSS in {len(langs)} languages plus any custom feeds. "
               "Only feed headlines, publishers, dates and links are used; open the link for the full report.")
    if fails:
        with st.expander(f"⚠️ {len(fails)} feed request(s) failed"):
            st.write("\n".join(f"- {x}" for x in fails))
    if local.empty:
        st.warning("No local news could be retrieved. If this persists on the hosted app, check feed status on the Data Sources page; "
                   "the scheduled GitHub Action also stores a daily snapshot that is used as a fallback.")
        return
    c = st.columns(5)
    explode = lambda col: sorted({x for v in local[col] for x in v.split(", ") if x})
    fc = c[0].multiselect("Commodity", explode("commodities"), key="nw_c")
    fs = c[1].multiselect("State", explode("states"), key="nw_s")
    ft = c[2].multiselect("Theme", explode("themes"), key="nw_t")
    fl = c[3].multiselect("Language", sorted(local["language"].unique()), key="nw_l")
    fe = c[4].multiselect("Evidence type", sorted(local["evidence"].unique()), key="nw_e")
    q = st.text_input("Search headlines", key="nw_q")
    t = local
    has = lambda col, vals: t[col].apply(lambda v: any(x in v.split(", ") for x in vals))
    for col, vals in (("commodities", fc), ("states", fs), ("themes", ft)):
        if vals:
            t = t[has(col, vals)]
    t = t[t["language"].isin(fl)] if fl else t
    t = t[t["evidence"].isin(fe)] if fe else t
    t = t[t["title"].str.contains(q, case=False, regex=False)] if q else t
    k = st.columns(4)
    k[0].metric("Items", len(t)); k[1].metric("Regional-language items", int((t["language"] != "English").sum()))
    k[2].metric("Hoarding / enforcement", int(t["themes"].str.contains("Hoarding").sum()))
    k[3].metric("Shortage / low arrivals", int(t["themes"].str.contains("Shortage").sum()))
    st.info("**Evidence labels** — *Official statement*: attributed to government in the headline. *Media allegation (unverified)*: "
            "hoarding or accusation language. *Forecast / expectation*: forward-looking wording. *Media report*: everything else. "
            "Labels and tags are keyword-based, not verified facts.", icon="ℹ️")
    tab1, tab2 = st.tabs(["Cards", "Table"])
    with tab1:
        ui.news_cards(t, 60)
    with tab2:
        out = t[["published", "title", "publisher", "language", "commodities", "states", "districts", "themes", "evidence", "link"]]
        ui.show(out, hide_index=True, use_container_width=True, height=560,
                     column_config={"link": st.column_config.LinkColumn("Source", display_text="open"),
                                    "published": st.column_config.DatetimeColumn("Published", format="DD MMM YYYY")})
        ui.download(out, "local_market_news.csv")
