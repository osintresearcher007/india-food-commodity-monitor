"""Page 4 - State & District Explorer."""
import pandas as pd
import plotly.express as px
import streamlit as st
from fci import analytics as A, ui


def page():
    ctx = st.session_state["ctx"]
    d, f = ctx["df"], ctx["filters"]
    st.title("State & District Explorer")
    man = d[(d["level"] != "national") & (d["quality"] == "OK")]
    if man.empty:
        st.info("No mandi-level data matches the current filters. Load AGMARKNET data on the Data Sources & Uploads page."); return
    ui.sample_banner(man)
    w, m = ui.compute(d, f)
    a, b, c = st.columns([2, 1, 2])
    state = a.selectbox("State", sorted(man["state"].unique()), key="ge_state")
    freq = b.radio("Period", ["Weekly", "Monthly"], horizontal=True, key="ge_freq")
    run = w if freq == "Weekly" else m
    thr = run["threshold"]
    dd = run["district"][run["district"]["state"] == state]
    mm = run["mandi"][run["mandi"]["state"] == state]
    coms = sorted(dd["commodity"].unique())
    com = c.selectbox("Commodity for district map", coms, key="ge_com") if coms else None
    st.caption(f"Comparison: {ui.period_caption(run, 'mandi')}")

    x, y = st.columns([2, 3])
    with x:
        st.subheader("District map")
        dm = dd[dd["commodity"] == com].copy() if com else dd.head(0)
        dm["fid"] = [ui.district_id(state, v) for v in dm["district"]]
        gj = ui.geo("districts")
        feats = {"type": "FeatureCollection", "features": [ft for ft in gj["features"] if ft["properties"]["st_nm"] == state]}
        if feats["features"] and dm["fid"].notna().any():
            lim = max(thr * 2, dm["change_pct"].abs().max())
            fig = ui.choropleth(dm.dropna(subset=["fid"]), "districts", "fid", "change_pct", state=state, height=430, hover_name="district",
                                hover_data={"fid": False, "price_cur": ":.0f", "price_prev": ":.0f", "n_markets": True, "confidence": True},
                                color_continuous_scale="RdBu_r", range_color=[-lim, lim], labels={"change_pct": "Change %"})
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("No district boundaries could be matched for this state and commodity.")
        miss = dm[dm["fid"].isna()]["district"].tolist()
        if miss:
            st.caption("Districts in the data without a matching boundary (2019 district map): " + ", ".join(miss))
    with y:
        st.subheader("District × commodity change heatmap (%)")
        if len(dd):
            pv = dd.pivot_table(index="district", columns="commodity", values="change_pct", aggfunc="mean").round(1)
            lim = max(thr * 2, float(pv.abs().max().max()))
            fig = px.imshow(pv, color_continuous_scale="RdBu_r", zmin=-lim, zmax=lim, text_auto=True, aspect="auto",
                            labels=dict(color="Change %", x="", y=""))
            fig.update_layout(margin=dict(l=0, r=0, t=10, b=0), height=430)
            st.plotly_chart(fig, use_container_width=True)
            st.caption("Blank cells: no matched market in both periods.")

    with ui.card("District summary"):
        cols = {"commodity": "Commodity", "district": "District", "price_cur": "Current avg", "price_prev": "Previous avg",
                "change_pct": "Change %", "n_markets": "Markets", "arrivals_change_pct": "Arrivals %", "method": "Method",
                "confidence": "Confidence", "status": "Status"}
        out = dd.sort_values("change_pct", ascending=False)[list(cols)].rename(columns=cols)
        ui.show(ui.style_changes(out, ["Change %"], {"Change %": thr}), hide_index=True, use_container_width=True, height=280)
        ui.download(out, f"{state}_districts_{run['freq']}.csv")

    with ui.card("Mandi detail"):
        p, q = st.columns(2)
        dist = p.multiselect("District", sorted(mm["district"].unique()), key="ge_dist")
        mk = q.multiselect("Mandi", sorted(mm[mm["district"].isin(dist)]["market"].unique() if dist else mm["market"].unique()), key="ge_mk")
        t = mm[mm["district"].isin(dist)] if dist else mm
        t = t[t["market"].isin(mk)] if mk else t
        mc = {"commodity": "Commodity", "variety": "Variety", "district": "District", "market": "Mandi", "price_cur": "Current avg",
              "price_prev": "Previous avg", "change_abs": "Change (Rs)", "change_pct": "Change %", "obs_cur": "Days (cur)",
              "obs_prev": "Days (prev)", "confidence": "Confidence", "source": "Source"}
        out = t.sort_values("change_pct", ascending=False)[list(mc)].rename(columns=mc)
        ui.show(ui.style_changes(out, ["Change %"], {"Change %": thr}), hide_index=True, use_container_width=True, height=300)
        ui.download(out, f"{state}_mandis_{run['freq']}.csv")

    with ui.card("Price and arrivals over time"):
        sm = man[man["state"] == state]
        sm = sm[sm["district"].isin(dist)] if dist else sm
        sm = sm[sm["market"].isin(mk)] if mk else sm
        com2 = st.selectbox("Commodity", sorted(sm["commodity"].unique()), index=sorted(sm["commodity"].unique()).index(com) if com in set(sm["commodity"]) else 0, key="ge_com2")
        ts = A.trend(sm[sm["commodity"] == com2], ["market"] if mk else ["district"])
        key = "market" if mk else "district"
        fig = px.line(ts, x="date", y="price", color=key, hover_data=["markets"], labels={"price": "Median modal price", "date": ""})
        fig.update_layout(height=340, margin=dict(l=0, r=0, t=10, b=0), hovermode="x unified", legend=dict(orientation="h", y=1.15))
        st.plotly_chart(fig, use_container_width=True)
        if ts["arrivals"].notna().any():
            arr = ts.groupby("date")["arrivals"].sum(min_count=1).reset_index()
            fig = px.bar(arr, x="date", y="arrivals", labels={"arrivals": "Arrivals (reported units)", "date": ""})
            fig.update_layout(height=220, margin=dict(l=0, r=0, t=10, b=0))
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.caption("This source does not report arrivals.")
