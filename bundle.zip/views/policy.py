"""Page 6 - Policy & Market Developments, and the international monitor."""
import pandas as pd
import plotly.express as px
import streamlit as st
from fci import ui
from fci.sources import news as N
from fci.signals import NEWS_TAG


def before_after(d: pd.DataFrame, when: pd.Timestamp, tag: str) -> None:
    """Official all-India price around an announcement date. Descriptive only."""
    nat = d[(d["level"] == "national") & (d["quality"] == "OK")]
    groups = [g for g, t in NEWS_TAG.items() if t == tag]
    pool = nat[(nat["commodity"] == tag) | nat["group"].isin(groups)]
    if pool.empty:
        st.caption("No official all-India series for this commodity."); return
    a, b = st.columns(2)
    com = a.selectbox("Series", sorted(pool["commodity"].unique()), key="pl_ser")
    mt = b.radio("Type", sorted(pool["market_type"].unique()), horizontal=True, key="pl_mt")
    s = pool[(pool["commodity"] == com) & (pool["market_type"] == mt)]
    s = s[(s["date"] >= when - pd.Timedelta(days=45)) & (s["date"] <= when + pd.Timedelta(days=45))].sort_values("date")
    if s.empty:
        st.caption("No price observations within 45 days of the announcement."); return
    fig = px.line(s, x="date", y="modal_price", labels={"modal_price": s["unit"].iat[0], "date": ""})
    fig.add_vline(x=when, line_dash="dash", line_color="#b91c1c")
    fig.update_layout(height=300, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, use_container_width=True)
    pre = s[(s["date"] < when) & (s["date"] >= when - pd.Timedelta(days=14))]["modal_price"]
    post = s[(s["date"] > when) & (s["date"] <= when + pd.Timedelta(days=14))]["modal_price"]
    if len(pre) and len(post):
        st.write(f"Average in the 14 days before: **Rs {pre.mean():,.2f}** ({len(pre)} days); 14 days after: "
                 f"**Rs {post.mean():,.2f}** ({len(post)} days); change **{(post.mean() / pre.mean() - 1) * 100:+.1f}%**.")
    else:
        st.write("Not enough observations on both sides of the date for a before/after comparison yet.")
    st.caption("A price change after an announcement is not evidence that the policy caused it; other supply and demand factors are not controlled for.")


def page():
    ctx = st.session_state["ctx"]
    st.title("Policy & International Developments")
    days = st.slider("Window (days)", 7, 45, 21, key="pl_days")
    nw, fails, origin = ui.get_news(days)
    st.caption(f"Source: {origin}. Mechanism, direction and status are assigned by published keyword rules from the headline; "
               "they are analytical interpretations, not statements by the source.")
    if fails:
        with st.expander(f"⚠️ {len(fails)} feed request(s) failed"):
            st.write("\n".join(f"- {x}" for x in fails))
    t1, t2, t3 = st.tabs(["Policy & Market Developments", "International developments", "India's structural trade exposure"])
    with t1:
        pol = N.policy_view(nw) if len(nw) else nw
        if pol.empty:
            st.warning("No policy items could be retrieved in this window.")
        else:
            a, b = st.columns(2)
            fs = a.multiselect("Status", sorted(pol["status"].unique()), key="pl_st")
            fc = b.multiselect("Commodity", sorted({x for v in pol["commodities"] for x in v.split(", ") if x}), key="pl_c")
            p = pol[pol["status"].isin(fs)] if fs else pol
            p = p[p["commodities"].apply(lambda v: any(x in v.split(", ") for x in fc))] if fc else p
            st.markdown("**Policy announcement → Affected commodities → Transmission mechanism → Price implication → Evidence and uncertainty**")
            out = p[["published", "title", "publisher", "status", "commodities", "mechanism", "implication", "evidence", "uncertainty", "link"]]
            ui.show(out, hide_index=True, use_container_width=True, height=380,
                         column_config={"link": st.column_config.LinkColumn("Source", display_text="open"),
                                        "published": st.column_config.DatetimeColumn("Date", format="DD MMM YYYY"),
                                        "title": st.column_config.TextColumn("Announcement", width="large")})
            ui.download(out, "policy_developments.csv")
            st.subheader("Prices before and after an announcement")
            opts = p[p["commodities"] != ""].dropna(subset=["published"])
            if len(opts):
                i = st.selectbox("Announcement", opts.index, format_func=lambda i: f"{opts.loc[i, 'published']:%d %b} — {opts.loc[i, 'title'][:110]}", key="pl_pick")
                tag = st.selectbox("Commodity", opts.loc[i, "commodities"].split(", "), key="pl_tag")
                before_after(ctx["all"], opts.loc[i, "published"].normalize(), tag)
            st.subheader("Items")
            ui.news_cards(p, 25, ["status", "mechanism", "implication"])
    with t2:
        x = N.intl_view(nw) if len(nw) else nw
        if x.empty:
            st.warning("No international items could be retrieved in this window.")
        else:
            fr = st.multiselect("Commodity", sorted(x["commodity"].unique()), key="pl_ic")
            x = x[x["commodity"].isin(fr)] if fr else x
            out = x[["published", "region", "commodity", "title", "publisher", "exposure", "mechanism", "direction", "horizon", "confidence", "link"]]
            ui.show(out, hide_index=True, use_container_width=True, height=380,
                         column_config={"link": st.column_config.LinkColumn("Source", display_text="open"),
                                        "published": st.column_config.DatetimeColumn("Date", format="DD MMM YYYY"),
                                        "title": st.column_config.TextColumn("Development", width="large")})
            ui.download(out, "international_developments.csv")
            st.caption("An item is linked to India only through the stated transmission mechanism. Where India's trade link is weak "
                       "(wheat, rice, sugar) the direction is marked indirect and confidence is lowered.")
            ui.news_cards(x, 25, ["region", "exposure", "mechanism", "direction", "horizon", "confidence"])
    with t3:
        st.markdown("Reference notes used by the international monitor (qualitative, long-standing trade structure; "
                    "check APEDA AgriExchange and DGCIS for current volumes).")
        ref = pd.DataFrame([{"Topic keyword": r[0].replace("|", ", "), "Region": r[1], "Commodity": r[2], "India exposure": r[3],
                             "Transmission mechanism": r[4], "Typical horizon": r[5]} for r in N.INTL_RULES])
        ui.show(ref, hide_index=True, use_container_width=True)
        st.markdown("**Primary references**: [FAO Food Price Index](https://www.fao.org/worldfoodsituation/foodpricesindex) · "
                    "[International Grains Council](https://www.igc.int/) · [USDA](https://www.usda.gov/) · "
                    "[APEDA AgriExchange](https://agriexchange.apeda.gov.in/) · [PIB](https://pib.gov.in/) · [DGFT](https://www.dgft.gov.in/)")
