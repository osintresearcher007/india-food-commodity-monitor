"""Page 7 - Weekly & Monthly Insights: early-warning signals and downloadable reports."""
import pandas as pd
import plotly.express as px
import streamlit as st
from fci import analytics as A, reports, signals, ui
from fci.sources import news as N

MIME = {"PDF": ("pdf", "application/pdf"), "Word (.docx)": ("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
        "Excel (.xlsx)": ("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")}


@st.cache_data(show_spinner="Preparing report...")
def render(kind: str, fmt: str, key: tuple, _ctx: dict) -> bytes:
    rep = reports.build(kind, _ctx)
    if fmt == "PDF":
        return reports.to_pdf(rep)
    if fmt.startswith("Word"):
        return reports.to_docx(rep)
    run = _ctx[kind]
    extra = {f"Data {lv}": A.display_alerts(A.alert_table(_ctx["weekly"], _ctx["monthly"], lv)) for lv in ("official", "state", "district", "mandi")}
    extra["Signals"] = _ctx["signals"]
    return reports.to_xlsx(rep, extra)


def page():
    ctx = st.session_state["ctx"]
    d, f = ctx["df"], ctx["filters"]
    st.title("Weekly & Monthly Insights")
    sample = ui.sample_banner(d)
    with ui.card("Report settings"):
        a, b, c, e = st.columns(4)
        mx = d["date"].max().date() if len(d) else pd.Timestamp.today().date()
        mn = d["date"].min().date() if len(d) else mx
        as_of = a.date_input("Report as of (data up to)", mx, min_value=mn, max_value=mx, key="in_asof")
        length = b.selectbox("Report length", list(reports.LENGTH), index=1, key="in_len")
        days = c.slider("News window (days)", 3, 45, 10, key="in_days")
        fmt = e.selectbox("Format", list(MIME), key="in_fmt")
        st.caption("Commodities, states, market type and sources follow the sidebar filters. The weekly report uses the last complete "
                   "Monday–Sunday week on or before the chosen date; the monthly report uses the last complete calendar month.")
        w, m = ui.compute(d, f, pd.Timestamp(as_of))
        nw, fails, origin = ui.get_news(days)
        if len(nw):
            nw = nw[nw["published"].isna() | (nw["published"] <= pd.Timestamp(as_of) + pd.Timedelta(days=1))]
        sig = ui.get_signals(d, w, m, nw)
        rctx = {"weekly": w, "monthly": m, "signals": sig, "news": nw, "policy": N.policy_view(nw) if len(nw) else nw,
                "intl": N.intl_view(nw) if len(nw) else nw, "length": length, "sample": sample,
                "filters": {k: v for k, v in f.items() if k != "provisional"}, "generated": pd.Timestamp.now()}
        key = (ui.data_version(), str(as_of), length, days, len(nw), fmt, tuple((k, tuple(v) if isinstance(v, list) else v) for k, v in f.items()))
        ext, mime = MIME[fmt]
        x, y = st.columns(2)
        x.download_button("⬇️  Download Weekly Insights", render("weekly", fmt, key, rctx), file_name=f"weekly_insights_{as_of}.{ext}",
                          mime=mime, type="primary", use_container_width=True, key="dl_weekly")
        y.download_button("⬇️  Download Monthly Insights", render("monthly", fmt, key, rctx), file_name=f"monthly_insights_{as_of}.{ext}",
                          mime=mime, type="primary", use_container_width=True, key="dl_monthly")
        if origin == "Unavailable":
            st.caption("News feeds are currently unavailable, so the news sections of the report will say so. Price sections are unaffected.")

    with ui.card("Early-warning signals"):
        if sig.empty:
            st.info("No signals for the current filters."); return
        k = st.columns(4)
        for col, lab in zip(k, ["Significant", "Elevated", "Watch", "Normal"]):
            col.metric(lab, int((sig["signal"] == lab).sum()))
        show = sig[["commodity", "signal", "score", "pattern", "weekly_change_pct", "monthly_change_pct", "states_beyond_threshold",
                    "states_reporting", "districts_beyond_threshold", "markets", "weeks_same_direction", "arrivals_change_pct",
                    "local_news", "policy_intl_news", "basis"]].rename(columns={
            "commodity": "Commodity", "signal": "Signal", "score": "Score", "pattern": "Pattern", "weekly_change_pct": "WoW %",
            "monthly_change_pct": "MoM %", "states_beyond_threshold": "States > thr", "states_reporting": "States reporting",
            "districts_beyond_threshold": "Districts > thr", "markets": "Markets", "weeks_same_direction": "Weeks same direction",
            "arrivals_change_pct": "Arrivals %", "local_news": "Local reports", "policy_intl_news": "Policy/intl items", "basis": "Basis"})
        ui.show(ui.style_changes(show, ["WoW %", "MoM %"]).map(
            lambda v: f"color:{ui.SIGNAL_COLOR.get(v, '')};font-weight:600", subset=["Signal"]), hide_index=True, use_container_width=True, height=380)
        ui.download(sig, "signals.csv")
        top = sig.head(15).melt(id_vars="commodity", value_vars=[c for c in sig.columns if c.startswith("pts_")], var_name="component", value_name="points")
        top["component"] = top["component"].str.replace("pts_", "").str.replace("context", "policy / international").str.title()
        fig = px.bar(top, y="commodity", x="points", color="component", orientation="h", labels={"points": "Score contribution", "commodity": ""},
                     category_orders={"commodity": sig.head(15)["commodity"].tolist()})
        fig.update_layout(height=430, margin=dict(l=0, r=0, t=10, b=0), legend=dict(orientation="h", y=1.1), xaxis_range=[0, 100])
        st.plotly_chart(fig, use_container_width=True)
        with st.expander("How the score is calculated"):
            st.markdown(f"```\n{signals.__doc__}\n```")
            st.markdown("A price spike, an actual shortage and an alleged shortage are kept distinct: the score rises with supporting "
                        "evidence but the *pattern* column states only what the data shows (e.g. 'price up, arrivals down').")

    with ui.card("Commodity brief"):
        com = st.selectbox("Commodity", sig["commodity"], key="in_com")
        r = sig[sig["commodity"] == com].iloc[0]
        st.markdown(f"**{com} — {r['signal']} ({r['score']:.0f}/100)**. {r['pattern']}. Basis: {r['basis'].lower()}.")
        stw = w["state"][w["state"]["commodity"] == com] if len(w["state"]) else pd.DataFrame()
        if len(stw):
            ui.show(ui.style_changes(stw.sort_values("change_pct", ascending=False)[["state", "price_cur", "price_prev", "change_pct", "n_markets", "arrivals_change_pct", "confidence"]],
                                          ["change_pct"], {"change_pct": 5}), hide_index=True, use_container_width=True, height=220)
        nf = signals.news_for(nw, com, r["group"])
        if len(nf):
            st.markdown("**Related reports and policy items (chronological)**")
            ui.news_cards(nf.sort_values("published"), 8)
        else:
            st.caption("No related news items in the window.")
