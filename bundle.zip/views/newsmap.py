"""India News Map - pointers on the map of India where local commodity news is reported, with a date slider."""
import pandas as pd
import plotly.express as px
import streamlit as st
from fci import reports, ui


def page():
    st.title("India News Map")
    nw, fails, origin = ui.get_news(400)
    local = nw[(nw["section"] == "Local") & nw["published"].notna()].copy() if len(nw) else pd.DataFrame()
    st.caption(f"News {origin}. Each pointer marks a district (or, when only a state is named, the state's centre) "
               "named in a local or regional-language commodity headline. A headline that names no state, district or major city "
               "is listed but not placed. Words such as 'mandi' that are also district names are not treated as places.")
    if fails:
        with st.expander(f"⚠️ {len(fails)} feed request(s) failed"):
            st.write("\n".join(f"- {x}" for x in fails))
    if local.empty:
        st.warning("No local news is available yet, so there is nothing to place on the map. Once the app is online the feeds "
                   "are read live, and the daily refresh keeps a history so the slider can go back in time.")
        local = pd.DataFrame(columns=list(nw.columns) if len(nw.columns) else
                             ["published", "title", "publisher", "link", "summary", "language", "section", "commodities",
                              "states", "districts", "themes", "evidence"])
        local["published"] = pd.to_datetime(local["published"])
    local["day"] = local["published"].dt.normalize()
    today = pd.Timestamp.now(tz="Asia/Kolkata").tz_localize(None).normalize()
    first = min(local["day"].min() if len(local) else today, today - pd.Timedelta(days=29))
    first = max(first, today - pd.Timedelta(days=400))
    a, b, c = st.columns([4, 1, 2])
    fmt = lambda d: f"{pd.Timestamp(d):%d %b %Y}"
    picked = a.slider("Date (the slider always ends at today)", min_value=first.date(), max_value=today.date(), value=today.date(),
                      format="DD MMM YYYY", key=f"nm_day_{today:%Y%m%d}")
    day = pd.Timestamp(picked)
    span = b.selectbox("Show", ["That day", "3 days to date", "7 days to date"], key="nm_span")
    back = {"That day": 0, "3 days to date": 2, "7 days to date": 6}[span]
    sel = local[(local["day"] <= day) & (local["day"] >= day - pd.Timedelta(days=back))]
    week = local[(local["day"] <= day) & (local["day"] >= day - pd.Timedelta(days=6))]
    coms = sorted({x for v in sel["commodities"] for x in v.split(", ") if x})
    fc = c.multiselect("Commodity", coms, key="nm_com")
    if fc:
        sel = sel[sel["commodities"].apply(lambda v: any(x in v.split(", ") for x in fc))]
    approx = st.checkbox("Also place regional-language articles that name no place at the centre of that language's home state (approximate)", key="nm_lang")
    pts = ui.news_points(sel, approx)
    k = st.columns(4)
    k[0].metric("Articles", len(sel)); k[1].metric("Placed on the map", pts["link"].nunique() if len(pts) else 0)
    k[2].metric("Places", pts["place"].nunique() if len(pts) else 0)
    k[3].metric("No place identified", len(sel) - (pts["link"].nunique() if len(pts) else 0))

    left, right = st.columns([3, 2])
    chosen = None
    with left:
        if sel.empty:
            has = sorted(local["day"].unique())
            st.info(f"No articles were retrieved for {fmt(day)}" + (f" or the {back} days before" if back else "") + ". "
                    + (f"Days with news: {fmt(has[0])} to {fmt(has[-1])}." if has else ""))
        elif pts.empty:
            st.info("None of the articles for this selection names a state or district, so there are no pointers. They are listed on the right.")
        else:
            first = lambda s: s.iloc[0]
            g = pts.groupby(["place", "state", "precision", "lon", "lat"]).agg(
                articles=("link", "nunique"),
                commodity=("commodities", lambda s: pd.Series([x for v in s for x in v.split(", ") if x] or ["Unspecified"]).mode().iat[0]),
                themes=("themes", lambda s: ", ".join(sorted({x for v in s for x in v.split(", ") if x})) or "—"),
                headline=("title", first)).reset_index()
            g["headline"] = g["headline"].str.slice(0, 90)
            fig = px.scatter_map(g, lat="lat", lon="lon", size="articles", color="commodity", size_max=26,
                                 custom_data=["place", "commodity", "state"], map_style="white-bg",
                                 center={"lat": 22.5, "lon": 82.5}, zoom=2.9 if ui.is_mobile() else 3.55, labels={"commodity": "Main commodity"})
            fig.update_traces(hovertemplate="<b>%{customdata[1]}</b><br>%{customdata[2]}<extra></extra>")
            fig.update_traces(marker=dict(opacity=0.8, sizemin=7))
            fig.update_layout(height=380 if ui.is_mobile() else 620, margin=dict(l=0, r=0, t=0, b=0), legend=dict(orientation="h", y=1.04),
                              map_layers=[{"sourcetype": "geojson", "source": ui.geo("states"), "type": "fill", "below": "traces", "color": "#f1f3f6"},
                                          {"sourcetype": "geojson", "source": ui.geo("states"), "type": "line", "below": "traces",
                                           "color": "#8f99a6", "line": {"width": 0.8}}])
            ev = st.plotly_chart(fig, use_container_width=True, on_select="rerun", selection_mode="points", key="nm_map")
            hit = (ev or {}).get("selection", {}).get("points", [])
            if hit and hit[0].get("customdata"):
                chosen = hit[0]["customdata"][0]
            st.caption("Pointer size = number of articles; colour = most-mentioned commodity at that place. Click a pointer to list its articles.")
    with right:
        opts = ["All places"] + (sorted(pts["place"].unique()) if len(pts) else [])
        place = st.selectbox("Place", opts, index=opts.index(chosen) if chosen in opts else 0, key=f"nm_place_{chosen}")
        show = sel if place == "All places" else sel[sel["link"].isin(pts[pts["place"] == place]["link"])]
        st.markdown(f"**{len(show)} article(s)** — {fmt(day)}" + (f" and the {back} days before" if back else ""))
        with st.container(height=560):
            ui.news_cards(show.sort_values("published", ascending=False), 60)
    with ui.card("Download weekly update"):
        wk_start = day - pd.Timedelta(days=6)
        if fc:
            week = week[week["commodities"].apply(lambda v: any(x in v.split(", ") for x in fc))]
        x, y, z = st.columns([2, 1, 2])
        x.caption(f"News for the 7 days ending on the slider date: **{fmt(wk_start)} to {fmt(day)}** ({len(week)} articles"
                  + (f", {', '.join(fc)} only" if fc else "") + "). Move the slider to download an earlier week.")
        kinds = {"PDF": ("pdf", "application/pdf", reports.to_pdf),
                 "Word (.docx)": ("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", reports.to_docx),
                 "Excel (.xlsx)": ("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", None)}
        kind = y.selectbox("Format", list(kinds), key="nm_fmt")
        ext, mime, render = kinds[kind]
        wpts = ui.news_points(week, approx)
        rep = reports.news_digest(week, wpts, wk_start, day)
        cols = ["published", "title", "publisher", "language", "commodities", "states", "districts", "themes", "evidence", "link"]
        data = render(rep) if render else reports.to_xlsx(rep, {"All articles": week[cols].assign(published=week["published"].dt.strftime("%Y-%m-%d %H:%M"))})
        z.download_button("⬇️  Download Weekly News Update", data, file_name=f"weekly_news_update_{day:%Y-%m-%d}.{ext}", mime=mime,
                          type="primary", use_container_width=True, key="nm_weekly")
        src = pts if len(pts) else sel
        out = src[[c for c in ["published", "place", "state", "precision", "title", "publisher", "language",
                               "commodities", "themes", "evidence", "link"] if c in src.columns]]
        ui.download(out, f"news_map_{day:%Y-%m-%d}.csv", "Download this view (CSV)")
