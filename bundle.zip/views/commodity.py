"""Page 3 - Commodity Explorer: history, comparisons, seasonality."""
import pandas as pd
import plotly.express as px
import streamlit as st
from fci import analytics as A, ui


def page():
    ctx = st.session_state["ctx"]
    d = ctx["df"]
    d = d[d["quality"] == "OK"]
    st.title("Commodity Explorer")
    ui.sample_banner(d)
    if d.empty:
        st.info("No data for the current filters."); return
    a, b, c, e = st.columns([2, 1, 2, 2])
    com = a.selectbox("Commodity", sorted(d["commodity"].unique()), key="ce_com")
    s = d[d["commodity"] == com]
    mt = b.selectbox("Market type", sorted(s["market_type"].unique()), key="ce_mt")
    s = s[s["market_type"] == mt]
    var = c.multiselect("Variety", sorted(v for v in s["variety"].unique() if v), key="ce_var")
    s = s[s["variety"].isin(var)] if var else s
    lo, hi = s["date"].min().date(), s["date"].max().date()
    rng = e.date_input("Date range", (lo, hi), min_value=lo, max_value=hi, key="ce_rng")
    if isinstance(rng, tuple) and len(rng) == 2:
        s = s[(s["date"] >= pd.Timestamp(rng[0])) & (s["date"] <= pd.Timestamp(rng[1]))]
    nat, man = s[s["level"] == "national"], s[s["level"] != "national"]

    with ui.card(f"{com} — {mt.lower()} price history"):
        parts = []
        if len(nat):
            parts.append(nat.groupby(["date", "unit"])["modal_price"].mean().reset_index().assign(series="All-India retail", markets=pd.NA).rename(columns={"modal_price": "price"}))
        if len(man):
            by = st.radio("Mandi series by", ["All reporting mandis", "State"], horizontal=True, key="ce_by")
            t = A.trend(man, ["unit"] + (["state"] if by == "State" else []))
            t["series"] = t["state"] if by == "State" else "Median of reporting mandis"
            parts.append(t)
        allp = pd.concat(parts, ignore_index=True)
        for unit, g in allp.groupby("unit"):
            fig = px.line(g.sort_values("date"), x="date", y="price", color="series", hover_data=["markets"],
                          labels={"price": unit, "date": "", "series": ""})
            fig.update_layout(height=380, margin=dict(l=0, r=0, t=10, b=0), hovermode="x unified", legend=dict(orientation="h", y=1.12))
            st.plotly_chart(fig, use_container_width=True)
        st.caption("Retail and wholesale series, and series in different units, are never mixed on one axis. The mandi line is the "
                   "median modal price of the markets reporting that day (hover for the market count) — it is not an official index.")

        x, y = st.columns(2)
        with x:
            st.subheader("Monthly averages")
            base = nat if len(nat) else man
            mo = base.assign(month=base["date"].dt.to_period("M").dt.to_timestamp()).groupby("month").agg(
                avg=("modal_price", "mean"), low=("modal_price", "min"), high=("modal_price", "max"), days=("date", "nunique")).reset_index()
            mo["MoM %"] = mo["avg"].pct_change() * 100
            mo["month"] = mo["month"].dt.strftime("%b %Y")
            ui.show(ui.style_changes(mo.rename(columns={"month": "Month", "avg": "Average", "low": "Low", "high": "High", "days": "Reporting days"}),
                                          ["MoM %"]), hide_index=True, use_container_width=True, height=330)
            st.caption("Months with few reporting days (e.g. year-ago reference points only) are indicative.")
        with y:
            st.subheader("Compare commodities (index, first day = 100)")
            pool = d[(d["market_type"] == mt) & (d["level"] == ("national" if len(nat) else "mandi"))]
            others = st.multiselect("Add commodities", sorted(set(pool["commodity"]) - {com}), key="ce_cmp", max_selections=6)
            cp = pool[pool["commodity"].isin([com] + others)]
            if isinstance(rng, tuple) and len(rng) == 2:
                cp = cp[(cp["date"] >= pd.Timestamp(rng[0])) & (cp["date"] <= pd.Timestamp(rng[1]))]
            cp = cp.groupby(["date", "commodity"])["modal_price"].median().reset_index().sort_values("date")
            cp["index"] = cp.groupby("commodity")["modal_price"].transform(lambda v: 100 * v / v.iloc[0])
            fig = px.line(cp, x="date", y="index", color="commodity", labels={"index": "Index", "date": "", "commodity": ""})
            fig.update_layout(height=330, margin=dict(l=0, r=0, t=10, b=0), hovermode="x unified", legend=dict(orientation="h", y=1.15))
            st.plotly_chart(fig, use_container_width=True)

        if len(man):
            st.subheader("Mandi comparison — latest reporting day per mandi")
            last = man.sort_values("date").groupby(["state", "district", "market", "variety"]).tail(1)
            out = last[["state", "district", "market", "variety", "date", "min_price", "max_price", "modal_price", "arrivals", "unit"]].sort_values("modal_price", ascending=False)
            ui.show(out, hide_index=True, use_container_width=True, height=320)
            ui.download(out, f"{com}_mandi_latest.csv")
        with st.expander("Underlying observations"):
            raw = s[["date", "state", "district", "market", "commodity", "variety", "market_type", "min_price", "max_price", "modal_price", "unit", "arrivals"]].sort_values("date", ascending=False)
            ui.show(raw.head(5000), hide_index=True, use_container_width=True)
            ui.download(raw, f"{com}_{mt}_observations.csv")
