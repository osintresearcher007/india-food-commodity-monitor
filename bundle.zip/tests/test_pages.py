"""Smoke tests: every dashboard page renders on the bundled data without an exception (news feeds mocked offline)."""
import sys
from pathlib import Path
import pytest
from streamlit.testing.v1 import AppTest

ROOT = Path(__file__).resolve().parent.parent
PAGES = ["overview", "alerts", "commodity", "geography", "newsmap", "newsroom", "policy", "insights", "sources"]


def harness(name: str, root: str, with_news: bool):
    import sys
    sys.path.insert(0, root)
    import pandas as pd
    import streamlit as st
    from fci import ui
    from fci.sources import news as N
    import importlib
    if with_news:
        sys.path.insert(0, root + "/tests")
        from test_core import RSS
        N.fetch_many = lambda urls, section, timeout=20: (N.parse_feed(RSS, "en", section), [])
    else:
        N.fetch_many = lambda urls, section, timeout=20: ([], ["offline"])
    st.cache_data.clear()
    df = ui.prices()
    filtered, chosen = ui.sidebar_filters(df)
    st.session_state["ctx"] = {"all": df, "df": filtered, "filters": chosen}
    importlib.import_module(f"views.{name}").page()


@pytest.mark.parametrize("with_news", [True, False])
@pytest.mark.parametrize("name", PAGES)
def test_page_renders(name, with_news):
    at = AppTest.from_function(harness, args=(name, str(ROOT), with_news), default_timeout=180)
    at.run()
    assert not at.exception, [e.value for e in at.exception]
    assert len(at.title) == 1


def test_report_downloads_present():
    at = AppTest.from_function(harness, args=("insights", str(ROOT), True), default_timeout=180)
    at.run()
    assert not at.exception
    labels = [b.label for b in at.get("download_button")]
    assert any("Download Weekly Insights" in x for x in labels) and any("Download Monthly Insights" in x for x in labels)


def test_news_map_slider_ends_today_and_weekly_download():
    import pandas as pd
    at = AppTest.from_function(harness, args=("newsmap", str(ROOT), True), default_timeout=180)
    at.run()
    assert not at.exception, [e.value for e in at.exception]
    today = pd.Timestamp.now(tz="Asia/Kolkata").date()
    sl = at.slider[0]
    as_date = lambda v: v if hasattr(v, "year") else pd.Timestamp(v, unit="us").date()  # AppTest reports microseconds
    assert as_date(sl.max) == today and as_date(sl.value) == today and (today - as_date(sl.min)).days >= 29
    assert any("Download Weekly News Update" in b.label for b in at.get("download_button"))
