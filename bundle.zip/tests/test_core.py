"""Unit tests: price calculations, date handling, aggregation, alert thresholds, uploads, news parsing, reports."""
import io
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from fci import analytics as A, daily, reports, signals, store  # noqa: E402
from fci.config import SCHEMA, classify_commodity, fix_text  # noqa: E402
from fci.sources import agmarknet, doca, necc, news, uploads  # noqa: E402


def make(rows):
    """rows: (date, state, district, market, commodity, price, arrivals)"""
    df = pd.DataFrame(rows, columns=["date", "state", "district", "market", "commodity", "modal_price", "arrivals"])
    df = df.assign(variety="", grade="", market_type="Wholesale", min_price=np.nan, max_price=np.nan, unit="Rs/Quintal",
                   source="test", level="mandi", is_sample=False)
    return store.quality_flags(store.add_taxonomy(store.standardise(df), {}))


def two_weeks(market, p_prev, p_cur, state="Maharashtra", district="Nashik", com="Onion", arr=(100, 100)):
    prev = [(f"2026-10-{d}", state, district, market, com, p_prev, arr[0]) for d in (26, 27, 28)]
    cur = [(f"2026-11-0{d}", state, district, market, com, p_cur, arr[1]) for d in (2, 3, 4)]
    return prev + cur + [("2026-11-08", state, district, market, com, p_cur, arr[1])]


# ---------- date handling
def test_week_starts_monday_and_month_start():
    d = pd.Series(pd.to_datetime(["2026-11-08", "2026-11-09", "2026-11-14"]))  # Sun, Mon, Sat
    assert list(A.period_start(d, "W").dt.strftime("%Y-%m-%d")) == ["2026-11-02", "2026-11-09", "2026-11-09"]
    assert list(A.period_start(d, "M").dt.day) == [1, 1, 1]


def test_complete_periods_only_by_default():
    p = A.comparison_periods("2026-11-14", "W")  # Saturday: week of 9 Nov is incomplete
    assert (p["cur"], p["prev"], p["provisional"]) == (pd.Timestamp("2026-11-02"), pd.Timestamp("2026-10-26"), False)
    p = A.comparison_periods("2026-11-15", "W")  # Sunday completes the week
    assert p["cur"] == pd.Timestamp("2026-11-09")
    p = A.comparison_periods("2026-11-14", "W", provisional=True)
    assert p["cur"] == pd.Timestamp("2026-11-09") and p["provisional"]
    m = A.comparison_periods("2026-11-14", "M")
    assert (m["cur"], m["prev"]) == (pd.Timestamp("2026-10-01"), pd.Timestamp("2026-09-01"))
    assert A.comparison_periods("2026-10-31", "M")["cur"] == pd.Timestamp("2026-10-01")


# ---------- price calculations and thresholds
def test_weekly_change_formula():
    r = A.run(make(two_weeks("Lasalgaon", 2000, 2150)), "W")["mandi"].iloc[0]
    assert r["change_pct"] == pytest.approx(7.5) and r["change_abs"] == pytest.approx(150)
    assert r["status"] == "Increase >5%" and r["confidence"] == "High"


@pytest.mark.parametrize("cur,expected", [(2100, "Within range"), (2100.5, "Increase >5%"), (1900, "Within range"), (1899, "Decrease >5%")])
def test_threshold_is_strict(cur, expected):
    assert A.run(make(two_weeks("M1", 2000, cur)), "W")["mandi"].iloc[0]["status"] == expected


def test_monthly_threshold_strict_10():
    assert A.status(10.0, 10) == "Within range" and A.status(10.01, 10) == "Increase >10%" and A.status(-10.01, 10) == "Decrease >10%"
    rows = [(f"2026-09-{d:02d}", "UP", "Agra", "Agra", "Potato", 1000, 50) for d in (5, 15, 25)]
    rows += [(f"2026-10-{d:02d}", "UP", "Agra", "Agra", "Potato", 880, 80) for d in (5, 15, 25)] + [("2026-10-31", "UP", "Agra", "Agra", "Potato", 880, 80)]
    r = A.run(make(rows), "M")["mandi"].iloc[0]
    assert r["change_pct"] == pytest.approx(-12.0) and r["status"] == "Decrease >10%"


# ---------- aggregation safeguards
def test_matched_markets_prevent_coverage_artifacts():
    rows = two_weeks("A", 2000, 2000)
    rows += [(f"2026-11-0{d}", "Maharashtra", "Nashik", "Expensive", "Onion", 4000, 100) for d in (2, 3, 4)]  # new market this week only
    out = A.run(make(rows), "W")
    assert len(out["mandi"]) == 1  # only the matched market is compared
    d = out["district"].iloc[0]
    assert d["change_pct"] == pytest.approx(0.0) and d["n_markets"] == 1 and d["confidence"] == "Low"


def test_arrival_weighted_vs_unweighted():
    rows = two_weeks("Big", 2000, 2200, arr=(900, 900)) + two_weeks("Small", 2000, 2000, arr=(100, 100))
    s = A.run(make(rows), "W")["state"].iloc[0]
    assert s["method"] == "Arrival-weighted mean" and s["change_pct"] == pytest.approx(9.0)  # (0.9*2200+0.1*2000)/2000
    rows = two_weeks("Big", 2000, 2200, arr=(np.nan, np.nan)) + two_weeks("Small", 2000, 2000, arr=(np.nan, np.nan))
    s = A.run(make(rows), "W")["state"].iloc[0]
    assert s["method"] == "Unweighted mean" and s["change_pct"] == pytest.approx(5.0) and s["status"] == "Within range"


def test_single_spike_is_not_a_state_alert_and_suspect_values_are_excluded():
    rows = sum((two_weeks(f"M{i}", 2000, 2010) for i in range(5)), []) + two_weeks("Spike", 2000, 2600)
    out = A.run(make(rows), "W")
    assert (out["mandi"]["status"] == "Increase >5%").sum() == 1
    st = out["state"].iloc[0]  # the mean crosses 5% only because of one market -> labelled, not treated as broad
    assert st["confidence"] == "Concentrated" and st["median_change"] == pytest.approx(0.5)
    df = make(rows)
    assert signals.compute(df, out, A.run(df, "M")).iloc[0]["states_beyond_threshold"] == 0
    rows = two_weeks("Typo", 2000, 3400) + two_weeks("OK", 2000, 2020)
    out = A.run(make(rows), "W")
    assert "Check data" in set(out["mandi"]["confidence"])
    assert out["state"].iloc[0]["change_pct"] == pytest.approx(1.0)  # the suspect series is left out


def test_state_pressure_score():
    rows = two_weeks("A", 2000, 2200) + two_weeks("B", 2000, 2000) + two_weeks("C", 1000, 1000, state="Punjab", district="Ludhiana")
    p = A.state_pressure(A.run(make(rows), "W")["mandi"], "W").set_index("state")
    assert p.loc["Maharashtra", "score"] == pytest.approx(50.0) and p.loc["Punjab", "score"] == 0


def test_quality_flags_and_dedupe():
    df = make([("2026-11-02", "S", "D", "M", "Onion", 2000, 1), ("2026-11-03", "S", "D", "M", "Onion", 0, 1),
               ("2026-11-04", "S", "D", "M", "Onion", 2000000, 1), ("2026-11-02", "S", "D", "M", "Onion", 2000, 1)])
    assert (df["quality"] != "OK").sum() == 2
    assert store.dedupe(df)[1] == 1


def test_alert_table_columns():
    df = make(two_weeks("A", 2000, 2200))
    t = A.display_alerts(A.alert_table(A.run(df, "W"), A.run(df, "M"), "mandi"))
    for c in ["Commodity", "State", "District", "Mandi", "Current price", "Previous price", "Weekly change %", "Monthly change %", "Source", "Alert status"]:
        assert c in t.columns
    assert t.iloc[0]["Alert status"].startswith("Weekly increase")


# ---------- taxonomy
def test_commodity_classification():
    assert classify_commodity("Arhar (Tur/Red Gram)(Whole)")[0] == "Tur/Arhar (Whole)"
    assert classify_commodity("Tur/Arhar Dal")[:2] == ("Tur/Arhar Dal", "Pulses")
    assert classify_commodity("Mustard Oil (Packed)")[1] == "Edible oils" and classify_commodity("Mustard")[1] == "Oilseeds"
    assert classify_commodity("Onion")[2] == "High" and classify_commodity("Turmeric (powder)")[2] == "Low"
    assert classify_commodity("Onion", {"priority": {"Onion": "Low"}})[2] == "Low"
    assert fix_text("Milk (â\x82¹/ltr)") == "Milk (₹/ltr)"


# ---------- uploads
def test_doca_workbook_parse():
    buf = io.BytesIO()
    with pd.ExcelWriter(buf) as xw:
        pd.DataFrame({"Commodities": ["Rice", "Ginger"], "Unit": ["1 Kg", "250 gm"], "13/11/2026": ["49.2", "30"], "13/11/2025": ["42", "0"]}).to_excel(xw, "Retail Prices", index=False)
        pd.DataFrame({"Commodities": ["Rice"], "Unit": ["100 Kg"], "13/11/2026": ["4400"], "13/11/2025": ["3900"]}).to_excel(xw, "Wholesale Prices", index=False)
        pd.DataFrame({"Field": ["Source URL"], "Value": ["x"]}).to_excel(xw, "Metadata", index=False)
    df, rep = uploads.parse_upload("2026-11-14.xlsx", buf.getvalue())
    assert rep[0]["format"].startswith("DoCA") and len(df) == 5  # the zero (not reported) is dropped
    assert set(df["market_type"]) == {"Retail", "Wholesale"} and set(df["level"]) == {"national"}
    assert df[df["market_type"] == "Wholesale"]["unit"].iat[0] == "Rs/100 Kg"


def test_generic_mandi_csv_detection():
    csv = ("State,District Name,Market Name,Commodity,Variety,Grade,Min Price (Rs./Quintal),Max Price (Rs./Quintal),"
           "Modal Price (Rs./Quintal),Arrivals (Tonnes),Price Date\n"
           "MAHARASHTRA,Nashik,Lasalgaon APMC,Onion,Red,FAQ,1500,2500,\"2,100\",350.5,13-11-2026\n"
           "MAHARASHTRA,Nashik,Lasalgaon APMC,Onion,Red,FAQ,1500,2500,\"2,100\",350.5,13-11-2026\n")
    df, rep = uploads.parse_upload("agmark.csv", csv.encode())
    r = store.standardise(df).iloc[0]
    assert (r["state"], r["district"], r["modal_price"], r["arrivals"], r["unit"]) == ("Maharashtra", "Nashik", 2100, 350.5, "Rs/Quintal")
    assert r["date"] == pd.Timestamp("2026-11-13") and r["market_type"] == "Wholesale" and r["level"] == "mandi"
    assert store.dedupe(store.standardise(df))[1] == 1


def test_retail_file_and_title_rows():
    buf = io.BytesIO()
    raw = pd.DataFrame([["Retail price bulletin", None, None, None], ["Date", "Centre", "Item", "Price per kg"],
                        ["01/11/2026", "Patna", "Potato", 24], ["02/11/2026", "Patna", "Potato", 25]])
    raw.to_excel(buf, index=False, header=False)
    df, rep = uploads.parse_upload("retail_bulletin.xlsx", buf.getvalue())
    assert len(df) == 2 and set(df["market_type"]) == {"Retail"} and set(df["unit"]) == {"Rs/Kg"}
    assert df["date"].max() == pd.Timestamp("2026-11-02")


# ---------- news
RSS = """<?xml version="1.0"?><rss version="2.0"><channel><title>t</title>
<item><title>Onion prices surge in Nashik as arrivals fall - Lokmat</title><link>http://a/1</link><pubDate>Thu, 12 Nov 2026 05:00:00 GMT</pubDate><source url="http://l">Lokmat</source></item>
<item><title>Onion prices surge in Nashik as arrivals fall - Other Wire</title><link>http://a/2</link><pubDate>Thu, 12 Nov 2026 09:00:00 GMT</pubDate><source url="http://o">Other Wire</source></item>
<item><title>Traders accused of hoarding tur dal; raids in Kalaburagi - Daily</title><link>http://a/3</link><pubDate>Wed, 11 Nov 2026 05:00:00 GMT</pubDate><source url="http://d">Daily</source></item>
<item><title>प्याज के दाम बढ़े, मंडी में आवक घटी - Hindi Daily</title><link>http://a/4</link><pubDate>Wed, 11 Nov 2026 05:00:00 GMT</pubDate><source url="http://h">Hindi Daily</source></item>
<item><title>Government cuts import duty on crude palm oil, notification issued - PIB</title><link>http://a/5</link><pubDate>Tue, 10 Nov 2026 05:00:00 GMT</pubDate><source url="http://p">PIB</source></item>
<item><title>Indonesia raises palm oil export levy - Reuters</title><link>http://a/6</link><pubDate>Tue, 10 Nov 2026 05:00:00 GMT</pubDate><source url="http://r">Reuters</source></item>
</channel></rss>"""


def test_news_parse_classify_dedupe():
    items = news.parse_feed(RSS, "en", "Local")
    df = news.classify(items, {"states": ["Maharashtra", "Karnataka"], "districts": {"Nashik": "Maharashtra", "Kalaburagi": "Karnataka"}})
    assert len(df) == 5  # the syndicated duplicate is removed
    on = df[df["title"].str.startswith("Onion")].iloc[0]
    assert on["publisher"] == "Lokmat" and "Onion" in on["commodities"] and on["states"] == "Maharashtra" and on["districts"] == "Nashik"
    assert "Price increase" in on["themes"] and "Shortage" in on["themes"]
    h = df[df["title"].str.contains("hoarding")].iloc[0]
    assert "Hoarding" in h["themes"] and h["evidence"].startswith("Media allegation") and "Pulses" in h["commodities"]
    assert "Onion" in df[df["title"].str.contains("प्याज")].iloc[0]["commodities"]


def test_policy_and_international_rules():
    df = news.classify(news.parse_feed(RSS, "en", "Policy"))
    p = news.policy_view(df)
    duty = p[p["title"].str.contains("import duty")].iloc[0]
    assert duty["status"] == "Notified" and duty["implication"] == "Downward" and "landed cost" in duty["mechanism"]
    x = news.intl_view(news.classify(news.parse_feed(RSS, "en", "International")))
    levy = x[x["title"].str.contains("Indonesia")].iloc[0]
    assert levy["commodity"] == "Edible oils" and levy["direction"].startswith("Upward") and "import" in levy["exposure"]
    assert "when:10d" in news.gn_url("onion", "en").replace("%3A", ":") and "ceid=IN:ta" in news.regional_queries(["ta"])[0][0]


# ---------- signals and reports
def scenario():
    rows = []
    for st_, dist in [("Maharashtra", "Nashik"), ("Madhya Pradesh", "Indore"), ("Karnataka", "Kolar")]:
        for i in range(2):
            rows += two_weeks(f"{dist}{i}", 2000, 2240, st_, dist, "Onion", arr=(200, 150))
    rows += two_weeks("Agra", 1500, 1380, "Uttar Pradesh", "Agra", "Potato", arr=(100, 140))
    rows += two_weeks("Khanna", 2600, 2610, "Punjab", "Ludhiana", "Wheat")
    return make(rows)


def test_signal_scoring_patterns():
    df = scenario()
    nw = news.classify(news.parse_feed(RSS, "en", "Local"))
    s = signals.compute(df, A.run(df, "W"), A.run(df, "M"), nw).set_index("commodity")
    assert s.loc["Onion", "pattern"].startswith("Possible supply stress") and s.loc["Onion", "signal"] in ("Elevated", "Significant")
    assert s.loc["Onion", "states_beyond_threshold"] == 3 and s.loc["Onion", "pts_arrivals"] == 10
    assert s.loc["Potato", "pattern"].startswith("Possible oversupply")
    assert s.loc["Wheat", "signal"] == "Normal"
    assert signals.label(19.9) == "Normal" and signals.label(20) == "Watch" and signals.label(40) == "Elevated" and signals.label(60) == "Significant"


@pytest.mark.parametrize("kind", ["weekly", "monthly"])
def test_reports_render_all_formats(kind):
    df = scenario()
    w, m = A.run(df, "W"), A.run(df, "M")
    nw = pd.concat([news.classify(news.parse_feed(RSS, "en", s)) for s in ("Local", "Policy", "International")])
    ctx = {"weekly": w, "monthly": m, "signals": signals.compute(df, w, m, nw), "news": nw, "policy": news.policy_view(nw),
           "intl": news.intl_view(nw), "length": "Standard", "sample": False, "filters": {"States": []}}
    rep = reports.build(kind, ctx)
    assert len(rep["sections"]) >= (9 if kind == "weekly" else 10)
    text = " ".join(p for s in rep["sections"] for p in s["paras"])
    assert "http://a/" in text
    if kind == "weekly":
        assert "Onion" in text and "+12.0%" in text and "Rs 2,240" in text
    else:
        assert "No mandi-level data is available for both months" in text
    assert reports.to_pdf(rep)[:4] == b"%PDF"
    assert reports.to_docx(rep)[:2] == b"PK" and reports.to_xlsx(rep)[:2] == b"PK"
    empty = {**ctx, "news": nw.head(0), "policy": nw.head(0), "intl": nw.head(0)}
    assert "No items retrieved" in " ".join(p for s in reports.build(kind, empty)["sections"] for p in s["paras"])


# ---------- live-page scrapers (fixtures copy the structure the sites served on 15 Nov 2026)
DOCA_HTML = """<html><body><form method="post" action="./Dailyprices.aspx"><div>
<table><tr><td>Date: 14/11/2026</td><td>All India Average Retail Price</td></tr></table>
<table border="1"><tr> <td rowspan="3"><b>Commodities</b></td> <td rowspan="3"><b>Unit</b></td><td colspan="3"><b>Daily Average Retail Price<br></b></td></tr>
<tr><td><b>Price As On</b></td><td><b>1 Day back </b></td><td><b>1 Year back </b></td></tr>
<tr><td>14/11/2026</td><td>13/11/2026</td><td>14/11/2025</td></tr>
<tr><td><b>Broken Rice</b></td><td>1 Kg</td><td>33.66</td><td>34.74</td><td>0</td></tr>
<tr><td><b>Rice</b></td><td>1 Kg</td><td>48.25</td><td>48.55</td><td>43.12</td></tr></table>
<table><tr><td>Date: 14/11/2026</td><td>All India Average Wholesale Price</td></tr></table>
<table border="1"><tr> <td rowspan="3"><b>Commodities</b></td> <td rowspan="3"><b>Unit</b></td><td colspan="3"><b>Daily Average Wholesale Price<br></b></td></tr>
<tr><td><b>Price As On</b></td><td><b>1 Day back </b></td><td><b>1 Year back </b></td></tr>
<tr><td>14/11/2026</td><td>13/11/2026</td><td>14/11/2025</td></tr>
<tr><td><b>Tomato</b></td><td>100 Kg</td><td>2977.69</td><td>3066.65</td><td>3206.68</td></tr></table>
<table><tr><td>Source:-  State Civil Supplies Deptt</td></tr></table></div></form></body></html>"""

NECC_HTML = """<html><body><form method="post"><select name="ddlMonth" id="ddlMonth"><option value="10">10</option>
<option selected="selected" value="11">11</option></select><select name="ddlYear"><option selected="selected" value="2026">2026</option></select>
<table><tr><td>x</td></tr></table>
<table><tr> <th>Name Of Zone / Day</th> <th>1</th><th>2</th><th>3</th> <th>Average</th> </tr>
<tr> <td colspan="302 ">NECC SUGGESTED EGG PRICES</td> </tr>
<tr> <td>Namakkal</td><td>610</td><td>620</td><td> - </td><td>615</td> </tr>
<tr> <td>Bengaluru (CC)</td><td>655</td><td> - </td><td> - </td><td>655</td> </tr>
<tr> <td colspan="302 ">Prevailing Prices</td> </tr>
<tr> <td>Luknow (CC)</td><td>673</td><td>677</td><td>677</td><td>675.67</td> </tr></table></form></body></html>"""


def test_doca_live_page_parse():
    df = doca.parse_html(DOCA_HTML)
    assert len(df) == 8  # 5 retail (one zero dropped) + 3 wholesale
    r = df[(df["commodity"] == "Rice") & (df["date"] == "2026-11-14")].iloc[0]
    assert (r["modal_price"], r["market_type"], r["unit"], r["level"]) == (48.25, "Retail", "Rs/Kg", "national")
    assert df[df["market_type"] == "Wholesale"]["unit"].iat[0] == "Rs/100 Kg"
    with pytest.raises(ValueError):
        doca.parse_html("<html><body><table><tr><td>Service unavailable</td></tr></table></body></html>")


def test_necc_page_parse():
    df = necc.parse_html(NECC_HTML, today="2026-11-15")
    assert len(df) == 6  # dashes are skipped and the Average column is not a day
    n = df[df["market"] == "Namakkal"]
    assert list(n["date"].dt.day) == [1, 2] and list(n["modal_price"]) == [610, 620]
    assert set(n["state"]) == {"Tamil Nadu"} and set(n["unit"]) == {"Rs/100 eggs"} and set(n["variety"]) == {"NECC suggested"}
    lk = df[df["market"] == "Luknow (CC)"].iloc[0]
    assert (lk["state"], lk["district"], lk["variety"]) == ("Uttar Pradesh", "Lucknow", "Prevailing")
    assert len(necc.parse_html(NECC_HTML, today="2026-11-02")) == 5  # nothing dated after 'today'
    assert classify_commodity("Egg")[0] == "Eggs"
    with pytest.raises(ValueError):
        necc.parse_html("<html><body><table><tr><td>Error</td></tr></table></body></html>")


def test_major_insights_of_the_day():
    df = scenario()
    nw = pd.concat([news.classify(news.parse_feed(RSS, "en", s), {"states": ["Maharashtra"], "districts": {"Nashik": "Maharashtra"}}) for s in ("Local", "Policy")])
    w, m = A.run(df, "W"), A.run(df, "M")
    pts = daily.daily_insights(df, w, m, signals.compute(df, w, m, nw), nw)
    assert 3 <= len(pts) <= 5
    text = " ".join(p["text"] for p in pts)
    assert "Onion" in text and "+12.0%" in text and "02 Nov" in text  # figures and dates are stated
    assert any(p["kind"] == "News" for p in pts) and "unverified" in text
    assert daily.daily_insights(df.head(0), A.run(df.head(0), "W"), A.run(df.head(0), "M")) == []


def test_weekly_news_digest_all_formats():
    pl = {"states": ["Maharashtra", "Karnataka"], "districts": {"Nashik": "Maharashtra", "Kalaburagi": "Karnataka"}}
    wk = news.classify(news.parse_feed(RSS, "en", "Local"), pl)
    pts = pd.DataFrame([{**r, "place": "Nashik", "state": "Maharashtra", "precision": "District"} for r in wk.head(1).to_dict("records")])
    rep = reports.news_digest(wk, pts, "2026-11-06", "2026-11-12")
    text = " ".join(p for s in rep["sections"] for p in s["paras"])
    assert "06 Nov 2026 to 12 Nov 2026" in rep["subtitle"] and f"{len(wk)} articles" in text
    assert "Nashik (Maharashtra)" in text and "http://a/3" in text and "unverified" in text
    assert reports.to_pdf(rep)[:4] == b"%PDF" and reports.to_docx(rep)[:2] == b"PK" and reports.to_xlsx(rep)[:2] == b"PK"
    empty = reports.news_digest(wk.head(0), pts.head(0), "2026-11-06", "2026-11-12")
    assert "No local commodity news was retrieved" in empty["sections"][0]["paras"][0] and reports.to_pdf(empty)[:4] == b"%PDF"


def test_agmarknet_monthly_parse_and_monthly_alerts():
    payload = {"success": True, "title": "Market-wise Wholesale Prices Monthly Analysis (All Districts) for Onion in Maharashtra - October, 2026",
               "rows": [{"market": "APMC Ahilyanagar ", "prices_october_2026": 2646.97, "prices_september_2026": 2844.3,
                         "prices_october_2025": 913.66, "change_over_previous_month": "-6.9", "change_over_previous_year": "189.7"},
                        {"market": "APMC Akole ", "prices_october_2026": 3436.66, "prices_september_2026": 3863.7,
                         "prices_october_2025": None, "change_over_previous_month": "-11.1", "change_over_previous_year": "-"}]}
    df = agmarknet.rows_to_frame(payload, "Onion", "Maharashtra", {"ahilyanagar": "Ahmednagar"})
    assert len(df) == 5 and set(df["market_type"]) == {"Wholesale"} and set(df["unit"]) == {"Rs/Quintal"}
    assert sorted(df["date"].dt.strftime("%Y-%m-%d").unique()) == ["2025-10-31", "2026-09-30", "2026-10-31"]
    assert df[df["market"] == "APMC Ahilyanagar"]["district"].iat[0] == "Ahmednagar"
    assert agmarknet.month_end("change_over_previous_month") is None and agmarknet.last_complete_month("2026-11-15") == (2026, 10)
    q = store.quality_flags(store.add_taxonomy(store.standardise(df), {}))
    m = A.run(q, "M")["mandi"].set_index("market")
    assert m.loc["Apmc Akole", "change_pct"] == pytest.approx(-11.05, abs=0.01) and m.loc["Apmc Akole", "status"] == "Decrease >10%"
    assert m.loc["Apmc Akole", "confidence"] == "High"  # a published monthly average counts as a full month
    assert A.run(q, "W")["mandi"].empty  # monthly averages never produce weekly comparisons


def test_agmarknet_fetch_month_with_fake_site_and_autoload(monkeypatch, tmp_path):
    class Resp:
        def __init__(self, js): self._js = js
        def raise_for_status(self): pass
        def json(self): return self._js

    class Fake:
        calls = 0
        def get(self, url, params=None, headers=None, timeout=None):
            Fake.calls += 1
            if url.endswith("dashboard-commodities-filter"):
                return Resp({"data": [{"id": 23, "cmdt_name": "Onion"}, {"id": 380, "cmdt_name": "Absinthe"}, {"id": 9999, "cmdt_name": "MSP Commodities"}]})
            if url.endswith("dashboard-filters/"):
                return Resp({"data": {"district_data": [{"id": 353, "state_id": 20, "district_name": "Nashik"}],
                                      "market_data": [{"id": 1, "mkt_name": "Lasalgaon APMC", "state_id": 20, "district_id": 353}]}})
            if url.endswith("price-trend/state-filter"):
                return Resp({"data": [{"state_id": 20, "state_name": "Maharashtra"}, {"state_id": 19, "state_name": "Madhya Pradesh"}]})
            if params["state"] == 19:
                raise ConnectionError("blocked")
            return Resp({"success": True, "rows": [{"market": "APMC Lasalgaon ", "prices_october_2026": 3000.0, "prices_september_2026": 2500.0}]})

    monkeypatch.setattr(agmarknet.time, "sleep", lambda s: None)
    df = agmarknet.fetch_month(2026, 10, session=Fake())
    assert len(df) == 2 and set(df["commodity"]) == {"Onion"} and set(df["district"]) == {"Nashik"}
    assert df.attrs["failed_requests"] == 1  # the failing state is reported, not fatal

    from fci import autoload
    monkeypatch.setattr(store, "MANDI_DIR", tmp_path / "mandi"); monkeypatch.setattr(store, "LOG", tmp_path / "log.csv")
    monkeypatch.setattr(autoload.agmarknet, "fetch_month", lambda y, m, log=None: df)
    monkeypatch.setattr(autoload.agmarknet, "last_complete_month", lambda today=None: (2026, 10))
    autoload.STATE.update(status="idle", detail="")
    assert autoload.start_if_needed()["status"] == "running"
    import threading
    [t.join(10) for t in threading.enumerate() if t.name == "agmarknet-autoload"]
    assert autoload.STATE["status"] == "done" and autoload._have(2026, 10)
    autoload.STATE.update(status="idle", detail="")
    assert autoload.start_if_needed()["status"] == "done"  # already stored -> no second download
    autoload.STATE.update(status="idle", detail="")
