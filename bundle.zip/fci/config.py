"""Central configuration: commodity taxonomy, priorities, thresholds, geography names."""
from __future__ import annotations
import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
USER_CONFIG = DATA / "user_config.json"

WEEKLY_THRESHOLD = 5.0    # % week-on-week, strict >
MONTHLY_THRESHOLD = 10.0  # % month-on-month, strict >
SUSPECT_CHANGE = 60.0     # |%| beyond which a change is flagged as a possible data-entry error
PRIORITY_WEIGHT = {"High": 3, "Medium": 2, "Low": 1}

SCHEMA = ["date", "state", "district", "market", "commodity", "variety", "grade", "market_type",
          "min_price", "max_price", "modal_price", "unit", "arrivals", "source", "level", "is_sample"]

# (regex on raw name, canonical commodity, group, default priority). First match wins.
COMMODITY_RULES = [
    (r"broken rice", "Broken Rice", "Rice", "High"),
    (r"paddy|dhan", "Paddy", "Rice", "High"),
    (r"\brice\b", "Rice", "Rice", "High"),
    (r"atta", "Atta (Wheat)", "Wheat", "High"),
    (r"maida", "Maida", "Wheat", "Medium"),
    (r"suji|sooji|rava", "Suji", "Wheat", "Medium"),
    (r"wheat", "Wheat", "Wheat", "High"),
    (r"egg", "Eggs", "Eggs", "High"),
    (r"palm ?oil|palmolein", "Palm Oil", "Edible oils", "High"),
    (r"soya ?(bean)? ?oil|soybean oil", "Soya Oil", "Edible oils", "High"),
    (r"sun ?flower ?oil", "Sunflower Oil", "Edible oils", "High"),
    (r"mustard ?oil", "Mustard Oil", "Edible oils", "High"),
    (r"ground ?nut ?oil", "Groundnut Oil", "Edible oils", "High"),
    (r"vanaspati", "Vanaspati", "Edible oils", "High"),
    (r"coconut oil|gingelly oil|sesam.* oil|rice bran oil", "Other Edible Oils", "Edible oils", "Medium"),
    (r"soya ?bean|soyabean", "Soybean", "Oilseeds", "High"),
    (r"mustard|rapeseed|sarson", "Mustard Seed", "Oilseeds", "High"),
    (r"ground ?nut", "Groundnut", "Oilseeds", "High"),
    (r"sun ?flower", "Sunflower Seed", "Oilseeds", "High"),
    (r"bharat dal", "Gram Dal (Bharat Dal adj.)", "Pulses", "Medium"),
    (r"besan", "Besan", "Pulses", "Medium"),
    (r"(tur|arhar).*dal|arhar dal|tur dal", "Tur/Arhar Dal", "Pulses", "High"),
    (r"arhar|\btur\b|red gram|pigeon", "Tur/Arhar (Whole)", "Pulses", "High"),
    (r"(urad|urd|black gram).*dal", "Urad Dal", "Pulses", "High"),
    (r"urad|\burd\b|black gram", "Urad (Whole)", "Pulses", "High"),
    (r"(moong|green gram).*dal", "Moong Dal", "Pulses", "High"),
    (r"moong|green gram", "Moong (Whole)", "Pulses", "High"),
    (r"(masoor|masur|lentil).*dal", "Masoor Dal", "Pulses", "High"),
    (r"masoor|masur|lentil", "Masoor (Whole)", "Pulses", "High"),
    (r"(gram|chana).*dal", "Gram Dal", "Pulses", "High"),
    (r"bengal gram|\bgram\b|chana|chick ?pea", "Chana (Whole)", "Pulses", "High"),
    (r"peas.*dry|yellow peas|rajma|cowpea|kulthi|horse gram|moth", "Other Pulses", "Pulses", "Medium"),
    (r"\bgur\b|jaggery", "Gur", "Sugar", "High"),
    (r"sugar", "Sugar", "Sugar", "High"),
    (r"onion", "Onion", "Vegetables", "High"),
    (r"potato", "Potato", "Vegetables", "High"),
    (r"tomato", "Tomato", "Vegetables", "High"),
    (r"brinjal", "Brinjal", "Other vegetables", "Medium"),
    (r"garlic", "Garlic", "Other vegetables", "Medium"),
    (r"ginger", "Ginger", "Other vegetables", "Medium"),
    (r"cabbage|cauliflower|bhindi|ladies finger|green chilli|carrot|peas|gourd|pumpkin|beans|capsicum|cucumber|raddish|radish",
     "{raw}", "Other vegetables", "Medium"),
    (r"maize|makka|corn", "Maize", "Maize & feed", "Medium"),
    (r"bajra|pearl millet", "Bajra", "Other foodgrains", "Medium"),
    (r"jowar|sorghum", "Jowar", "Other foodgrains", "Medium"),
    (r"ragi|finger millet", "Ragi", "Other foodgrains", "Medium"),
    (r"barley|\bjau\b", "Barley", "Other foodgrains", "Medium"),
    (r"milk", "Milk", "Dairy", "Medium"),
    (r"ghee", "Desi Ghee", "Dairy", "Medium"),
    (r"butter", "Butter", "Dairy", "Medium"),
    (r"banana", "Banana", "Fruits", "Medium"),
    (r"chill", "Red Chillies", "Spices", "Low"),
    (r"turmeric|haldi", "Turmeric", "Spices", "Low"),
    (r"cum+in|jeera", "Cumin", "Spices", "Low"),
    (r"cor+iander|dhania", "Coriander", "Spices", "Low"),
    (r"pepper", "Black Pepper", "Spices", "Low"),
    (r"cardamom", "Cardamom", "Spices", "Low"),
    (r"\btea\b", "Tea", "Other", "Low"),
    (r"salt", "Salt", "Other", "Low"),
]
GROUP_ORDER = ["Vegetables", "Rice", "Wheat", "Pulses", "Edible oils", "Oilseeds", "Sugar", "Eggs",
               "Maize & feed", "Other vegetables", "Other foodgrains", "Dairy", "Fruits", "Spices", "Other"]
HEADLINE = ["Onion", "Potato", "Tomato", "Rice", "Wheat", "Tur/Arhar Dal", "Gram Dal", "Urad Dal", "Moong Dal",
            "Masoor Dal", "Mustard Oil", "Palm Oil", "Soya Oil", "Sunflower Oil", "Sugar", "Eggs"]

STATE_ALIASES = {
    "nct of delhi": "Delhi", "delhi": "Delhi", "orissa": "Odisha", "uttrakhand": "Uttarakhand",
    "uttaranchal": "Uttarakhand", "pondicherry": "Puducherry", "chattisgarh": "Chhattisgarh",
    "jammu & kashmir": "Jammu and Kashmir", "jammu and kashmir": "Jammu and Kashmir",
    "andaman & nicobar": "Andaman and Nicobar", "andaman and nicobar islands": "Andaman and Nicobar",
    "dadra & nagar haveli": "Dadra and Nagar Haveli", "daman & diu": "Daman and Diu", "telengana": "Telangana",
    "tamilnadu": "Tamil Nadu", "west bangal": "West Bengal", "all india": "All India",
}


def fix_text(s) -> str:
    """Trim, collapse whitespace and repair UTF-8 text that was mis-decoded as Latin-1 (e.g. the rupee sign)."""
    s = "" if s is None else str(s)
    if "â" in s or "Ã" in s:
        try:
            s = s.encode("latin-1").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            s = re.sub(r"â\S{0,2}", "", s)
    return re.sub(r"\s+", " ", s).strip()


def load_user_config() -> dict:
    base = {"priority": {}, "exclude": [], "extra": []}  # extra: [{"pattern","name","group","priority"}]
    if USER_CONFIG.exists():
        try:
            base.update(json.loads(USER_CONFIG.read_text()))
        except json.JSONDecodeError:
            pass
    return base


def save_user_config(cfg: dict) -> None:
    USER_CONFIG.parent.mkdir(parents=True, exist_ok=True)
    USER_CONFIG.write_text(json.dumps(cfg, indent=2, ensure_ascii=False))


def classify_commodity(raw: str, cfg: dict | None = None) -> tuple[str, str, str]:
    """Return (canonical name, group, priority) for a raw commodity label."""
    cfg = cfg or {}
    name = fix_text(raw)
    low = re.sub(r"\(.*?/ltr\)", "", name.lower())
    rules = [(e["pattern"], e["name"], e.get("group", "Other"), e.get("priority", "Medium"))
             for e in cfg.get("extra", [])] + COMMODITY_RULES
    for pat, canon, group, prio in rules:
        if re.search(pat, low):
            canon = name.title() if canon == "{raw}" else canon
            return canon, group, cfg.get("priority", {}).get(canon, prio)
    return name, "Other", cfg.get("priority", {}).get(name, "Medium")


def norm_state(s: str) -> str:
    t = fix_text(s)
    return STATE_ALIASES.get(t.lower(), t.title() if t.isupper() or t.islower() else t)


def norm_place(s: str) -> str:
    t = re.sub(r"\s*\b(apmc|mandi|market yard|market|\(.*?\))\s*$", "", fix_text(s), flags=re.I).strip()
    return t.title() if t else ""
