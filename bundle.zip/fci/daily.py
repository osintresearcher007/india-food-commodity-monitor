"""'Major Insights of the Day': up to five rule-based points built only from stored prices and retrieved headlines.

Order of preference: (1) official all-India items beyond the weekly/monthly alert thresholds, (2) the largest
day-on-day all-India move, (3) the strongest centre/state-level move in mandi data, (4) the largest year-on-year
change, (5) what local news is reporting today, (6) the latest policy item. Every point carries its figures and dates.
"""
from __future__ import annotations
import pandas as pd
from . import analytics as A


def _rs(v: float) -> str:
    return f"Rs {v:,.2f}" if v < 1000 else f"Rs {v:,.0f}"


def daily_insights(df: pd.DataFrame, weekly: dict, monthly: dict, sig: pd.DataFrame | None = None,
                   news: pd.DataFrame | None = None, limit: int = 5) -> list[dict]:
    """Return [{'kind', 'text'}], at most `limit` items. Empty list when there is no data."""
    out: list[dict] = []
    add = lambda kind, text: out.append({"kind": kind, "text": text})
    nat = df[(df["level"] == "national") & (df["quality"] == "OK") & (df["priority"] == "High")]
    retail = nat[nat["market_type"] == "Retail"] if (nat["market_type"] == "Retail").any() else nat

    # 1. threshold breaches in official series
    for run, word in ((weekly, "week"), (monthly, "month")):
        t = run.get("official", pd.DataFrame())
        per = run.get("official_periods")
        if t is None or not len(t) or not per:
            continue
        t = t[(t["priority"] == "High") & (t["status"] != "Within range") & (t["confidence"] != "Check data")]
        if len(t):
            top = t.reindex(t["change_pct"].abs().sort_values(ascending=False).index).head(3)
            items = "; ".join(f"{r.commodity} ({r.market_type.lower()}) {r.change_pct:+.1f}% to {_rs(r.price_cur)}" for r in top.itertuples())
            add("Alert", f"All-India prices beyond the {run['threshold']:g}% {word}-on-{word} threshold "
                         f"({per['cur']:%d %b}–{per['cur_end']:%d %b %Y}): {items}.")
    if not out:
        per = weekly.get("official_periods")
        t = weekly.get("official", pd.DataFrame())
        if per and t is not None and len(t):
            h = t[t["priority"] == "High"]
            top = h.loc[h["change_pct"].abs().idxmax()]
            add("Stable", f"No high-priority all-India series moved more than {A.WEEKLY_THRESHOLD:g}% in the week "
                          f"{per['cur']:%d %b}–{per['cur_end']:%d %b %Y}. Largest move: {top['commodity']} "
                          f"({top['market_type'].lower()}) {top['change_pct']:+.1f}% to {_rs(top['price_cur'])} per {top['unit'].replace('Rs/', '')}.")

    # 2. day-on-day
    if len(retail):
        last = retail["date"].max()
        prev_days = retail[retail["date"] < last]["date"]
        if len(prev_days):
            prev = prev_days.max()
            a = retail[retail["date"] == last].set_index("commodity")["modal_price"]
            b = retail[retail["date"] == prev].set_index("commodity")["modal_price"]
            ch = (A.pct_change(a, b)).dropna()
            if len(ch):
                c = ch.abs().idxmax()
                gap = (last - prev).days
                add("Day", f"Largest day-on-day move in all-India retail prices on {last:%d %b %Y}: {c} {ch[c]:+.1f}% "
                           f"({_rs(b[c])} to {_rs(a[c])}"
                           + (f"; previous report {prev:%d %b}, {gap} days earlier" if gap > 1 else "") + "). "
                           f"{int((ch > 0).sum())} of {len(ch)} high-priority items rose, {int((ch < 0).sum())} fell.")

    # 3. centre / state level
    md, st = weekly.get("mandi", pd.DataFrame()), weekly.get("state", pd.DataFrame())
    per = weekly.get("mandi_periods")
    if md is not None and len(md) and per:
        sample = " (SAMPLE data)" if df[df["level"] != "national"]["is_sample"].any() else ""
        ok = md[md["confidence"].isin(["High", "Medium"])]
        hit = ok[ok["status"] != "Within range"]
        if len(hit):
            r = hit.loc[hit["change_pct"].abs().idxmax()]
            ns = st[(st["status"] != "Within range") & (st["confidence"] != "Concentrated")]["state"].nunique() if len(st) else 0
            add("Local", f"Market level{sample}, week {per['cur']:%d %b}–{per['cur_end']:%d %b}: {len(hit)} of {len(ok)} matched "
                         f"series moved more than {A.WEEKLY_THRESHOLD:g}%. Largest: {r['commodity']} at {r['market']}, {r['state']} "
                         f"{r['change_pct']:+.1f}% ({_rs(r['price_prev'])} to {_rs(r['price_cur'])} per {r['unit'].replace('Rs/', '')}). "
                         f"{ns} state average(s) crossed the threshold.")
        elif len(ok):
            r = ok.loc[ok["change_pct"].abs().idxmax()]
            add("Local", f"Market level{sample}, week {per['cur']:%d %b}–{per['cur_end']:%d %b}: none of {len(ok)} matched series "
                         f"moved more than {A.WEEKLY_THRESHOLD:g}%. Largest: {r['commodity']} at {r['market']}, {r['state']} {r['change_pct']:+.1f}%.")

    mm, perm = monthly.get("mandi", pd.DataFrame()), monthly.get("mandi_periods")
    if mm is not None and len(mm) and perm:
        okm = mm[mm["confidence"].isin(["High", "Medium"])]
        up, dn = okm[okm["status"].str.startswith("Inc")], okm[okm["status"].str.startswith("Dec")]
        if len(okm):
            sm = monthly.get("state", pd.DataFrame())
            sm = sm[(sm["status"] != "Within range") & (sm["confidence"].isin(["High", "Medium"]))] if len(sm) else sm
            top = sm.reindex(sm["change_pct"].abs().sort_values(ascending=False).index).head(3) if len(sm) else sm
            add("Mandi", f"Wholesale mandi prices, {perm['cur']:%B %Y} against {perm['prev']:%B %Y}: {len(up)} of {len(okm)} market series "
                         f"rose more than {A.MONTHLY_THRESHOLD:g}% and {len(dn)} fell more than {A.MONTHLY_THRESHOLD:g}%."
                         + (" Largest state-level moves: " + "; ".join(f"{r.commodity} in {r.state} {r.change_pct:+.1f}% ({int(r.n_markets)} markets)"
                                                                       for r in top.itertuples()) + "." if len(top) else ""))

    # 4. year on year
    if len(retail):
        last = retail["date"].max()
        cur = retail[retail["date"] == last].set_index("commodity")["modal_price"]
        old = retail[(retail["date"] <= last - pd.Timedelta(days=358)) & (retail["date"] >= last - pd.Timedelta(days=372))]
        if len(old):
            base = old.sort_values("date").groupby("commodity")["modal_price"].last()
            yoy = A.pct_change(cur, base).dropna()
            if len(yoy):
                c = yoy.abs().idxmax()
                up = yoy[yoy > 10].sort_values(ascending=False)
                add("Year", f"Against a year ago, {c} retail is {yoy[c]:+.0f}% ({_rs(base[c])} to {_rs(cur[c])}). "
                            + (f"{len(up)} high-priority items are more than 10% higher than last year"
                               + (": " + ", ".join(f"{k} {v:+.0f}%" for k, v in up.head(4).items()) if len(up) else "") + "."))

    # 5. news of the latest day, 6. policy
    if news is not None and len(news):
        loc = news[(news["section"] == "Local") & news["published"].notna()]
        if len(loc):
            day = loc["published"].dt.normalize().max()
            today = loc[loc["published"].dt.normalize() == day]
            coms = today["commodities"].str.split(", ").explode().replace("", pd.NA).dropna().value_counts()
            states = today["states"].str.split(", ").explode().replace("", pd.NA).dropna().value_counts()
            hoard = int(today["themes"].str.contains("Hoarding").sum())
            short = int(today["themes"].str.contains("Shortage").sum())
            if len(coms):
                add("News", f"Local news on {day:%d %b %Y}: {len(today)} commodity reports; most covered "
                            + ", ".join(f"{k} ({v})" for k, v in coms.head(3).items())
                            + (("; most reports from " + ", ".join(f"{k} ({v})" for k, v in states.head(3).items())) if len(states) else "")
                            + f". {short} mention shortage or lower arrivals and {hoard} mention hoarding or enforcement (media reports, unverified).")
        pol = news[(news["section"] == "Policy") & news["published"].notna()].sort_values("published", ascending=False)
        if len(pol):
            r = pol.iloc[0]
            add("Policy", f"Latest policy item ({r['published']:%d %b %Y}, {r['publisher']}): {r['title']}.")

    if sig is not None and len(sig) and (sig["signal"] != "Normal").any() and len(out) < limit + 1:
        r = sig[sig["signal"] != "Normal"].iloc[0]
        out.insert(1, {"kind": "Signal", "text": f"Early-warning signal: {r['commodity']} is at {r['signal']} "
                       f"({r['score']:.0f}/100) — {r['pattern'].lower()}."})
    return out[:limit]
