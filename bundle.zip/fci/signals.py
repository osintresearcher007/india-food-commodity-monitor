"""Transparent rules-based early-warning score per commodity (0-100).

Points:  magnitude 25 (weekly change vs 10% or monthly vs 20%, whichever is larger)
         geographic spread 25 (share of reporting states moving beyond the threshold in the same direction)
         persistence 15 (consecutive weeks moving the same way, up to 4)
         reporting markets 10 (20+ markets 10, 5+ 6, 2+ 3; official all-India average only 5)
         arrivals 10 (arrivals moving >=5% against the price direction)
         supporting news 10 (2.5 per matching local item in the news window, max 4)
         policy / international 5 (2.5 per matching item, max 2)
Labels:  <20 Normal, 20-39 Watch, 40-59 Elevated, 60+ Significant. These are analytical indicators, not official findings.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from . import analytics as A

NEWS_TAG = {"Pulses": "Pulses", "Edible oils": "Edible oils", "Oilseeds": "Oilseeds", "Sugar": "Sugar", "Rice": "Rice",
            "Wheat": "Wheat", "Eggs": "Eggs", "Maize & feed": "Maize", "Spices": "Spices"}
UP_THEMES = ("Price increase", "Shortage", "Hoarding", "Weather")
DOWN_THEMES = ("Glut", "Farmer distress")


def label(score: float) -> str:
    return "Significant" if score >= 60 else "Elevated" if score >= 40 else "Watch" if score >= 20 else "Normal"


def news_for(news: pd.DataFrame, commodity: str, group: str) -> pd.DataFrame:
    if news is None or news.empty:
        return pd.DataFrame(columns=getattr(news, "columns", []))
    tag = commodity if commodity in ("Onion", "Tomato", "Potato") else NEWS_TAG.get(group, commodity)
    return news[news["commodities"].str.contains(tag, regex=False, na=False)]


def compute(df: pd.DataFrame, weekly: dict, monthly: dict, news: pd.DataFrame | None = None) -> pd.DataFrame:
    rows = []
    mandi = df[df["level"] != "national"]
    sp = A.series_periods(mandi, "W") if not mandi.empty else pd.DataFrame()
    spo = A.series_periods(df[(df["level"] == "national")], "W")
    items = df[["commodity", "group", "priority"]].drop_duplicates()
    for com, grp, prio in items.itertuples(index=False):
        def pick(run, level):
            t = run.get(level, pd.DataFrame())
            if t is None or t.empty:
                return None
            t = t[t["commodity"] == com]
            if t.empty:
                return None
            w = t[t["market_type"] == "Wholesale"]
            return (w if not w.empty else t).iloc[0]
        nw, nm = pick(weekly, "national"), pick(monthly, "national")
        basis = "Mandi aggregate"
        if nw is None and nm is None:
            nw, nm, basis = pick(weekly, "official"), pick(monthly, "official"), "Official all-India average"
        if nw is None and nm is None:
            continue
        cw = float(nw["change_pct"]) if nw is not None else np.nan
        cm = float(nm["change_pct"]) if nm is not None else np.nan
        lead = cw if not np.isnan(cw) and abs(cw) / 10 >= (abs(cm) / 20 if not np.isnan(cm) else 0) else cm
        direction = 1 if lead > 0 else -1
        magnitude = 25 * min(1.0, max(abs(np.nan_to_num(cw)) / 10, abs(np.nan_to_num(cm)) / 20))
        # spread across states
        st = weekly.get("state", pd.DataFrame())
        st = st[st["commodity"] == com] if st is not None and not st.empty else pd.DataFrame()
        n_states = len(st)
        st = st[st["confidence"] != "Concentrated"] if n_states else st
        hit = int(((st["change_pct"] * direction) > A.WEEKLY_THRESHOLD).sum()) if n_states else 0
        dist = weekly.get("district", pd.DataFrame())
        dist = dist[dist["commodity"] == com] if dist is not None and not dist.empty else pd.DataFrame()
        dist = dist[dist["confidence"] != "Concentrated"] if len(dist) else dist
        d_hit = int(((dist["change_pct"] * direction) > A.WEEKLY_THRESHOLD).sum()) if len(dist) else 0
        spread = 25 * (hit / n_states) if n_states else 0.0
        # persistence on weekly mean of matched-series prices
        src = sp[sp["commodity"] == com] if basis == "Mandi aggregate" and not sp.empty else spo[spo["commodity"] == com]
        per = weekly["mandi_periods" if basis == "Mandi aggregate" else "official_periods"]
        wk = src[src["period"] <= per["cur"]].groupby("period")["price"].median() if not src.empty else pd.Series(dtype=float)
        streak = A.persistence(wk) if len(wk) > 2 else 0
        persist = 15 * min(abs(streak), 4) / 4 if np.sign(streak) == direction else 0.0
        n_markets = int(nw["n_markets"]) if nw is not None and basis == "Mandi aggregate" else 0
        coverage = 5 if basis != "Mandi aggregate" else 10 if n_markets >= 20 else 6 if n_markets >= 5 else 3 if n_markets >= 2 else 0
        arr = float(nw["arrivals_change_pct"]) if nw is not None and "arrivals_change_pct" in nw and pd.notna(nw.get("arrivals_change_pct")) else np.nan
        arrivals = 10 if (not np.isnan(arr) and arr * direction <= -5) else 0
        nf = news_for(news, com, grp)
        themes = UP_THEMES if direction > 0 else DOWN_THEMES
        loc = nf[(nf["section"] == "Local") & nf["themes"].apply(lambda t: any(x in t for x in themes))] if len(nf) else nf
        ctx = nf[nf["section"] != "Local"] if len(nf) else nf
        news_pts, ctx_pts = min(10, 2.5 * len(loc)), min(5, 2.5 * len(ctx))
        score = magnitude + spread + persist + coverage + arrivals + news_pts + ctx_pts
        moved = max(abs(np.nan_to_num(cw)) / A.WEEKLY_THRESHOLD, abs(np.nan_to_num(cm)) / A.MONTHLY_THRESHOLD)
        if moved <= 0.5:
            pattern = "No notable movement"
        elif direction > 0 and (arrivals or len(loc)) and moved > 1:
            pattern = "Possible supply stress (price up" + (", arrivals down" if arrivals else "") + (", supporting reports" if len(loc) else "") + ")"
        elif direction < 0 and (arrivals or len(loc)) and moved > 1:
            pattern = "Possible oversupply (price down" + (", arrivals up" if arrivals else "") + (", supporting reports" if len(loc) else "") + ")"
        elif n_states >= 3 and hit / n_states >= 0.4:
            pattern = f"Broad-based {'increase' if direction > 0 else 'decline'} across states"
        elif hit or d_hit:
            pattern = f"Localised {'increase' if direction > 0 else 'decline'}"
        else:
            pattern = f"Moderate {'firming' if direction > 0 else 'easing'}"
        if moved <= 0.5:
            score = min(score, 19.0)  # no price signal -> never above Normal on context alone
        rows.append({"commodity": com, "group": grp, "priority": prio, "basis": basis, "weekly_change_pct": cw,
                     "monthly_change_pct": cm, "direction": "Up" if direction > 0 else "Down",
                     "states_reporting": n_states, "states_beyond_threshold": hit, "districts_beyond_threshold": d_hit,
                     "markets": n_markets, "weeks_same_direction": abs(streak) if np.sign(streak) == direction else 0,
                     "arrivals_change_pct": arr, "local_news": len(loc), "policy_intl_news": len(ctx),
                     "pts_magnitude": magnitude, "pts_spread": spread, "pts_persistence": persist,
                     "pts_markets": coverage, "pts_arrivals": arrivals, "pts_news": news_pts, "pts_context": ctx_pts,
                     "score": round(score, 1), "signal": label(score), "pattern": pattern})
    out = pd.DataFrame(rows)
    return out.sort_values("score", ascending=False).reset_index(drop=True) if len(out) else out
