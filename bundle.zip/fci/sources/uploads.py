"""Auto-detecting normaliser for uploaded CSV / XLS / XLSX / XLSM price files (macros are never executed)."""
from __future__ import annotations
import io, re
import pandas as pd
from ..config import SCHEMA, fix_text
from . import doca

SYN = {
    "date": ["arrival_date", "price_date", "reported_date", "report_date", "date", "day"],
    "state": ["state_name", "state"],
    "district": ["district_name", "district"],
    "market": ["market_name", "mandi_name", "mandi", "market", "apmc", "centre", "center", "city"],
    "commodity": ["commodity_name", "commodity", "item", "product", "crop"],
    "variety": ["variety"], "grade": ["grade"],
    "min_price": ["min_price", "minimum_price", "min"],
    "max_price": ["max_price", "maximum_price", "max"],
    "modal_price": ["modal_price", "modal", "average_price", "avg_price", "price", "rate"],
    "arrivals": ["arrivals_tonnes", "arrival_quantity", "arrivals", "arrival", "quantity", "qty"],
    "unit": ["unit_of_price", "price_unit", "unit"],
    "market_type": ["market_type", "price_type", "type"],
}


def _key(c) -> str:
    return re.sub(r"[^a-z0-9]+", "_", fix_text(c).lower()).strip("_")


def detect_columns(columns) -> dict:
    """Map canonical field -> source column using exact, then substring matches."""
    keyed = {_key(c): c for c in columns}
    found, used = {}, set()
    for field, names in SYN.items():
        for n in names:
            if n in keyed and keyed[n] not in used:
                found[field] = keyed[n]; break
        else:
            for n in names:
                hit = next((c for k, c in keyed.items() if n in k and c not in used
                            and not (field == "date" and "update" in k)), None)
                if hit is not None:
                    found[field] = hit; break
        if field in found:
            used.add(found[field])
    return found


def _market_type(text: str) -> str | None:
    t = text.lower()
    return "Retail" if "retail" in t else "Wholesale" if ("wholesale" in t or "mandi" in t) else None


def _unit(text: str) -> str | None:
    t = text.lower()
    if re.search(r"quintal|qtl|100 ?kg", t):
        return "Rs/Quintal"
    if re.search(r"per ?kg|/ ?kg|\bkg\b", t):
        return "Rs/Kg"
    if "dozen" in t:
        return "Rs/Dozen"
    if re.search(r"\b100 ?(eggs|nos)\b|per ?100", t):
        return "Rs/100 eggs"
    return None


def _header_row(df: pd.DataFrame) -> int:
    """Find the row that looks like a header (handles title rows above the table)."""
    for i in range(min(15, len(df))):
        cells = [_key(v) for v in df.iloc[i].tolist() if pd.notna(v)]
        if sum(any(n in c for n in ("commodity", "price", "market", "date", "state")) for c in cells) >= 2:
            return i
    return 0


def normalise_table(df: pd.DataFrame, hint: str = "") -> tuple[pd.DataFrame, dict]:
    """Normalise one long-format table. Returns (frame in SCHEMA, detection report)."""
    cols = detect_columns(df.columns)
    info = {"detected": {k: str(v) for k, v in cols.items()}, "hint": hint}
    if "commodity" not in cols or "date" not in cols or not ({"modal_price", "min_price", "max_price"} & set(cols)):
        info["error"] = "Could not find commodity, date and price columns"
        return pd.DataFrame(columns=SCHEMA), info
    g = lambda f: df[cols[f]] if f in cols else pd.Series(pd.NA, index=df.index)
    num = lambda f: pd.to_numeric(g(f).astype(str).str.replace(r"[^\d.\-]", "", regex=True), errors="coerce")
    modal = num("modal_price")
    if "modal_price" not in cols:
        modal = (num("min_price") + num("max_price")) / 2
        info["note"] = "No modal price column: midpoint of min and max used"
    dates = pd.to_datetime(g("date"), errors="coerce", dayfirst=True, format="mixed")
    header_text = " ".join(map(str, df.columns)) + " " + hint
    mtype = g("market_type").map(lambda v: _market_type(str(v))) if "market_type" in cols else None
    default_type = _market_type(header_text) or "Wholesale"
    unit = g("unit").map(lambda v: _unit(str(v))) if "unit" in cols else None
    default_unit = _unit(header_text) or ("Rs/Kg" if default_type == "Retail" else "Rs/Quintal")
    has_geo = "market" in cols or "district" in cols or "state" in cols
    out = pd.DataFrame({
        "date": dates, "state": g("state") if "state" in cols else ("All India" if not has_geo else ""),
        "district": g("district"), "market": g("market"), "commodity": g("commodity"),
        "variety": g("variety"), "grade": g("grade"),
        "market_type": mtype.fillna(default_type) if mtype is not None else default_type,
        "min_price": num("min_price"), "max_price": num("max_price"), "modal_price": modal,
        "unit": unit.fillna(default_unit) if unit is not None else default_unit, "arrivals": num("arrivals"),
        "source": f"Upload: {hint}" if hint else "Upload", "level": "mandi" if has_geo else "national",
        "is_sample": False})
    out = out.dropna(subset=["date", "commodity", "modal_price"])
    info.update(rows=len(out), market_type=default_type, unit=default_unit,
                date_range=f"{out['date'].min():%d %b %Y} to {out['date'].max():%d %b %Y}" if len(out) else "")
    return out[SCHEMA], info


def read_any(name: str, data: bytes) -> dict[str, pd.DataFrame]:
    """Read every sheet of a workbook, or a CSV, as raw string tables."""
    low = name.lower()
    if low.endswith((".csv", ".txt", ".tsv")):
        for enc in ("utf-8-sig", "latin-1"):
            try:
                return {"csv": pd.read_csv(io.BytesIO(data), dtype=str, sep=None, engine="python", encoding=enc)}
            except UnicodeDecodeError:
                continue
    engine = "xlrd" if low.endswith(".xls") else "openpyxl"  # openpyxl reads .xlsm values without running macros
    return pd.read_excel(io.BytesIO(data), sheet_name=None, dtype=str, engine=engine, header=None)


def parse_upload(name: str, data: bytes) -> tuple[pd.DataFrame, list[dict]]:
    """Parse one uploaded file. Returns (normalised rows, per-sheet detection reports)."""
    sheets = read_any(name, data)
    reports, frames = [], []
    if "csv" not in sheets:
        hdr = {s: (df.iloc[1:].set_axis(df.iloc[0].map(fix_text), axis=1) if len(df) else df) for s, df in sheets.items()}
        if doca.is_doca_workbook(hdr):
            out = doca.parse_sheets(hdr)
            return out, [{"sheet": "Retail + Wholesale", "format": "DoCA daily all-India report", "rows": len(out)}]
    for sname, df in sheets.items():
        if df.empty or re.search(r"meta|readme|notes", sname, re.I):
            continue
        if sname != "csv":
            h = _header_row(df)
            df = df.iloc[h + 1:].set_axis([fix_text(c) for c in df.iloc[h]], axis=1)
        out, info = normalise_table(df.dropna(how="all"), hint=f"{name} {'' if sname == 'csv' else sname}".strip())
        info["sheet"] = sname
        reports.append(info)
        frames.append(out)
    frames = [f for f in frames if not f.empty]
    return (pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=SCHEMA)), reports
