"""Illustrative mandi data for demonstrating the state / district / mandi views before real data is loaded.

Every row is flagged is_sample=True and sourced 'SAMPLE DATA (illustrative - not real prices)'. The app shows a
banner whenever sample rows are on screen, and sample rows are never written to the real mandi store.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from ..config import SCHEMA

SOURCE = "SAMPLE DATA (illustrative - not real prices)"
GEOG = {
    "Maharashtra": {"Nashik": ["Lasalgaon", "Pimpalgaon"], "Pune": ["Pune", "Junnar"], "Solapur": ["Solapur"]},
    "Madhya Pradesh": {"Indore": ["Indore"], "Ujjain": ["Ujjain"], "Sehore": ["Sehore", "Ashta"]},
    "Uttar Pradesh": {"Agra": ["Agra"], "Farrukhabad": ["Farrukhabad"], "Kanpur Nagar": ["Kanpur"], "Lucknow": ["Lucknow"]},
    "Karnataka": {"Kolar": ["Kolar"], "Bengaluru Urban": ["Yeshwanthpur"], "Belagavi": ["Belagavi"]},
    "West Bengal": {"Hooghly": ["Tarakeswar"], "Bardhaman": ["Burdwan"], "Kolkata": ["Posta"]},
    "Gujarat": {"Rajkot": ["Rajkot", "Gondal"], "Ahmedabad": ["Ahmedabad"]},
    "Rajasthan": {"Jaipur": ["Jaipur"], "Kota": ["Kota"], "Alwar": ["Alwar"]},
    "Punjab": {"Ludhiana": ["Khanna"], "Amritsar": ["Amritsar"]},
    "Andhra Pradesh": {"Kurnool": ["Kurnool"], "Chittoor": ["Madanapalle"]},
    "Tamil Nadu": {"Coimbatore": ["Coimbatore"], "Chennai": ["Koyambedu"]},
    "Bihar": {"Patna": ["Patna"], "Nalanda": ["Biharsharif"]},
    "Delhi": {"New Delhi": ["Azadpur"]},
}
BASE = {"Onion": 1900, "Potato": 1400, "Tomato": 2200, "Wheat": 2650, "Rice": 3700, "Soyabean": 4600,
        "Mustard": 6100, "Arhar (Tur/Red Gram)(Whole)": 7400, "Bengal Gram(Gram)(Whole)": 5900, "Maize": 2250}
# (commodity, states, weekly drift %, arrivals drift %) applied over the final four weeks
SCENARIOS = [("Onion", {"Maharashtra", "Madhya Pradesh", "Karnataka", "Gujarat"}, 7.5, -9.0),
             ("Potato", {"Uttar Pradesh", "West Bengal", "Bihar"}, -6.0, 8.0),
             ("Arhar (Tur/Red Gram)(Whole)", {"Maharashtra", "Karnataka"}, 3.0, -2.0)]


def generate(end_date, days: int = 84, seed: int = 7) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.date_range(end=pd.Timestamp(end_date).normalize(), periods=days, freq="D")
    rows = []
    for state, dists in GEOG.items():
        for dist, markets in dists.items():
            for mk in markets:
                for com, base in BASE.items():
                    if rng.random() < 0.25:
                        continue
                    level = base * rng.uniform(0.88, 1.12)
                    walk = np.cumsum(rng.normal(0, 0.006, days))
                    drift = np.zeros(days)
                    arr_drift = np.zeros(days)
                    for sc, states, wk, awk in SCENARIOS:
                        if sc == com and state in states:
                            ramp = np.clip(np.arange(days) - (days - 49), 0, None) / 7.0
                            drift, arr_drift = ramp * wk / 100, ramp * awk / 100
                    price = level * np.exp(walk + drift)
                    arr = rng.uniform(40, 400) * np.exp(rng.normal(0, 0.15, days) + arr_drift)
                    if com == "Tomato" and mk == "Kolar":
                        price[-6:] *= 1.45  # an isolated single-mandi spike
                    for d, p, a in zip(dates, price, arr):
                        if d.weekday() == 6 or rng.random() < 0.08:
                            continue  # closed days / non-reporting
                        m = round(float(p), -1)
                        rows.append((d, state, dist, mk, com, "Other", "FAQ", "Wholesale", round(m * 0.9, -1),
                                     round(m * 1.1, -1), m, "Rs/Quintal", round(float(a), 1), SOURCE, "mandi", True))
    return pd.DataFrame(rows, columns=SCHEMA)
