"""Adapter for AGMARKNET 2.0 (agmarknet.gov.in) market-wise wholesale prices, monthly analysis.

Public JSON API behind the page https://agmarknet.gov.in/marketallwholesalemonthanalysis (checked 15 Nov 2026):
  GET {API}price-trend/wholesale-prices-monthly?report_mode=MarketwiseAll&commodity=<id>&year=<y>&month=<m>&export=false&state=<id>
returns, for one commodity in one state, every market's average wholesale price (Rs/quintal) for that month, the
previous month and the same month a year earlier. Commodity ids come from dashboard-commodities-filter, the states
with data from price-trend/state-filter, and market -> district from dashboard-filters.
The site's DAILY market-wise reports require a CAPTCHA and are therefore not collected; these are monthly averages
and are used for month-on-month analysis only. They are WHOLESALE prices and are kept apart from retail series.
"""
from __future__ import annotations
import calendar, re, time
import pandas as pd
import requests
from ..config import SCHEMA

API = "https://api.agmarknet.gov.in/v1/"
SOURCE = "AGMARKNET monthly (agmarknet.gov.in)"
GRADE = "Monthly average"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36",
      "Accept": "application/json", "Origin": "https://agmarknet.gov.in", "Referer": "https://agmarknet.gov.in/"}
WANTED = re.compile(r"^(onion|potato|tomato|rice|wheat|maize|mustard|soyabean|groundnut|sunflower|garlic|sugar|mustard oil)$"
                    r"|arhar|bengal gram|green gram|black gram|lentil", re.I)
MONTHS = {m.lower(): i for i, m in enumerate(calendar.month_name) if m}


def _get(s, path: str, **params):
    r = s.get(API + path, params=params, headers=UA, timeout=60)
    r.raise_for_status()
    return r.json()


def _norm(name: str) -> str:
    return re.sub(r"[^a-z0-9]", "", str(name).lower().replace("apmc", ""))


def month_end(key: str) -> pd.Timestamp | None:
    """'prices_october_2026' -> 2026-10-31."""
    m = re.fullmatch(r"prices_([a-z]+)_(\d{4})", key)
    if not m or m.group(1) not in MONTHS:
        return None
    return pd.Timestamp(year=int(m.group(2)), month=MONTHS[m.group(1)], day=1) + pd.offsets.MonthEnd(0)


def rows_to_frame(payload: dict, commodity: str, state: str, districts: dict | None = None) -> pd.DataFrame:
    """Turn one API answer into SCHEMA rows (one per market and month). districts: normalised market name -> district."""
    out = []
    for row in payload.get("rows") or []:
        market = str(row.get("market", "")).strip()
        if not market:
            continue
        for key, val in row.items():
            d = month_end(key)
            price = pd.to_numeric(val, errors="coerce")
            if d is None or pd.isna(price) or price <= 0:
                continue
            out.append((d, state, (districts or {}).get(_norm(market), ""), market, commodity, "", GRADE, "Wholesale",
                        pd.NA, pd.NA, float(price), "Rs/Quintal", pd.NA, SOURCE, "mandi", False))
    return pd.DataFrame(out, columns=SCHEMA)


def lookups(s) -> tuple[dict, dict]:
    """(commodity name -> id for the wanted food commodities, state id -> {normalised market: district})."""
    coms = {c["cmdt_name"].strip(): c["id"] for c in _get(s, "dashboard-commodities-filter")["data"]
            if WANTED.search(c["cmdt_name"].strip()) and c["id"] < 9000}
    f = _get(s, "dashboard-filters/", dashboard_name="marketwise_price_arrival")["data"]
    dname = {d["id"]: d["district_name"] for d in f.get("district_data", [])}
    markets: dict = {}
    for m in f.get("market_data", []):
        if m.get("state_id") is not None:
            markets.setdefault(m["state_id"], {})[_norm(m["mkt_name"])] = dname.get(m.get("district_id"), "")
    return coms, markets


def fetch_month(year: int, month: int, session=None, pause: float = 0.25, log=None) -> pd.DataFrame:
    """All wanted commodities x all states with data, for one month (each answer also carries the previous month and
    the same month a year earlier). Individual failures are reported through `log` and skipped."""
    s = session or requests.Session()
    coms, markets = lookups(s)
    frames, fails = [], 0
    for cname, cid in sorted(coms.items()):
        try:
            states = _get(s, "price-trend/state-filter", commodity=cid)["data"]
        except Exception as e:
            fails += 1
            (log or print)(f"{cname}: state list failed ({type(e).__name__})")
            continue
        for st in states:
            try:
                js = _get(s, "price-trend/wholesale-prices-monthly", report_mode="MarketwiseAll", commodity=cid, year=year,
                          month=month, export="false", state=st["state_id"])
                if js.get("success"):
                    frames.append(rows_to_frame(js, cname, st["state_name"], markets.get(st["state_id"], {})))
            except Exception as e:
                fails += 1
                (log or print)(f"{cname} / {st.get('state_name')}: {type(e).__name__} {str(e)[:80]}")
            time.sleep(pause)
    if not frames:
        raise ValueError(f"AGMARKNET returned no data for {year}-{month:02d} ({fails} failed requests)")
    df = pd.concat(frames, ignore_index=True)
    df.attrs["failed_requests"] = fails
    return df


def last_complete_month(today=None) -> tuple[int, int]:
    t = (pd.Timestamp(today) if today is not None else pd.Timestamp.now(tz="Asia/Kolkata").tz_localize(None))
    p = t.replace(day=1) - pd.Timedelta(days=1)
    return p.year, p.month
