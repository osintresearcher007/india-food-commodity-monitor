"""Adapter for AGMARKNET daily mandi prices published on data.gov.in (Open Government Data platform).

Resources
- DAILY  9ef84268-d588-465a-a308-a864a43d0070  'Current daily price of various commodities from various markets'
  (today's/latest reports only - call it every day to build history).
- HIST   35985678-0d79-46b4-9ed6-6f13308a1d24  'Variety-wise daily market prices data of commodity'
  (supports filtering by date/state/commodity - used for back-filling).
A free API key is required: register at https://data.gov.in, open 'My Account' and copy the key into the
DATA_GOV_API_KEY secret. Prices are Rs/quintal wholesale. These resources do not carry arrival quantities.
NOTE: this adapter could not be called from the build environment (government hosts were not reachable from it);
field names are matched case-insensitively and any failure is reported in the refresh log, never hidden.
"""
from __future__ import annotations
import time
import pandas as pd
import requests
from ..config import SCHEMA

BASE = "https://api.data.gov.in/resource/"
DAILY = "9ef84268-d588-465a-a308-a864a43d0070"
HIST = "35985678-0d79-46b4-9ed6-6f13308a1d24"
SOURCE = "AGMARKNET via data.gov.in"


def records_to_frame(records: list[dict]) -> pd.DataFrame:
    if not records:
        return pd.DataFrame(columns=SCHEMA)
    raw = pd.DataFrame(records)
    raw.columns = [c.lower().strip().replace(" ", "_").replace("x0020_", "") for c in raw.columns]
    get = lambda *names: next((raw[n] for n in names if n in raw.columns), pd.Series(pd.NA, index=raw.index))
    df = pd.DataFrame({
        "date": pd.to_datetime(get("arrival_date", "date"), format="%d/%m/%Y", errors="coerce"),
        "state": get("state"), "district": get("district"), "market": get("market"),
        "commodity": get("commodity"), "variety": get("variety"), "grade": get("grade"),
        "market_type": "Wholesale", "min_price": get("min_price", "min_x0020_price"),
        "max_price": get("max_price"), "modal_price": get("modal_price"), "unit": "Rs/Quintal",
        "arrivals": get("arrivals", "arrival", "arrivals_tonnes"), "source": SOURCE, "level": "mandi",
        "is_sample": False})
    return df[SCHEMA]


def fetch(api_key: str, resource: str = DAILY, filters: dict | None = None, page: int = 1000,
          max_rows: int = 200_000, session=None, pause: float = 0.3) -> pd.DataFrame:
    """Page through a data.gov.in resource. Raises requests.HTTPError / ValueError on failure."""
    if not api_key:
        raise ValueError("DATA_GOV_API_KEY is not set")
    s = session or requests.Session()
    rows, offset = [], 0
    while offset < max_rows:
        params = {"api-key": api_key, "format": "json", "limit": page, "offset": offset}
        for k, v in (filters or {}).items():
            params[f"filters[{k}]"] = v
        r = s.get(BASE + resource, params=params, timeout=60)
        r.raise_for_status()
        js = r.json()
        if js.get("status") == "error" or "records" not in js:
            raise ValueError(f"data.gov.in error: {js.get('message', str(js)[:200])}")
        recs = js["records"]
        rows.extend(recs)
        if len(recs) < page:
            break
        offset += page
        time.sleep(pause)
    return records_to_frame(rows)


def fetch_day(api_key: str, day, session=None) -> pd.DataFrame:
    """Back-fill one date from the historical resource (dd/mm/yyyy filter)."""
    d = pd.Timestamp(day).strftime("%d/%m/%Y")
    return fetch(api_key, HIST, {"Arrival_Date": d}, session=session)
