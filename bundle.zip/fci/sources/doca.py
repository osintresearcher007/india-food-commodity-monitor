"""Adapter for Department of Consumer Affairs (Price Monitoring) all-India daily average price reports.

Input: the daily workbooks saved from https://fcainfoweb.nic.in/Reports/DB/Dailyprices.aspx with sheets
'Retail Prices' and 'Wholesale Prices' (rows = commodities, columns = dates). Each workbook carries the report
date, the previous days, the same day a month earlier and a year earlier; every dated column is kept.
These are national averages of reporting centres - they have no state, district or mandi detail.
"""
from __future__ import annotations
import io
import pandas as pd
from ..config import SCHEMA, fix_text

SOURCE = "DoCA Price Monitoring (fcainfoweb.nic.in)"


def is_doca_workbook(sheets: dict) -> bool:
    names = {s.lower() for s in sheets}
    return any("retail" in n for n in names) and any("wholesale" in n for n in names)


def parse_sheets(sheets: dict[str, pd.DataFrame]) -> pd.DataFrame:
    out = []
    for name, df in sheets.items():
        low = name.lower()
        mtype = "Retail" if "retail" in low else "Wholesale" if "wholesale" in low else None
        if mtype is None or df.shape[1] < 3:
            continue
        df = df.copy()
        df.columns = [fix_text(c) for c in df.columns]
        ccol, ucol = df.columns[0], df.columns[1]
        dates = {c: pd.to_datetime(c, format="%d/%m/%Y", errors="coerce") for c in df.columns[2:]}
        dcols = [c for c, d in dates.items() if pd.notna(d)]
        if not dcols:
            continue
        long = df.melt(id_vars=[ccol, ucol], value_vars=dcols, var_name="d", value_name="modal_price")
        long["date"] = long["d"].map(dates)
        long["modal_price"] = pd.to_numeric(long["modal_price"], errors="coerce")
        long = long[long["modal_price"] > 0]  # the portal prints 0 where no price was reported
        out.append(pd.DataFrame({
            "date": long["date"], "state": "All India", "district": "", "market": "",
            "commodity": long[ccol].map(fix_text), "variety": "", "grade": "", "market_type": mtype,
            "min_price": pd.NA, "max_price": pd.NA, "modal_price": long["modal_price"],
            "unit": long[ucol].map(lambda u: "Rs/" + fix_text(u).replace("1 ", "").replace("kg", "Kg")),
            "arrivals": pd.NA, "source": SOURCE, "level": "national", "is_sample": False}))
    if not out:
        return pd.DataFrame(columns=SCHEMA)
    return pd.concat(out, ignore_index=True)[SCHEMA]


def parse_file(file) -> pd.DataFrame:
    data = file if isinstance(file, (str, bytes)) or hasattr(file, "read") else str(file)
    if isinstance(data, bytes):
        data = io.BytesIO(data)
    sheets = pd.read_excel(data, sheet_name=None, dtype=str, engine="openpyxl")
    return parse_sheets(sheets)


URL = "https://fcainfoweb.nic.in/Reports/DB/Dailyprices.aspx"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36"}


def parse_html(html: str) -> pd.DataFrame:
    """Parse the live daily report page (structure verified on 15 Nov 2026): one table for retail, one for wholesale,
    each with header rows 'Commodities | Unit | Daily Average <Retail/Wholesale> Price', a row of dd/mm/yyyy dates,
    then one row per commodity."""
    import re
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "html.parser")
    sheets = {}
    for table in soup.find_all("table"):
        rows = [[c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])] for tr in table.find_all("tr", recursive=True)]
        if not rows or not rows[0] or not rows[0][0].lower().startswith("commodit"):
            continue
        title = " ".join(rows[0]).lower()
        name = "Retail Prices" if "retail" in title else "Wholesale Prices" if "wholesale" in title else None
        di = next((i for i, r in enumerate(rows) if r and all(re.fullmatch(r"\d{2}/\d{2}/\d{4}", c) for c in r)), None)
        if name is None or di is None:
            continue
        dates = rows[di]
        body = [r for r in rows[di + 1:] if len(r) == len(dates) + 2]
        sheets[name] = pd.DataFrame(body, columns=["Commodities", "Unit"] + dates)
    if len(sheets) < 2:
        raise ValueError("DoCA page: retail and wholesale tables not found (page layout may have changed)")
    return parse_sheets(sheets)


def fetch(session=None) -> pd.DataFrame:
    import requests
    r = (session or requests).get(URL, headers=UA, timeout=90)
    r.raise_for_status()
    return parse_html(r.text)
