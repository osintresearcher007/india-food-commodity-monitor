"""Adapter for NECC (National Egg Co-ordination Committee) daily egg price sheet.

Source page: https://www.e2necc.com/home/eggprice  - a zone x day table for one month, in two sections:
'NECC suggested egg prices' and 'Prevailing prices'. Prices are Rs per 100 eggs at production (PC) and
consumption (CC) centres. NECC states these are suggestive reference prices, not mandated ones.
A plain GET returns the current month (structure verified on 15 Nov 2026). Earlier months need the page's form
(POST ddlMonth / ddlYear); that path could not be verified and is reported in the refresh log if it fails.
"""
from __future__ import annotations
import re
import pandas as pd
import requests
from bs4 import BeautifulSoup
from ..config import SCHEMA

URL = "https://www.e2necc.com/home/eggprice"
SOURCE = "NECC (e2necc.com)"
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126 Safari/537.36"}
# centre -> (state, district)
CENTRES = {
    "Ahmedabad": ("Gujarat", "Ahmadabad"), "Ajmer": ("Rajasthan", "Ajmer"), "Barwala": ("Haryana", "Hisar"),
    "Bengaluru": ("Karnataka", "Bengaluru"), "Brahmapur": ("Odisha", "Ganjam"), "Chennai": ("Tamil Nadu", "Chennai"),
    "Chittoor": ("Andhra Pradesh", "Chittoor"), "Delhi": ("Delhi", "New Delhi"), "E.Godavari": ("Andhra Pradesh", "East Godavari"),
    "Hospet": ("Karnataka", "Ballari"), "Hyderabad": ("Telangana", "Hyderabad"), "Jabalpur": ("Madhya Pradesh", "Jabalpur"),
    "Kolkata": ("West Bengal", "Kolkata"), "Ludhiana": ("Punjab", "Ludhiana"), "Mumbai": ("Maharashtra", "Mumbai"),
    "Mysuru": ("Karnataka", "Mysuru"), "Namakkal": ("Tamil Nadu", "Namakkal"), "Pune": ("Maharashtra", "Pune"),
    "Raipur": ("Chhattisgarh", "Raipur"), "Surat": ("Gujarat", "Surat"), "Vijayawada": ("Andhra Pradesh", "Krishna"),
    "Vizag": ("Andhra Pradesh", "Visakhapatnam"), "W.Godavari": ("Andhra Pradesh", "West Godavari"),
    "Warangal": ("Telangana", "Warangal Urban"), "Allahabad": ("Uttar Pradesh", "Prayagraj"), "Bhopal": ("Madhya Pradesh", "Bhopal"),
    "Indore": ("Madhya Pradesh", "Indore"), "Kanpur": ("Uttar Pradesh", "Kanpur Nagar"), "Luknow": ("Uttar Pradesh", "Lucknow"),
    "Lucknow": ("Uttar Pradesh", "Lucknow"), "Muzaffurpur": ("Bihar", "Muzaffarpur"), "Muzaffarpur": ("Bihar", "Muzaffarpur"),
    "Nagpur": ("Maharashtra", "Nagpur"), "Patna": ("Bihar", "Patna"), "Ranchi": ("Jharkhand", "Ranchi"),
    "Varanasi": ("Uttar Pradesh", "Varanasi"),
}


def rows_to_frame(rows: list[list[str]], year: int, month: int) -> pd.DataFrame:
    """rows: [zone, day1, day2, ...] lists, with single-cell rows marking the section. Returns SCHEMA rows."""
    out, section = [], "NECC suggested"
    for r in rows:
        cells = [str(c).strip() for c in r]
        if len(cells) < 2:
            if cells and cells[0]:
                section = "Prevailing" if "prevail" in cells[0].lower() else "NECC suggested"
            continue
        zone = cells[0]
        name = re.sub(r"\s*\(.*?\)\s*$", "", zone).strip()
        state, district = CENTRES.get(name, ("", name))
        for day, v in enumerate(cells[1:], start=1):
            price = pd.to_numeric(v, errors="coerce")
            if pd.isna(price) or price <= 0:
                continue
            try:
                d = pd.Timestamp(year=year, month=month, day=day)
            except ValueError:  # e.g. the trailing 'Average' column or day 31 in a 30-day month
                continue
            out.append((d, state, district, zone, "Egg", section, "", "Wholesale", pd.NA, pd.NA, float(price),
                        "Rs/100 eggs", pd.NA, SOURCE, "mandi", False))
    return pd.DataFrame(out, columns=SCHEMA)


def parse_html(html: str, today=None) -> pd.DataFrame:
    soup = BeautifulSoup(html, "html.parser")

    def selected(name):
        sel = soup.find("select", attrs={"name": name})
        opt = sel.find("option", selected=True) if sel else None
        return int(opt["value"]) if opt and str(opt.get("value", "")).isdigit() else None
    today = pd.Timestamp(today) if today is not None else pd.Timestamp.now(tz="Asia/Kolkata").tz_localize(None)
    year, month = selected("ddlYear") or today.year, selected("ddlMonth") or today.month
    table = max(soup.find_all("table"), key=lambda t: len(t.find_all("tr")), default=None)
    if table is None:
        raise ValueError("NECC page: price table not found (page layout may have changed)")
    rows = [[c.get_text(" ", strip=True) for c in tr.find_all(["td", "th"])] for tr in table.find_all("tr")]
    head = rows[0] if rows else []
    if not head or "zone" not in head[0].lower():
        raise ValueError("NECC page: unexpected table header (page layout may have changed)")
    ndays = sum(1 for h in head[1:] if h.isdigit())
    df = rows_to_frame([r[: ndays + 1] for r in rows[1:]], year, month)
    return df[df["date"] <= today.normalize()]


def fetch(year: int | None = None, month: int | None = None, session=None) -> pd.DataFrame:
    """Current month by GET; a specific month by the page's form POST (unverified path)."""
    s = session or requests.Session()
    if year is None:
        r = s.get(URL, headers=UA, timeout=60)
    else:
        r = s.post(URL, headers=UA, timeout=60, data={"ddlMonth": f"{month:02d}", "ddlYear": str(year),
                                                      "rblReportType": "DailyReport", "btnReport": "Get Sheet"})
    r.raise_for_status()
    df = parse_html(r.text)
    if year is not None and len(df) and (df["date"].dt.month.iat[0] != month or df["date"].dt.year.iat[0] != year):
        raise ValueError(f"NECC returned a different month than requested ({year}-{month:02d})")
    return df
