"""News, policy and international monitors built on public RSS (Google News search RSS, PIB, custom feeds).

Only headlines, publisher names, dates and links published in the feeds are used; article pages are not scraped.
Classification (commodity, place, theme, evidence type) is keyword-based and shown as such.
"""
from __future__ import annotations
import html, re, urllib.parse
from concurrent.futures import ThreadPoolExecutor
import feedparser
import pandas as pd
import requests

UA = {"User-Agent": "Mozilla/5.0 (compatible; IndiaFoodCommodityMonitor/1.0)"}
COLS = ["published", "title", "publisher", "link", "summary", "language", "section", "commodities", "states",
        "districts", "themes", "evidence"]

# commodity -> search/match terms per language
TERMS = {
    "en": {"Onion": ["onion"], "Tomato": ["tomato"], "Potato": ["potato"], "Rice": ["rice", "paddy"],
           "Wheat": ["wheat", "atta"], "Pulses": ["pulses", "dal", "tur", "arhar", "chana", "urad", "moong", "masur", "masoor", "lentil"],
           "Edible oils": ["edible oil", "palm oil", "soybean oil", "soyoil", "mustard oil", "sunflower oil", "cooking oil"],
           "Oilseeds": ["soybean", "soyabean", "mustard", "groundnut", "oilseed"], "Sugar": ["sugar", "sugarcane", "ethanol"],
           "Eggs": ["egg", "necc"], "Maize": ["maize", "corn"],
           "Spices": ["chilli", "turmeric", "cumin", "jeera", "coriander", "pepper", "cardamom"]},
    "hi": {"Onion": ["प्याज"], "Tomato": ["टमाटर"], "Potato": ["आलू"], "Rice": ["चावल", "धान"], "Wheat": ["गेहूं", "आटा"],
           "Pulses": ["दाल", "अरहर", "चना"], "Edible oils": ["खाद्य तेल", "सरसों तेल"], "Sugar": ["चीनी"], "Eggs": ["अंडा", "अंडे"]},
    "mr": {"Onion": ["कांदा", "कांद्या"], "Tomato": ["टोमॅटो"], "Potato": ["बटाटा"], "Rice": ["तांदूळ"], "Wheat": ["गहू"],
           "Pulses": ["डाळ", "तूर"], "Edible oils": ["खाद्यतेल"], "Sugar": ["साखर"], "Eggs": ["अंडी"], "Oilseeds": ["सोयाबीन"]},
    "gu": {"Onion": ["ડુંગળી"], "Tomato": ["ટામેટા"], "Potato": ["બટાકા"], "Rice": ["ચોખા"], "Wheat": ["ઘઉં"],
           "Pulses": ["દાળ"], "Edible oils": ["ખાદ્ય તેલ", "સીંગતેલ"], "Sugar": ["ખાંડ"], "Eggs": ["ઈંડા"]},
    "pa": {"Onion": ["ਪਿਆਜ਼"], "Tomato": ["ਟਮਾਟਰ"], "Potato": ["ਆਲੂ"], "Rice": ["ਚੌਲ", "ਝੋਨਾ", "ਝੋਨੇ"], "Wheat": ["ਕਣਕ"],
           "Pulses": ["ਦਾਲ"], "Sugar": ["ਖੰਡ"], "Eggs": ["ਅੰਡੇ"]},
    "bn": {"Onion": ["পেঁয়াজ"], "Tomato": ["টমেটো"], "Potato": ["আলু"], "Rice": ["চাল"], "Wheat": ["গম"],
           "Pulses": ["ডাল"], "Edible oils": ["ভোজ্য তেল", "সরষের তেল"], "Sugar": ["চিনি"], "Eggs": ["ডিম"]},
    "or": {"Onion": ["ପିଆଜ"], "Tomato": ["ଟମାଟୋ"], "Potato": ["ଆଳୁ"], "Rice": ["ଚାଉଳ"], "Wheat": ["ଗହମ"],
           "Pulses": ["ଡାଲି"], "Edible oils": ["ଖାଇବା ତେଲ"], "Sugar": ["ଚିନି"], "Eggs": ["ଅଣ୍ଡା"]},
    "te": {"Onion": ["ఉల్లి"], "Tomato": ["టమాటా", "టమోటా"], "Potato": ["బంగాళదుంప"], "Rice": ["బియ్యం"], "Wheat": ["గోధుమ"],
           "Pulses": ["పప్పు", "కంది"], "Edible oils": ["వంట నూనె"], "Sugar": ["చక్కెర"], "Eggs": ["గుడ్లు", "గుడ్డు"]},
    "ta": {"Onion": ["வெங்காயம்"], "Tomato": ["தக்காளி"], "Potato": ["உருளைக்கிழங்கு"], "Rice": ["அரிசி"], "Wheat": ["கோதுமை"],
           "Pulses": ["பருப்பு"], "Edible oils": ["சமையல் எண்ணெய்"], "Sugar": ["சர்க்கரை"], "Eggs": ["முட்டை"]},
    "kn": {"Onion": ["ಈರುಳ್ಳಿ"], "Tomato": ["ಟೊಮೆಟೊ", "ಟೊಮೇಟೊ"], "Potato": ["ಆಲೂಗಡ್ಡೆ"], "Rice": ["ಅಕ್ಕಿ"], "Wheat": ["ಗೋಧಿ"],
           "Pulses": ["ಬೇಳೆ", "ತೊಗರಿ"], "Edible oils": ["ಅಡುಗೆ ಎಣ್ಣೆ"], "Sugar": ["ಸಕ್ಕರೆ"], "Eggs": ["ಮೊಟ್ಟೆ"]},
    "ml": {"Onion": ["ഉള്ളി", "സവാള"], "Tomato": ["തക്കാളി"], "Potato": ["ഉരുളക്കിഴങ്ങ്"], "Rice": ["അരി"], "Wheat": ["ഗോതമ്പ്"],
           "Pulses": ["പരിപ്പ്"], "Edible oils": ["വെളിച്ചെണ്ണ", "ഭക്ഷ്യ എണ്ണ"], "Sugar": ["പഞ്ചസാര"], "Eggs": ["മുട്ട"]},
}
LANG_NAMES = {"en": "English", "hi": "Hindi", "mr": "Marathi", "gu": "Gujarati", "pa": "Punjabi", "bn": "Bengali",
              "or": "Odia", "te": "Telugu", "ta": "Tamil", "kn": "Kannada", "ml": "Malayalam"}
# price / shortage / hoarding words used to build regional-language queries
MARKET_WORDS = {
    "hi": ["दाम", "कीमत", "भाव", "किल्लत", "जमाखोरी", "आवक"], "mr": ["भाव", "दर", "टंचाई", "साठेबाजी", "आवक"],
    "gu": ["ભાવ", "અછત", "સંગ્રહખોરી"], "pa": ["ਭਾਅ", "ਕੀਮਤ", "ਕਮੀ", "ਜਮ੍ਹਾਂਖੋਰੀ"], "bn": ["দাম", "সংকট", "মজুত"],
    "or": ["ଦର", "ଅଭାବ", "ମହଜୁଦ"], "te": ["ధర", "కొరత", "అక్రమ నిల్వ"], "ta": ["விலை", "தட்டுப்பாடு", "பதுக்கல்"],
    "kn": ["ಬೆಲೆ", "ಕೊರತೆ", "ದಾಸ್ತಾನು"], "ml": ["വില", "ക്ഷാമം", "പൂഴ്ത്തിവെപ്പ്"],
}
THEMES = {
    "Price increase": r"price[s]? (rise|surge|soar|jump|spike|up|hike)|costlier|skyrocket|dearer|soar|surge|महंग|दाम बढ़|भाव वाढ|ધર ಏರಿಕೆ|விலை உயர்|ధర పెరి|വില കൂ|দাম বাড়|ભાવ વધ",
    "Shortage / low arrivals": r"shortage|short supply|scarcity|arrivals (fall|drop|dip|decline)|low arrivals|supply crunch|किल्लत|कमी|टंचाई|আকাল|সংকট|అకొరత|కొరత|தட்டுப்பாடு|ಕೊರತೆ|ക്ഷാമം|અછત|ਕਮੀ|ଅଭାବ",
    "Hoarding / enforcement": r"hoard|black.?market|stock limit|raid|seiz|stock concealment|essential commodities act|जमाखोरी|कालाबाज|साठेबाज|মজুত|பதுக்கல்|అక్రమ నిల్వ|ದಾಸ್ತಾನು|പൂഴ്ത്തി|સંગ્રહખોરી|ਜਮ੍ਹਾਂਖੋਰ|ମହଜୁଦ",
    "Glut / price fall": r"glut|bumper|oversupply|price[s]? (crash|fall|slump|plunge|drop|down)|distress sale|dump(ed|ing)? (on|their)|throw|भाव गिर|दाम गिर|भाव घसर|কমেছে|விலை சரி|ధర పత|ಬೆಲೆ ಕುಸಿ",
    "Farmer distress": r"farmer[s]? (protest|distress|agitat|dump|suicide|demand)|किसान.*(परेशान|आंदोलन)|शेतकरी.*(संकट|आंदोलन)",
    "Weather / crop damage": r"crop (damage|loss)|unseasonal|heavy rain|flood|drought|heat ?wave|hailstorm|cyclone|pest|फसल.*(खराब|नुकसान|बर्बाद)|बारिश|पावसा|অতিবৃষ্টি|వర్షా|மழை|ಮಳೆ|മഴ",
    "Harvest / sowing": r"harvest|sowing|acreage|kharif|rabi|output estimate|production estimate",
    "Transport disruption": r"truck(er)?s? strike|transport strike|highway block|freight|rail rake|logistics|bandh",
    "Procurement / intervention": r"procure|msp|buffer|open market sale|omss|nafed|nccf|fci|subsid|bharat (atta|dal|rice)|price stabili",
    "Trade (import/export)": r"import|export|duty|tariff|dgft|minimum export price|\bmep\b|quota|shipment",
    "Demand": r"demand (rise|surge|up|fall|weak)|festiv|wedding season|consumption",
}
EVIDENCE = [
    ("Official statement", r"\bpib\b|press information bureau|ministry|notif|gazette|government (says|said|orders|announces)|cabinet|dgft|collector order"),
    ("Media allegation (unverified)", r"alleg|accus|claim|suspect|reportedly|hoard|black.?market|जमाखोरी|साठेबाज|பதுக்கல்"),
    ("Forecast / expectation", r"forecast|expected|likely|may |could |outlook|estimate|projected|to rise|to fall|seen "),
]

GN = "https://news.google.com/rss/search?q={q}&hl={hl}&gl=IN&ceid=IN:{ce}"
PIB_RSS = "https://www.pib.gov.in/RssMain.aspx?ModId=6&Lang=1&Regid=3"

LOCAL_EN = [
    "(onion OR tomato OR potato) (price OR prices) (mandi OR wholesale OR retail OR APMC)",
    "(hoarding OR \"stock limit\" OR raid OR seized OR \"black marketing\") (pulses OR wheat OR rice OR sugar OR \"edible oil\" OR onion)",
    "(glut OR \"distress sale\" OR \"prices crash\" OR dump) farmers (onion OR tomato OR potato OR soybean OR garlic)",
    "(\"crop damage\" OR \"unseasonal rain\" OR heatwave OR flood) (wheat OR paddy OR pulses OR onion OR tomato) mandi",
    "(tur OR arhar OR chana OR urad OR moong OR masur) dal (price OR prices OR arrivals)",
    "(\"edible oil\" OR \"palm oil\" OR \"soybean oil\" OR \"mustard oil\" OR \"sunflower oil\") price India",
    "(egg OR NECC) (price OR rate) (Namakkal OR Barwala OR Hyderabad OR wholesale)",
    "(wheat OR rice OR sugar OR maize) (mandi price OR arrivals OR procurement) India",
]
POLICY_Q = [
    "PIB (\"consumer affairs\" OR \"food and public distribution\") (\"stock limit\" OR buffer OR OMSS OR \"price stabilisation\")",
    "DGFT notification (export OR import) (rice OR wheat OR sugar OR onion OR pulses OR \"edible oil\")",
    "(\"import duty\" OR \"export duty\" OR \"minimum export price\") (\"edible oil\" OR pulses OR onion OR rice OR sugar OR wheat) India",
    "MSP (kharif OR rabi) (cabinet OR CCEA) crops",
    "(FCI OR NAFED OR NCCF) (procurement OR \"open market sale\" OR \"buffer stock\" OR \"market intervention\")",
    "ethanol (sugar OR maize OR \"FCI rice\" OR molasses) policy India",
    "state government (order OR orders) (\"stock limit\" OR \"essential commodities\" OR \"price control\") (onion OR pulses OR tomato OR wheat)",
]
INTL_Q = [
    "palm oil (Indonesia OR Malaysia) (\"export levy\" OR biodiesel OR prices OR output)",
    "(soybean OR soyoil) (Brazil OR Argentina OR \"United States\") (crop OR export OR prices)",
    "sunflower oil (Russia OR Ukraine) (export OR prices OR crop)",
    "(wheat OR rice) global (prices OR production) (FAO OR IGC OR USDA)",
    "sugar (Brazil OR Thailand) (output OR prices OR exports)",
    "(lentils OR pulses OR \"yellow peas\" OR pigeon peas) (Canada OR Australia OR Myanmar OR Mozambique) (exports OR crop) India",
    "(\"Red Sea\" OR \"freight rates\" OR shipping) (grain OR \"vegetable oil\" OR commodities)",
    "\"FAO food price index\"",
    "(\"export ban\" OR \"export restriction\" OR tariff) (rice OR wheat OR \"palm oil\" OR sugar OR pulses)",
]

# keyword -> (transmission mechanism, likely direction for Indian prices)
POLICY_RULES = [
    (r"export (ban|prohibit|curb|restrict)|minimum export price|\bmep\b|export duty", "Restricts exports, keeping more supply in the domestic market", "Downward / stabilising"),
    (r"(lift|remove|scrap|withdraw|ease).{0,25}export|export.{0,25}(allowed|permitted|resume)", "Re-opens exports, drawing supply out of the domestic market", "Upward / supportive"),
    (r"import duty.{0,30}(cut|reduc|slash|lower|waive|exempt|nil)|(cut|reduc|slash|lower|waive|scrap).{0,30}import duty|duty.free import", "Lowers the landed cost of imports", "Downward"),
    (r"import duty.{0,30}(hike|rais|increas)|(hike|rais|increas).{0,30}import duty", "Raises the landed cost of imports; supports domestic producers", "Upward"),
    (r"stock limit|anti.?hoarding|essential commodities|raid|seiz", "Forces release of trade stocks and deters holding", "Downward in the short term"),
    (r"open market sale|omss|buffer.{0,20}(release|offload|sale)|bharat (atta|dal|rice)|subsidi[sz]ed sale", "Adds government stock to market supply", "Downward / stabilising"),
    (r"\bmsp\b|minimum support price", "Raises the price floor for farmers; passes through to market prices over the season", "Upward (floor)"),
    (r"procure|market intervention|price support scheme|pss\b", "Government buying removes surplus and supports farm-gate prices", "Supportive / upward"),
    (r"ethanol", "Changes diversion of sugar/grain to fuel, altering food availability", "Depends on allocation - upward if diversion rises"),
    (r"import.{0,20}(allow|permit|quota|extend|free)", "Enlarges import supply", "Downward"),
]
INTL_RULES = [
    (r"palm", "Indonesia / Malaysia", "Edible oils", "India imports well over half of its edible oil; palm oil is the largest share, mainly from Indonesia and Malaysia",
     "Import parity: CIF price + Indian import duty + rupee rate feed into refined palm and blended oil prices within weeks", "Short (2-6 weeks)"),
    (r"soy ?(bean)? ?oil|soyoil|soybean|soya", "Brazil / Argentina / US", "Edible oils", "Crude soybean oil is imported mainly from Argentina and Brazil",
     "Landed soy oil cost; also influences domestic soybean and soymeal prices", "Short to medium"),
    (r"sunflower", "Russia / Ukraine", "Edible oils", "Sunflower oil is almost entirely imported, largely from Russia and Ukraine",
     "Landed sunflower oil cost; substitution with soy and palm oil", "Short to medium"),
    (r"rice", "Global", "Rice", "India is the largest rice exporter, so the exposure is on the export side",
     "World prices change export demand for Indian rice; domestic effect depends on export policy and FCI stocks", "Medium"),
    (r"wheat", "Global", "Wheat", "India is broadly self-sufficient; imports are small and policy-controlled",
     "Limited direct pass-through unless imports are opened or duty is changed", "Medium to long"),
    (r"sugar", "Brazil / Thailand", "Sugar", "India is a large producer; sugar exports are regulated by government quota",
     "World prices matter mainly through export-quota decisions and ethanol economics", "Medium"),
    (r"lentil|pulses|peas|pigeon|chickpea", "Canada / Australia / Myanmar / Africa", "Pulses", "India imports tur, masur, urad and yellow peas to cover deficits",
     "Supplier crop size and prices set landed cost; import-duty windows matter", "Medium"),
    (r"freight|red sea|shipping|suez", "Global shipping", "Edible oils", "Bulk vegetable oil and pulses imports move by sea",
     "Higher freight and insurance raise landed costs of all imported food commodities", "Short"),
    (r"food price index|fao", "Global", "Rice", "Benchmark of world food commodity prices",
     "Indicator of global direction only; no direct pass-through without a trade link", "Indicator"),
]
UP_WORDS = r"rise|rises|rising|surge|soar|jump|hike|higher|rally|gain|climb|tight|drought|ban|curb|restrict|levy|shortfall|lower (output|crop)|cut.{0,15}(output|estimate)"
DOWN_WORDS = r"fall|falls|falling|drop|slump|plunge|lower prices|decline|ease|easing|bumper|record (crop|output|harvest)|surplus|glut|cut.{0,15}(levy|duty)"


def gn_url(query: str, lang: str = "en", days: int = 10) -> str:
    q = urllib.parse.quote(f"{query} when:{days}d")
    return GN.format(q=q, hl=f"{lang}-IN" if lang == "en" else lang, ce=lang)


def regional_queries(langs: list[str], days: int = 10) -> list[tuple[str, str]]:
    out = []
    for lg in langs:
        if lg == "en" or lg not in MARKET_WORDS:
            continue
        coms = [t[0] for t in TERMS[lg].values()]
        out.append((gn_url(f"({' OR '.join(coms)}) ({' OR '.join(MARKET_WORDS[lg])})", lg, days), lg))
    return out


def _clean(s: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(re.sub(r"<[^>]+>", " ", s or ""))).strip()


def parse_feed(text: str, language: str = "en", section: str = "Local") -> list[dict]:
    feed = feedparser.parse(text)
    items = []
    for e in feed.entries:
        title = _clean(e.get("title", ""))
        pub = _clean(e.get("source", {}).get("title", "")) if isinstance(e.get("source"), dict) else ""
        if not pub and " - " in title:
            pub = title.rsplit(" - ", 1)[1]
        if pub and title.endswith(" - " + pub):
            title = title[: -len(pub) - 3]
        t = e.get("published_parsed") or e.get("updated_parsed")
        summary = _clean(e.get("summary", ""))
        if summary.startswith(title[:40]):
            summary = ""  # Google News repeats the headline; keep only genuine descriptions
        items.append({"published": pd.Timestamp(*t[:6]) if t else pd.NaT, "title": title,
                      "publisher": pub or _clean(feed.feed.get("title", "")), "link": e.get("link", ""),
                      "summary": summary[:400], "language": LANG_NAMES.get(language, language), "section": section})
    return items


def _find(text: str, table: dict) -> list[str]:
    return [k for k, pat in table.items() if re.search(pat, text, flags=re.I)]


def classify(items: list[dict], places: dict | None = None) -> pd.DataFrame:
    """Tag commodity, state/district, theme and evidence type by keyword. places = {'states': [...], 'districts': {name: state}}."""
    if not items:
        return pd.DataFrame(columns=COLS)
    places = places or {"states": [], "districts": {}}
    rows = []
    for it in items:
        text = f"{it['title']} {it['summary']}"
        low = text.lower()
        coms = sorted({c for terms in TERMS.values() for c, ws in terms.items()
                       if any((re.search(rf"\b{re.escape(w)}", low) if w.isascii() else w in text) for w in ws)})
        states = [s for s in places["states"] if re.search(rf"\b{re.escape(s.lower())}\b", low)]
        dists = [d for d in places["districts"] if len(d) >= 4 and re.search(rf"\b{re.escape(d.lower())}\b", low)]
        for d in dists:
            if places["districts"][d] not in states:
                states.append(places["districts"][d])
        ev = next((name for name, pat in EVIDENCE if re.search(pat, low)), "Media report")
        rows.append({**it, "commodities": ", ".join(coms), "states": ", ".join(states), "districts": ", ".join(dists),
                     "themes": ", ".join(_find(low, THEMES)), "evidence": ev})
    df = pd.DataFrame(rows)[COLS]
    return dedupe(df)


def dedupe(df: pd.DataFrame) -> pd.DataFrame:
    """Remove identical / syndicated stories: same normalised headline keeps the earliest publication."""
    key = df["title"].str.lower().str.replace(r"[^\w]+", " ", regex=True).str.strip().str[:70]
    df = df.assign(_k=key).sort_values("published").drop_duplicates("_k", keep="first").drop(columns="_k")
    return df.sort_values("published", ascending=False).reset_index(drop=True)


def fetch_many(urls: list[tuple[str, str]], section: str, timeout: int = 8) -> tuple[list[dict], list[str]]:
    """Fetch feeds concurrently. Returns (items, failure messages)."""
    def one(u):
        url, lang = u
        try:
            r = requests.get(url, headers=UA, timeout=timeout)
            r.raise_for_status()
            return parse_feed(r.text, lang, section), None
        except Exception as e:
            return [], f"{urllib.parse.unquote(url)[:90]}... : {type(e).__name__} {str(e)[:80]}"
    items, fails = [], []
    with ThreadPoolExecutor(16) as ex:
        for got, err in ex.map(one, urls):
            items.extend(got)
            if err:
                fails.append(err)
    return items, fails


def collect(langs: list[str] | None = None, days: int = 10, places: dict | None = None,
            extra_feeds: list[str] | None = None) -> tuple[pd.DataFrame, list[str]]:
    """Fetch local, policy and international news. Returns (classified frame, failed-source messages)."""
    langs = langs or list(LANG_NAMES)
    local = [(gn_url(q, "en", days), "en") for q in LOCAL_EN] + regional_queries(langs, days)
    local += [(u, "en") for u in (extra_feeds or [])]
    a, f1 = fetch_many(local, "Local")
    b, f2 = fetch_many([(gn_url(q, "en", max(days, 14)), "en") for q in POLICY_Q] + [(PIB_RSS, "en")], "Policy")
    c, f3 = fetch_many([(gn_url(q, "en", max(days, 14)), "en") for q in INTL_Q], "International")
    food = re.compile("|".join(re.escape(w) for ws in TERMS["en"].values() for w in ws) + r"|food|kharif|rabi|msp|crop|mandi", re.I)
    b = [x for x in b if food.search(x["title"] + " " + x["summary"])]
    df = classify(a + b + c, places)
    if len(df):
        cutoff = pd.Timestamp.now(tz="UTC").tz_localize(None) - pd.Timedelta(days=max(days, 14) + 2)
        df = df[df["published"].isna() | (df["published"] >= cutoff)]
    return df, f1 + f2 + f3


def policy_view(df: pd.DataFrame) -> pd.DataFrame:
    """Policy items with status, transmission mechanism and likely price implication (rule-based)."""
    p = df[df["section"] == "Policy"].copy()
    if p.empty:
        return p
    mech, imp, stat = [], [], []
    for t in (p["title"] + " " + p["summary"]).str.lower():
        hit = next(((m, d) for pat, m, d in POLICY_RULES if re.search(pat, t)), ("Not classified by the rule set", "Unclear"))
        mech.append(hit[0]); imp.append(hit[1])
        stat.append("Implemented" if re.search(r"comes? into (force|effect)|with immediate effect|implemented|begins|started|kicks off", t)
                    else "Notified" if re.search(r"notif|gazette|order issued|circular", t)
                    else "Proposed / under consideration" if re.search(r"mull|consider|propos|may |likely|plan(s|ning)? to|seeks", t)
                    else "Announced")
    p["status"], p["mechanism"], p["implication"] = stat, mech, imp
    p["uncertainty"] = "Headline-based classification; read the source. Timing of a price move after a policy is not proof of causation."
    return p


def intl_view(df: pd.DataFrame) -> pd.DataFrame:
    """International items with India exposure, transmission mechanism, direction and horizon (rule-based)."""
    x = df[df["section"] == "International"].copy()
    if x.empty:
        return x
    recs = []
    for t in (x["title"] + " " + x["summary"]).str.lower():
        hit = next((r for r in INTL_RULES if re.search(r[0], t)), None)
        up, down = bool(re.search(UP_WORDS, t)), bool(re.search(DOWN_WORDS, t))
        direction = "Upward pressure possible" if up and not down else "Downward pressure possible" if down and not up else "Unclear from headline"
        if hit is None:
            recs.append(("Not identified", "", "No India link identified by the rule set", "None established - treat as background", "", "Unclear from headline", "Low"))
        else:
            weak = hit[2] in ("Wheat", "Rice", "Sugar") or "Indicator" in hit[5]
            if weak and direction != "Unclear from headline":
                direction += " (indirect; depends on Indian trade policy)"
            recs.append((hit[1], hit[2], hit[3], hit[4], hit[5], direction,
                         "Low" if direction.startswith("Unclear") else "Medium-low" if weak else "Medium"))
    for i, c in enumerate(["region", "commodity", "exposure", "mechanism", "horizon", "direction", "confidence"]):
        x[c] = [r[i] for r in recs]
    return x
