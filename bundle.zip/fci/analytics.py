"""Price-change engine: complete-period comparisons, matched-market aggregation, alerts and confidence labels.

Definitions
- Week = Monday-Sunday calendar week; month = calendar month. By default only complete periods are compared.
- A 'series' is one commodity + variety + grade + market type + unit + source at one market. Only series reporting
  in BOTH periods are compared (matched markets), so changes in market coverage cannot create artificial moves.
- Mandi price = mean of daily modal prices in the period.
- District/state/all-India price = mean over matched series (arrival-weighted with fixed weights when at least
  80% of the series report arrivals in both periods; otherwise unweighted, with the market count shown).
- Arrivals are compared as average arrivals per reporting day, so a different number of market days does not distort them.
- A district/state average that crosses the threshold while its median market does not is labelled 'Concentrated'
  (driven by a few markets) rather than treated as a broad move.
- Alerts are strict: weekly change > 5% (or < -5%), monthly change > 10% (or < -10%).
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from .config import WEEKLY_THRESHOLD, MONTHLY_THRESHOLD, SUSPECT_CHANGE, PRIORITY_WEIGHT

SERIES = ["commodity", "group", "priority", "variety", "grade", "market_type", "unit", "source",
          "state", "district", "market"]
ITEM = ["commodity", "group", "priority", "market_type", "unit"]
GEO = {"district": ["state", "district"], "state": ["state"], "national": []}
THRESHOLD = {"W": WEEKLY_THRESHOLD, "M": MONTHLY_THRESHOLD}


def period_start(dates: pd.Series, freq: str) -> pd.Series:
    d = pd.to_datetime(dates).dt.normalize()
    if freq == "W":
        return d - pd.to_timedelta(d.dt.weekday, unit="D")
    return d.dt.to_period("M").dt.start_time


def period_end(start: pd.Timestamp, freq: str) -> pd.Timestamp:
    return start + pd.Timedelta(days=6) if freq == "W" else start + pd.offsets.MonthEnd(0)


def comparison_periods(max_date, freq: str, provisional: bool = False) -> dict:
    """Latest complete period and the one before it. With provisional=True the current partial period is used."""
    max_date = pd.Timestamp(max_date).normalize()
    cur = period_start(pd.Series([max_date]), freq).iloc[0]
    complete = period_end(cur, freq) <= max_date
    if not complete and not provisional:
        cur = period_start(pd.Series([cur - pd.Timedelta(days=1)]), freq).iloc[0]
    prev = period_start(pd.Series([cur - pd.Timedelta(days=1)]), freq).iloc[0]
    return {"freq": freq, "cur": cur, "cur_end": min(period_end(cur, freq), max_date), "prev": prev,
            "prev_end": period_end(prev, freq), "provisional": bool(not complete and provisional)}


def series_periods(df: pd.DataFrame, freq: str) -> pd.DataFrame:
    """Mean modal price, observation days and total arrivals for every series and period."""
    d = df[df["quality"] == "OK"] if "quality" in df.columns else df
    d = d.assign(period=period_start(d["date"], freq))
    g = d.groupby(SERIES + ["period"], dropna=False, sort=False)
    out = g.agg(price=("modal_price", "mean"), obs=("date", "nunique"),
                arrivals=("arrivals", "mean")).reset_index()  # average arrivals per reporting day
    # A source that publishes ready-made monthly averages has one row per month but stands for the whole month.
    out.loc[out["grade"] == "Monthly average", "obs"] = 20
    return out


def pct_change(cur, prev):
    return np.round((cur / prev - 1.0) * 100.0, 6)  # rounding keeps exactly-5% moves from tripping the strict test


def status(change: float, thr: float) -> str:
    if pd.isna(change):
        return "No comparison"
    if change > thr:
        return f"Increase >{thr:g}%"
    if change < -thr:
        return f"Decrease >{thr:g}%"
    return "Within range"


def compare_series(sp: pd.DataFrame, per: dict) -> pd.DataFrame:
    """Matched series: one row per series present in both the current and the previous period."""
    cur = sp[sp["period"] == per["cur"]].drop(columns="period")
    prev = sp[sp["period"] == per["prev"]].drop(columns="period")
    m = cur.merge(prev, on=SERIES, suffixes=("_cur", "_prev"))
    m["change_abs"] = m["price_cur"] - m["price_prev"]
    m["change_pct"] = pct_change(m["price_cur"], m["price_prev"])
    thr = THRESHOLD[per["freq"]]
    m["status"] = [status(c, thr) for c in m["change_pct"]]
    obs = m[["obs_cur", "obs_prev"]].min(axis=1)
    m["confidence"] = np.select([m["change_pct"].abs() > SUSPECT_CHANGE, obs >= 3, obs >= 2],
                                ["Check data", "High", "Medium"], "Low")
    m["n_markets"] = 1
    return m


def aggregate(cmp: pd.DataFrame, level: str, freq: str) -> pd.DataFrame:
    """Aggregate matched series to district, state or all-India (mandi-based) level."""
    keys = ITEM + GEO[level]
    if cmp.empty:
        return pd.DataFrame(columns=keys + ["price_cur", "price_prev", "change_abs", "change_pct", "status",
                                            "confidence", "n_markets", "n_series", "method"])
    thr = THRESHOLD[freq]
    c = cmp[cmp["confidence"] != "Check data"].copy()
    c["has_arr"] = (c["arrivals_cur"] > 0) & (c["arrivals_prev"] > 0)
    c["w"] = np.where(c["has_arr"], c["arrivals_cur"].fillna(0) + c["arrivals_prev"].fillna(0), 0.0)
    c["up"] = c["change_pct"] > thr
    c["down"] = c["change_pct"] < -thr
    for col in ("cur", "prev"):
        c[f"wp_{col}"] = c[f"price_{col}"] * c["w"]
    g = c.groupby(keys, dropna=False, sort=False)
    a = g.agg(mean_cur=("price_cur", "mean"), mean_prev=("price_prev", "mean"), wsum=("w", "sum"),
              wp_cur=("wp_cur", "sum"), wp_prev=("wp_prev", "sum"), arr_share=("has_arr", "mean"),
              n_series=("market", "size"), n_markets=("market", "nunique"), median_change=("change_pct", "median"),
              share_up=("up", "mean"), share_down=("down", "mean"),
              arr_cur=("arrivals_cur", lambda s: s.sum(min_count=1)),
              arr_prev=("arrivals_prev", lambda s: s.sum(min_count=1))).reset_index()
    weighted = (a["arr_share"] >= 0.8) & (a["wsum"] > 0)
    a["price_cur"] = np.where(weighted, a["wp_cur"] / a["wsum"].where(a["wsum"] > 0), a["mean_cur"])
    a["price_prev"] = np.where(weighted, a["wp_prev"] / a["wsum"].where(a["wsum"] > 0), a["mean_prev"])
    a["method"] = np.where(weighted, "Arrival-weighted mean", "Unweighted mean")
    a["change_abs"] = a["price_cur"] - a["price_prev"]
    a["change_pct"] = pct_change(a["price_cur"], a["price_prev"])
    a["arrivals_change_pct"] = np.where(a["arr_prev"] > 0, pct_change(a["arr_cur"], a["arr_prev"]), np.nan)
    a["status"] = [status(x, thr) for x in a["change_pct"]]
    a["confidence"] = np.select([a["n_markets"] >= 5, a["n_markets"] >= 2], ["High", "Medium"], "Low")
    # An average pushed over the threshold by one or two markets while the typical market did not move is not broad-based.
    lone = (a["status"] != "Within range") & (a["n_markets"] >= 3) & (a["median_change"].abs() <= thr)
    a.loc[lone, "confidence"] = "Concentrated"
    return a.drop(columns=["mean_cur", "mean_prev", "wsum", "wp_cur", "wp_prev", "arr_cur", "arr_prev"])


def run(df: pd.DataFrame, freq: str, as_of=None, provisional: bool = False) -> dict:
    """All comparisons for one frequency. Mandi rows and official national (DoCA) rows use their own latest dates."""
    out = {"freq": freq, "threshold": THRESHOLD[freq]}
    mandi = df[df["level"] != "national"]
    nat = df[df["level"] == "national"]
    for name, part in (("mandi", mandi), ("official", nat)):
        if part.empty:
            out[name] = pd.DataFrame()
            out[f"{name}_periods"] = None
            continue
        mx = min(pd.Timestamp(as_of), part["date"].max()) if as_of is not None else part["date"].max()
        per = comparison_periods(mx, freq, provisional)
        cmp = compare_series(series_periods(part[part["date"] <= mx], freq), per)
        out[name] = cmp
        out[f"{name}_periods"] = per
    m = out["mandi"]
    for level in GEO:
        out[level] = aggregate(m, level, freq) if not m.empty else pd.DataFrame()
    return out


def state_pressure(cmp: pd.DataFrame, freq: str) -> pd.DataFrame:
    """Price-pressure score per state, 0-100.

    Score = priority-weighted share of the state's matched mandi series whose price rose by more than the alert
    threshold (weights: High 3, Medium 2, Low 1). It measures how broad increases are, not how large.
    """
    if cmp.empty:
        return pd.DataFrame(columns=["state", "score", "median_change", "n_series", "n_markets", "n_up", "n_down"])
    thr = THRESHOLD[freq]
    c = cmp[cmp["confidence"] != "Check data"].copy()
    c["w"] = c["priority"].map(PRIORITY_WEIGHT).fillna(1)
    c["up"] = (c["change_pct"] > thr)
    c["down"] = (c["change_pct"] < -thr)
    c["wu"] = c["w"] * c["up"]
    g = c.groupby("state")
    p = g.agg(wu=("wu", "sum"), w=("w", "sum"), median_change=("change_pct", "median"), n_series=("market", "size"),
              n_markets=("market", "nunique"), n_up=("up", "sum"), n_down=("down", "sum")).reset_index()
    p["score"] = 100 * p["wu"] / p["w"]
    return p.drop(columns=["wu", "w"]).sort_values("score", ascending=False)


def alert_table(weekly: dict, monthly: dict, level: str) -> pd.DataFrame:
    """One row per item/location with weekly and monthly change side by side (the Market Alert Table)."""
    keys = SERIES if level in ("mandi", "official") else ITEM + GEO[level]
    w, m = weekly.get(level, pd.DataFrame()), monthly.get(level, pd.DataFrame())
    cols = ["price_cur", "price_prev", "change_abs", "change_pct", "status", "confidence", "n_markets"]

    def prep(x, suf):
        if x is None or x.empty:
            return pd.DataFrame(columns=keys + [f"{c}_{suf}" for c in cols])
        return x[keys + cols].rename(columns={c: f"{c}_{suf}" for c in cols})
    t = prep(w, "w").merge(prep(m, "m"), on=keys, how="outer")
    if t.empty:
        return t
    for g in GEO["district"] + ["market"]:
        if g not in t.columns:
            t[g] = "All India" if g == "state" and level == "national" else ""
    alert = []
    for sw, sm in zip(t["status_w"].fillna(""), t["status_m"].fillna("")):
        parts = [f"Weekly {sw.lower()}" for _ in [0] if sw.startswith(("Inc", "Dec"))]
        parts += [f"Monthly {sm.lower()}" for _ in [0] if sm.startswith(("Inc", "Dec"))]
        alert.append("; ".join(parts) or "Within range")
    t["alert"] = alert
    t["is_alert"] = t["alert"] != "Within range"
    return t.sort_values(["is_alert", "change_pct_w"], ascending=[False, False], na_position="last")


def display_alerts(t: pd.DataFrame) -> pd.DataFrame:
    """Rename the alert table to the user-facing column set."""
    if t.empty:
        return pd.DataFrame()
    cur = t["price_cur_w"].fillna(t["price_cur_m"])
    prev = t["price_prev_w"].fillna(t["price_prev_m"])
    out = pd.DataFrame({
        "Commodity": t["commodity"], "Variety": t.get("variety", ""), "Market type": t["market_type"],
        "State": t["state"], "District": t["district"], "Mandi": t["market"],
        "Current price": cur.round(2), "Previous price": prev.round(2), "Unit": t["unit"],
        "Weekly change %": t["change_pct_w"].round(2), "Monthly change %": t["change_pct_m"].round(2),
        "Markets": t["n_markets_w"].fillna(t["n_markets_m"]), "Confidence": t["confidence_w"].fillna(t["confidence_m"]),
        "Source": t["source"] if "source" in t.columns else "Mandi aggregate", "Alert status": t["alert"]})
    return out.reset_index(drop=True)


def trend(df: pd.DataFrame, by: list[str] | None = None) -> pd.DataFrame:
    """Daily median modal price across reporting markets, with the market count (not an official index)."""
    d = df[df["quality"] == "OK"] if "quality" in df.columns else df
    keys = ["date"] + (by or [])
    return d.groupby(keys).agg(price=("modal_price", "median"), markets=("market", "nunique"),
                               arrivals=("arrivals", lambda s: s.sum(min_count=1))).reset_index()


def persistence(sp_item: pd.Series, min_move: float = 1.0) -> int:
    """Number of consecutive latest periods moving in the same direction by at least min_move %. Signed."""
    ch = sp_item.sort_index().pct_change().dropna() * 100
    n = 0
    for v in ch.iloc[::-1]:
        if abs(v) < min_move or (n and np.sign(v) != np.sign(n)):
            break
        n += int(np.sign(v))
    return n
