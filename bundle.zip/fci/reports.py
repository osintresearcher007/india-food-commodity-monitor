"""Rule-based weekly / monthly insight reports rendered to Word, PDF and Excel from the current data."""
from __future__ import annotations
import io
import pandas as pd
from . import analytics as A

LENGTH = {"Brief": 5, "Standard": 10, "Detailed": 20}


def _fmt_period(per: dict | None) -> str:
    if not per:
        return "n/a"
    f = "%d %b %Y"
    if per.get("point"):
        return f"price on {per['cur']:{f}} compared with {per['prev']:{f}}"
    return (f"{per['cur']:{f}} to {per['cur_end']:{f}} compared with {per['prev']:{f}} to {per['prev_end']:{f}}"
            + (" (provisional: current period incomplete)" if per["provisional"] else ""))


def _money(v) -> str:
    return "n/a" if pd.isna(v) else f"Rs {v:,.2f}" if v < 1000 else f"Rs {v:,.0f}"


def _place(r) -> str:
    parts = [r.get(k, "") for k in ("market", "district", "state")]
    return ", ".join(p for p in parts if isinstance(p, str) and p) or "All India"


def _line(r, per_word: str) -> str:
    extra = f"; {int(r['n_markets'])} matched market(s)" if r.get("n_markets", 1) and r.get("market", "") == "" and r.get("state", "") != "All India" else ""
    arr = r.get("arrivals_change_pct")
    arr_txt = f"; arrivals {arr:+.1f}%" if arr is not None and pd.notna(arr) else ""
    return (f"{r['commodity']} ({r['market_type'].lower()}), {_place(r)}: {_money(r['price_cur'])} per "
            f"{r['unit'].replace('Rs/', '')} against {_money(r['price_prev'])} the previous {per_word} "
            f"({r['change_pct']:+.1f}%, {r['change_abs']:+,.2f}{extra}{arr_txt}; confidence {r['confidence']}).")


def _movers(t: pd.DataFrame, up: bool, n: int, only_alerts: bool = True) -> pd.DataFrame:
    if t is None or t.empty:
        return pd.DataFrame()
    t = t[t["confidence"] != "Check data"]
    key = "Increase" if up else "Decrease"
    if only_alerts:
        t = t[t["status"].str.startswith(key)]
    t = t.assign(_p=t["priority"].map({"High": 0, "Medium": 1, "Low": 2}))
    return t.sort_values(["_p", "change_pct"], ascending=[True, not up]).head(n)


def _table(t: pd.DataFrame, cols: dict) -> pd.DataFrame:
    if t is None or t.empty:
        return pd.DataFrame()
    out = t[[c for c in cols if c in t.columns]].rename(columns=cols).copy()
    for c in out.columns:
        if out[c].dtype.kind == "f":
            out[c] = out[c].round(2)
    return out


def _news_lines(n: pd.DataFrame, k: int, extra: str | None = None) -> list[str]:
    lines = []
    for r in n.head(k).itertuples():
        when = f"{r.published:%d %b %Y}" if pd.notna(r.published) else "date n/a"
        tag = f" [{getattr(r, extra)}]" if extra and getattr(r, extra, "") else ""
        where = f" ({r.states})" if r.states else ""
        lines.append(f"{r.title}{where} - {r.publisher}, {when}. {r.evidence}.{tag} Source: {r.link}")
    return lines


TCOLS = {"commodity": "Commodity", "market_type": "Type", "state": "State", "district": "District", "market": "Mandi",
         "price_cur": "Current", "price_prev": "Previous", "change_pct": "Change %", "n_markets": "Markets",
         "arrivals_change_pct": "Arrivals %", "confidence": "Confidence", "unit": "Unit"}


def build(kind: str, ctx: dict) -> dict:
    """Assemble report sections. ctx: weekly, monthly, signals, news, policy, intl, length, sample, filters, generated."""
    n = LENGTH.get(ctx.get("length", "Standard"), 10)
    run = ctx["weekly"] if kind == "weekly" else ctx["monthly"]
    word, thr = ("week", A.WEEKLY_THRESHOLD) if kind == "weekly" else ("month", A.MONTHLY_THRESHOLD)
    news = ctx.get("news", pd.DataFrame())
    local = news[news["section"] == "Local"] if len(news) else news
    off, nat, st, di, md = (run.get(k, pd.DataFrame()) for k in ("official", "national", "state", "district", "mandi"))
    sig = ctx.get("signals", pd.DataFrame())
    S = []
    add = lambda title, paras, table=None: S.append({"title": title, "paras": [p for p in paras if p], "table": table})
    caveat = ("State, district and mandi figures in this report come from SAMPLE (illustrative) data because no real "
              "mandi-level data has been loaded. They demonstrate the method only and must not be cited."
              if ctx.get("sample") else "")
    basis = [f"All-India retail prices: {_fmt_period(run.get('official_periods'))}.",
             f"Mandi-level data: {_fmt_period(run.get('mandi_periods'))}." if run.get("mandi_periods") else
             "No mandi-level data loaded.", caveat,
             f"Alert rule: change strictly greater than {thr:g}% {word}-on-{word}, matched markets only. "
             "Averages of reporting markets are not an official price index."]
    # 1 overview
    up_o, dn_o = _movers(off, True, n, False), _movers(off, False, n, False)
    hi = off[off["priority"] == "High"] if len(off) else off
    ov = []
    if len(off):
        nu, nd = int((off["status"].str.startswith("Inc")).sum()), int((off["status"].str.startswith("Dec")).sum())
        ov.append(f"Of {len(off)} official all-India retail and wholesale series, {nu} rose and {nd} fell by more than "
                  f"{thr:g}% over the {word}. Among high-priority items the median change was "
                  f"{hi['change_pct'].median():+.2f}% (range {hi['change_pct'].min():+.1f}% to {hi['change_pct'].max():+.1f}%).")
        ov += ["Largest increase: " + _line(up_o.iloc[0], word)] if len(up_o) and up_o.iloc[0]["change_pct"] > 0 else []
        ov += ["Largest decrease: " + _line(dn_o.iloc[0], word)] if len(dn_o) and dn_o.iloc[0]["change_pct"] < 0 else []
    else:
        ov.append("No official all-India series available for the selected period.")
    add("Executive summary" if kind == "monthly" else "National food-commodity market overview", basis + ov,
        _table(pd.concat([up_o.head(n // 2 + 1), dn_o.head(n // 2 + 1)]).drop_duplicates(), TCOLS) if len(off) else None)
    # 2 key developments
    dev = []
    for r in (sig[sig["signal"] != "Normal"].head(n).itertuples() if len(sig) else []):
        wk = f"{r.weekly_change_pct:+.1f}% WoW" if pd.notna(r.weekly_change_pct) else "WoW n/a"
        mo = f"{r.monthly_change_pct:+.1f}% MoM" if pd.notna(r.monthly_change_pct) else "MoM n/a"
        dev.append(f"{r.commodity}: {r.signal} (score {r.score:.0f}/100; {wk}, {mo}; {r.basis.lower()}). {r.pattern}. "
                   f"{r.states_beyond_threshold} of {r.states_reporting} reporting states and {r.districts_beyond_threshold} "
                   f"districts beyond the weekly threshold; {r.local_news} supporting local report(s).")
    if kind == "weekly":
        add("Most significant developments", dev or ["No commodity is above the Normal signal level on current data."],
            _table(sig.head(n), {"commodity": "Commodity", "signal": "Signal", "score": "Score", "weekly_change_pct": "WoW %",
                                 "monthly_change_pct": "MoM %", "pattern": "Pattern", "basis": "Basis"}) if len(sig) else None)
    else:
        add("National commodity-price overview", dev or ["No commodity is above the Normal signal level on current data."],
            _table(off.sort_values("change_pct", ascending=False), TCOLS) if len(off) else None)
    # 3 increases
    ups = [("All India (mandi aggregate)", nat), ("State", st), ("District", di), ("Mandi", md)]
    paras, tabs = [], []
    for name, t in ups:
        mv = _movers(t, True, n)
        paras.append(f"{name} level: {len(_movers(t, True, 10**6))} item-location(s) above +{thr:g}%." if len(t) else "")
        paras += [_line(r, word) for _, r in mv.head(max(3, n // 3)).iterrows()]
        if len(mv):
            tabs.append(mv.assign(level=name))
    paras += [f"Official all-India averages above +{thr:g}%: " + ("; ".join(
        f"{r.commodity} {r.market_type.lower()} {r.change_pct:+.1f}%" for r in _movers(off, True, n).itertuples()) or "none") + "."]
    add(f"Commodities rising more than {thr:g}% {word}-on-{word}", paras,
        _table(pd.concat(tabs), {"level": "Level", **TCOLS}) if tabs else None)
    # 4 concentration (monthly) / declines
    if kind == "monthly":
        p = A.state_pressure(md, "M") if len(md) else pd.DataFrame()
        add("State-wise and district-wise concentration of price pressure",
            ([f"{r.state}: pressure score {r.score:.0f}/100; {int(r.n_up)} of {int(r.n_series)} matched series above "
              f"+{thr:g}%, median change {r.median_change:+.1f}%, {int(r.n_markets)} markets." for r in p.head(n).itertuples()]
             + [f"{r.district}, {r.state}: {r.commodity} {r.change_pct:+.1f}% across {int(r.n_markets)} market(s)."
                for r in _movers(di, True, n // 2 + 1).itertuples()]
             + ["Score = priority-weighted share of a state's matched mandi series rising above the threshold."])
            if len(p) else ["No mandi-level data is available for both months, so geographic concentration cannot be assessed."],
            _table(p.head(2 * n), {"state": "State", "score": "Pressure score", "median_change": "Median change %",
                                   "n_series": "Series", "n_markets": "Markets", "n_up": "Rising", "n_down": "Falling"}))
        sus = md[md["confidence"] == "Check data"] if len(md) else md
        an = _movers(md, True, n)
        add("Major mandi-level anomalies", ([_line(r, word) for _, r in an.iterrows()] +
            [f"{len(sus)} mandi series changed by more than {A.SUSPECT_CHANGE:g}% and are excluded pending data verification."
             if len(sus) else "No mandi series breached the data-verification limit."])
            if len(md) else ["No mandi-level data is available for both months."],
            _table(pd.concat([an, sus.head(n)]), TCOLS) if len(md) else None)
    paras, tabs = [], []
    for name, t in ups:
        mv = _movers(t, False, n)
        paras += [_line(r, word) for _, r in mv.head(max(3, n // 3)).iterrows()]
        if len(mv):
            tabs.append(mv.assign(level=name))
    glut = sig[sig["pattern"].str.contains("oversupply", na=False)] if len(sig) else sig
    paras += [f"{r.commodity}: {r.pattern}." for r in glut.itertuples()]
    stress = sig[sig["pattern"].str.contains("supply stress", na=False)] if len(sig) else sig
    if kind == "monthly":
        paras += [f"{r.commodity}: {r.pattern}." for r in stress.itertuples()]
    add("Supply shortages, gluts and changes in arrivals" if kind == "monthly" else "Significant downward movements and potential gluts",
        paras or [f"No item-location fell by more than {thr:g}% in matched markets."],
        _table(pd.concat(tabs), {"level": "Level", **TCOLS}) if tabs else None)
    # news
    none = ["No items retrieved for the selected window. News feeds may be unavailable; see the Data Sources page."]
    add("National and regional news analysis" if kind == "monthly" else "Important regional and local reports",
        ([f"{len(local)} local/regional items retrieved; " + ", ".join(f"{k}: {v}" for k, v in
          local["themes"].str.split(", ").explode().replace("", pd.NA).dropna().value_counts().head(6).items()) + "."]
         + _news_lines(local[local["language"] != "English"], n // 2 + 1) + _news_lines(local[local["language"] == "English"], n))
        if len(local) else none)
    hoard = local[local["themes"].str.contains("Hoarding", na=False)] if len(local) else local
    if kind == "weekly":
        add("Hoarding-related reports and enforcement action",
            (["Items below are media reports or allegations unless marked as official statements."] + _news_lines(hoard, n))
            if len(hoard) else ["No hoarding or enforcement reports were retrieved in the window."])
    pol, intl = ctx.get("policy", pd.DataFrame()), ctx.get("intl", pd.DataFrame())
    add("Government policy reactions" if kind == "monthly" else "Government policy developments",
        [f"{r.title} - {r.publisher}, {r.published:%d %b %Y}. Status: {r.status}. Affected: {r.commodities or 'not identified'}. "
         f"Mechanism: {r.mechanism}. Likely implication: {r.implication}. Source: {r.link}"
         for r in pol.head(n).itertuples() if pd.notna(r.published)] if len(pol) else none)
    add("International developments relevant to India" if kind == "weekly" else "International developments",
        [f"{r.title} - {r.publisher}, {r.published:%d %b %Y}. Region: {r.region}; commodity: {r.commodity}. "
         f"India exposure: {r.exposure}. Transmission: {r.mechanism}. Direction: {r.direction}; horizon: {r.horizon}; "
         f"confidence: {r.confidence}. Source: {r.link}" for r in intl.head(n).itertuples() if pd.notna(r.published)]
        if len(intl) else none)
    # outlook
    watch = [f"{r.commodity}: monitor whether the {r.direction.lower()}ward move persists ({r.weeks_same_direction} week(s) so far) "
             f"and whether it spreads beyond {r.states_beyond_threshold} state(s)." for r in sig[sig["signal"] != "Normal"].head(n).itertuples()] if len(sig) else []
    add("Implications for the following month" if kind == "monthly" else "Emerging risks and indicators to monitor next week",
        watch + ["Indicators: mandi arrivals against the same week last month, the number of states crossing the alert "
                 "threshold, new stock-limit or trade-policy notifications, and landed prices of imported edible oils and pulses.",
                 "This report is generated by rules from stored data and retrieved headlines. It contains no forecasts; "
                 "where evidence is missing the section says so."])
    title = f"India Food Commodity {'Weekly' if kind == 'weekly' else 'Monthly'} Insights"
    f = ctx.get("filters", {})
    scope = "; ".join(f"{k}: {', '.join(v) if v else 'All'}" for k, v in f.items())
    return {"title": title, "subtitle": f"Generated {ctx.get('generated', pd.Timestamp.now()):%d %b %Y %H:%M}. Scope - {scope}",
            "sections": S}


def to_docx(rep: dict) -> bytes:
    from docx import Document
    from docx.shared import Pt
    doc = Document()
    doc.styles["Normal"].font.size = Pt(10)
    doc.add_heading(rep["title"], 0)
    doc.add_paragraph(rep["subtitle"])
    for i, s in enumerate(rep["sections"], 1):
        doc.add_heading(f"{i}. {s['title']}", 1)
        for p in s["paras"]:
            doc.add_paragraph(p)
        t = s["table"]
        if t is not None and len(t):
            t = t.head(40)
            tb = doc.add_table(rows=1, cols=len(t.columns))
            tb.style = "Light Grid Accent 1"
            for c, name in zip(tb.rows[0].cells, t.columns):
                c.text = str(name)
            for row in t.itertuples(index=False):
                for c, v in zip(tb.add_row().cells, row):
                    c.text = "" if pd.isna(v) else f"{v:,.2f}" if isinstance(v, float) else str(v)
            for row in tb.rows:
                for c in row.cells:
                    for p in c.paragraphs:
                        for r in p.runs:
                            r.font.size = Pt(7.5)
    buf = io.BytesIO(); doc.save(buf)
    return buf.getvalue()


def _pdf_font() -> str:
    """Use a Unicode font when available so regional-language headlines render; otherwise Helvetica."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    import glob
    for pat in ("/usr/share/fonts/**/NotoSans-Regular.ttf", "/usr/share/fonts/**/DejaVuSans.ttf", "C:/Windows/Fonts/Nirmala.ttf"):
        hit = glob.glob(pat, recursive=True)
        if hit:
            try:
                pdfmetrics.registerFont(TTFont("Body", hit[0]))
                return "Body"
            except Exception:
                continue
    return "Helvetica"


def to_pdf(rep: dict) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from xml.sax.saxutils import escape
    font = _pdf_font()
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["BodyText"], fontName=font, fontSize=9, leading=12.5, spaceAfter=4)
    h1 = ParagraphStyle("h", parent=ss["Heading2"], fontSize=12, spaceBefore=10, textColor=colors.HexColor("#1f3a5f"))
    cell = ParagraphStyle("c", parent=body, fontSize=7, leading=8.5, spaceAfter=0)
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm,
                            bottomMargin=14 * mm, title=rep["title"])
    el = [Paragraph(escape(rep["title"]), ss["Title"]), Paragraph(escape(rep["subtitle"]), body)]
    for i, s in enumerate(rep["sections"], 1):
        el.append(Paragraph(escape(f"{i}. {s['title']}"), h1))
        el += [Paragraph(escape(p), body) for p in s["paras"]]
        t = s["table"]
        if t is not None and len(t):
            t = t.head(40)
            data = [[Paragraph(escape(str(c)), cell) for c in t.columns]] + [
                [Paragraph(escape("" if pd.isna(v) else f"{v:,.2f}" if isinstance(v, float) else str(v)), cell) for v in row]
                for row in t.itertuples(index=False)]
            tb = Table(data, repeatRows=1, colWidths=[doc.width / len(t.columns)] * len(t.columns))
            tb.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfe7f1")),
                                    ("GRID", (0, 0), (-1, -1), 0.25, colors.grey), ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            el += [Spacer(1, 4), tb]
    doc.build(el)
    return buf.getvalue()


def to_xlsx(rep: dict, extra: dict[str, pd.DataFrame] | None = None) -> bytes:
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xw:
        rows = [{"Section": "", "Text": rep["title"]}, {"Section": "", "Text": rep["subtitle"]}]
        for i, s in enumerate(rep["sections"], 1):
            rows += [{"Section": f"{i}. {s['title']}", "Text": p} for p in s["paras"]]
        pd.DataFrame(rows).to_excel(xw, "Narrative", index=False)
        xw.sheets["Narrative"].set_column(0, 0, 45); xw.sheets["Narrative"].set_column(1, 1, 160)
        used = {"Narrative"}
        tables = [(f"{i}. {s['title']}", s["table"]) for i, s in enumerate(rep["sections"], 1)] + list((extra or {}).items())
        for name, t in tables:
            if t is None or not len(t):
                continue
            sheet = "".join(ch for ch in name if ch not in "[]:*?/\\")[:31]
            while sheet in used:
                sheet = sheet[:29] + "_2"
            used.add(sheet)
            t.to_excel(xw, sheet, index=False)
            xw.sheets[sheet].set_column(0, len(t.columns) - 1, 18)
    return buf.getvalue()


def news_digest(week: pd.DataFrame, points: pd.DataFrame, start, end, length: str = "Standard") -> dict:
    """Weekly news update for the India News Map: what was reported, where, and the source links."""
    n = LENGTH.get(length, 10)
    S = []
    add = lambda title, paras, table=None: S.append({"title": title, "paras": [p for p in paras if p], "table": table})
    count = lambda col: week[col].str.split(", ").explode().replace("", pd.NA).dropna().value_counts()
    title = "India Food Commodity News - Weekly Update"
    sub = f"Local and regional commodity news published {pd.Timestamp(start):%d %b %Y} to {pd.Timestamp(end):%d %b %Y}"
    if week.empty:
        add("Overview", ["No local commodity news was retrieved for this week. News feeds may have been unavailable, or no history "
                         "had been collected yet for these dates."])
        return {"title": title, "subtitle": sub, "sections": S}
    coms, states, themes = count("commodities"), count("states"), count("themes")
    placed = points["link"].nunique() if len(points) else 0
    add("Overview", [
        f"{len(week)} articles from {week['publisher'].nunique()} publishers in {week['language'].nunique()} language(s); "
        f"{placed} name a state or district and {len(week) - placed} do not.",
        "Most-covered commodities: " + (", ".join(f"{k} ({v})" for k, v in coms.head(6).items()) or "none identified") + ".",
        "States most mentioned: " + (", ".join(f"{k} ({v})" for k, v in states.head(6).items()) or "none identified") + ".",
        "Themes: " + (", ".join(f"{k} ({v})" for k, v in themes.head(6).items()) or "none identified") + ".",
        "Commodity, place and theme are assigned by keyword from the headline. Items are media reports unless marked as official "
        "statements; allegations are unverified."],
        coms.rename_axis("Commodity").reset_index(name="Articles"))
    if len(points):
        g = points.groupby(["state", "place", "precision"]).agg(
            Articles=("link", "nunique"),
            Commodities=("commodities", lambda v: ", ".join(sorted({x for t in v for x in t.split(", ") if x}))),
            Themes=("themes", lambda v: ", ".join(sorted({x for t in v for x in t.split(", ") if x})))).reset_index()
        g = g.sort_values("Articles", ascending=False).rename(columns={"state": "State", "place": "Place", "precision": "Level"})
        add("Where news was reported", [f"{r.Place} ({r.State}): {r.Articles} article(s) - {r.Commodities or 'commodity not identified'}; "
                                        f"{r.Themes or 'no theme identified'}." for r in g.head(n).itertuples()], g.head(40))
    by_day = week.assign(Day=week["published"].dt.strftime("%d %b %Y")).groupby("Day", sort=False).size().rename("Articles").reset_index()
    add("Articles per day", [", ".join(f"{r.Day}: {r.Articles}" for r in by_day.itertuples()) + "."], by_day)
    for com in list(coms.head(max(4, n // 2)).index):
        sub_df = week[week["commodities"].apply(lambda v: com in v.split(", "))].sort_values("published", ascending=False)
        add(f"{com}", _news_lines(sub_df, n))
    hoard = week[week["themes"].str.contains("Hoarding", na=False)]
    add("Hoarding and enforcement reports", (["Media reports or allegations unless marked as official statements."] + _news_lines(hoard, n))
        if len(hoard) else ["None retrieved this week."])
    glut = week[week["themes"].str.contains("Glut|Farmer distress", na=False)]
    add("Gluts, price falls and farmer distress", _news_lines(glut, n) if len(glut) else ["None retrieved this week."])
    other = week[week["commodities"] == ""]
    if len(other):
        add("Other items (commodity not identified)", _news_lines(other, n // 2 + 1))
    return {"title": title, "subtitle": sub, "sections": S}
