"""Optional durable save from the hosted app: commit changed data files back to the GitHub repository.

Streamlit Community Cloud's disk is temporary, so uploads made in the hosted app are lost on restart unless they are
committed. Set two secrets to enable this:  GITHUB_REPO = "owner/repo"  and  GITHUB_TOKEN = a fine-grained token with
'Contents: read and write' on that repository only. Without them the app still works; uploads last until restart.
"""
from __future__ import annotations
import base64
from pathlib import Path
import requests
from .config import ROOT

API = "https://api.github.com/repos/{repo}/contents/{path}"


def commit_file(path: Path, repo: str, token: str, branch: str = "main", message: str | None = None) -> str:
    """Create or update one file in the repo. Returns 'committed' or raises requests.HTTPError."""
    rel = Path(path).resolve().relative_to(ROOT).as_posix()
    url = API.format(repo=repo, path=rel)
    hdr = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
    cur = requests.get(url, headers=hdr, params={"ref": branch}, timeout=30)
    body = {"message": message or f"data: update {rel}", "branch": branch,
            "content": base64.b64encode(Path(path).read_bytes()).decode()}
    if cur.status_code == 200:
        body["sha"] = cur.json()["sha"]
    r = requests.put(url, headers=hdr, json=body, timeout=60)
    r.raise_for_status()
    return "committed"


def commit_many(paths: list[Path], repo: str, token: str, branch: str = "main") -> list[str]:
    out = []
    for p in paths:
        try:
            out.append(f"{Path(p).name}: {commit_file(p, repo, token, branch)}")
        except Exception as e:
            out.append(f"{Path(p).name}: FAILED {str(e)[:120]}")
    return out
