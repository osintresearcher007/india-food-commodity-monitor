"""Shared Streamlit helpers: cached data access, filters, map data, formatting."""
from __future__ import annotations
import json, os, re
import pandas as pd
import streamlit as st
from . import analytics as A, signals, store
from .config import DATA, GROUP_ORDER, USER_CONFIG, load_user_config
from .sources import news as N

PALETTE = {"Increase": "#c0392b", "Decrease": "#1f77b4", "Within": "#7f8c8d"}
SIGNAL_COLOR = {"Normal": "#6b7280", "Watch": "#b7791f", "Elevated": "#c05621", "Significant": "#b91c1c"}


def secret(name: str, default: str = "") -> str:
    try:
        if name in st.secrets:
            return str(st.secrets[name])
    except Exception:
        pass
    return os.environ.get(name, default)


def data_version() -> float:
    files = [store.NATIONAL, store.SAMPLE, USER_CONFIG]
    files += list(store.MANDI_DIR.glob("*.csv.gz")) if store.MANDI_DIR.exists() else []
    return sum(p.stat().st_mtime for p in files if p.exists())


@st.cache_data(show_spinner="Loading price data...")
def load_prices(version: float) -> pd.DataFrame:
    nat = store.load_national()
    nat = nat[nat["market_type"] == "Retail"]  # the dashboard shows retail prices only; wholesale all-India rows stay in storage
    df = pd.concat([nat, store.load_mandi()], ignore_index=True)
    df = store.quality_flags(store.add_taxonomy(df, load_user_config()))
    df["group"] = pd.Categorical(df["group"], [g for g in GROUP_ORDER if g in set(df["group"])] +
                                 sorted(set(df["group"]) - set(GROUP_ORDER)), ordered=True).astype(str)
    return df


def prices() -> pd.DataFrame:
    return load_prices(data_version())


@st.cache_data(show_spinner="Computing price changes...")
def runs(version: float, key: tuple, _df: pd.DataFrame, as_of=None, provisional: bool = False) -> tuple[dict, dict]:
    return A.run(_df, "W", as_of, provisional), A.run(_df, "M", as_of, provisional)


@st.cache_data
def places() -> dict:
    gj = json.loads((DATA / "geo" / "districts.geojson").read_text())
    d = {f["properties"]["district"]: f["properties"]["st_nm"] for f in gj["features"]}
    keys = sorted({f"{f['properties']['st_nm']}|{f['properties']['district']}" for f in gj["features"]})
    return {"states": sorted(set(d.values())), "districts": d, "district_keys": keys}


@st.cache_data
def geo(level: str) -> dict:
    gj = json.loads((DATA / "geo" / f"{level}.geojson").read_text())
    for f in gj["features"]:
        p = f["properties"]
        f["id"] = p["st_nm"] if level == "states" else f"{p['st_nm']}|{p['district']}"
    return gj


def _k(s: str) -> str:
    return re.sub(r"[^a-z]", "", str(s).lower())


def district_id(state: str, district: str) -> str | None:
    """Match a (state, district) pair from price data to the map's feature id; None when no boundary matches."""
    idx = {(_k(s), _k(d)): f"{s}|{d}" for d, s in places()["districts"].items()}
    return idx.get((_k(state), _k(district)))


@st.cache_data(ttl=3600, show_spinner="Fetching news feeds...")
def news(langs: tuple, days: int) -> tuple[pd.DataFrame, list[str], str]:
    """Live feeds, falling back to the last snapshot saved by the scheduled refresh (data/news.csv.gz)."""
    cfg = load_user_config()
    df, fails = N.collect(list(langs), days, places(), cfg.get("extra_feeds", []))
    origin = "Live RSS"
    snap = DATA / "news.csv.gz"
    if df.empty and snap.exists():
        df = pd.read_csv(snap, parse_dates=["published"]).fillna("")
        origin = f"Stored snapshot ({pd.Timestamp(snap.stat().st_mtime, unit='s'):%d %b %Y %H:%M} UTC)"
    elif df.empty:
        origin = "Unavailable"
    arch = DATA / "news_archive.csv.gz"
    if arch.exists():  # older days collected by the scheduled refresh, so the date slider can go back in time
        old = pd.read_csv(arch, parse_dates=["published"]).fillna("")
        df = N.dedupe(pd.concat([df, old], ignore_index=True)) if len(df) else old
    return df, fails, origin


def get_news(days: int = 10) -> tuple[pd.DataFrame, list[str], str]:
    langs = tuple(st.session_state.get("news_langs", list(N.LANG_NAMES)))
    return news(langs, days)


def sidebar_filters(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Global filters shown on every page. Returns (filtered frame, chosen values)."""
    sb = st.sidebar
    sb.markdown("### Filters")
    prios = sb.multiselect("Priority", ["High", "Medium", "Low"], default=["High", "Medium"], key="f_prio")
    d = df[df["priority"].isin(prios)] if prios else df
    groups = sb.multiselect("Commodity group", [g for g in GROUP_ORDER if g in set(d["group"])], key="f_group")
    if groups:
        d = d[d["group"].isin(groups)]
    coms = sb.multiselect("Commodity", sorted(d["commodity"].unique()), key="f_com")
    if coms:
        d = d[d["commodity"].isin(coms)]
    mtypes = []
    states = sb.multiselect("State", sorted(s for s in d["state"].unique() if s and s != "All India"), key="f_state")
    if states:
        d = d[d["state"].isin(states) | (d["level"] == "national")]
    srcs = sb.multiselect("Data source", sorted(d["source"].unique()), key="f_src")
    if srcs:
        d = d[d["source"].isin(srcs)]
    prov = sb.toggle("Include current incomplete week/month (provisional)", value=False, key="f_prov")
    return d, {"Priority": prios, "Groups": groups, "Commodities": coms, "Market type": mtypes, "States": states,
               "Sources": srcs, "provisional": prov}


def compute(d: pd.DataFrame, f: dict, as_of=None) -> tuple[dict, dict]:
    key = tuple((k, tuple(v) if isinstance(v, list) else v) for k, v in f.items())
    return runs(data_version(), key, d, as_of, f.get("provisional", False))


def get_signals(d, w, m, nw) -> pd.DataFrame:
    return signals.compute(d, w, m, nw)


def sample_banner(df: pd.DataFrame) -> bool:
    if df["is_sample"].any():
        st.warning("State, district and mandi views are showing **SAMPLE DATA (illustrative, not real prices)** because no "
                   "real mandi-level data is loaded yet. All-India figures are real DoCA data. Load mandi data on the "
                   "*Data Sources & Uploads* page to replace the sample.", icon="⚠️")
        return True
    man = df[df["level"] != "national"]
    load = st.session_state.get("agmarknet_load", {})
    if load.get("status") == "running":
        st.warning("**AGMARKNET mandi prices are being downloaded now** (a few hundred requests, usually one to three minutes). "
                   "Until they arrive, the state and district views show egg prices only. Reload the page in a couple of minutes.", icon="⏳")
    elif load.get("status") == "failed":
        st.error(f"AGMARKNET mandi prices could not be downloaded: {load.get('detail')}. The state and district views show egg "
                 "prices only. You can retry from the Data Sources & Uploads page.", icon="⚠️")
    elif len(man) and set(man["commodity"]) == {"Eggs"}:
        st.info("All-India figures are **retail** prices. State, district and centre views so far cover **eggs only** (NECC centre "
                "prices, Rs per 100 eggs).", icon="ℹ️")
    elif len(man):
        st.info("All-India figures are **retail** prices (Department of Consumer Affairs). State, district and mandi views are "
                "**wholesale mandi** prices: AGMARKNET monthly averages in Rs per quintal, and NECC egg prices in Rs per 100 eggs. "
                "The two are shown in separate sections and never combined.", icon="ℹ️")
    return False


def period_caption(run: dict, which: str = "official") -> str:
    p = run.get(f"{which}_periods")
    if not p:
        return "no data"
    s = f"{p['cur']:%d %b}–{p['cur_end']:%d %b %Y} vs {p['prev']:%d %b}–{p['prev_end']:%d %b %Y}"
    return s + (" · PROVISIONAL" if p["provisional"] else "")


def download(df: pd.DataFrame, name: str, label: str = "Download CSV") -> None:
    st.download_button(label, df.to_csv(index=False).encode("utf-8-sig"), file_name=name, mime="text/csv", key=f"dl_{name}")


def pct_cols(cols: list[str]) -> dict:
    return {c: st.column_config.NumberColumn(c, format="%+.2f%%") for c in cols}


def style_changes(df: pd.DataFrame, cols: list[str], thr: dict | None = None):
    """Colour change columns: red above +threshold, blue below -threshold."""
    thr = thr or {}

    def colour(v, t):
        if pd.isna(v):
            return ""
        return f"color: {PALETTE['Increase']}; font-weight:600" if v > t else f"color: {PALETTE['Decrease']}; font-weight:600" if v < -t else ""
    sty = df.style
    for c in cols:
        if c in df.columns:
            t = thr.get(c, A.WEEKLY_THRESHOLD if "eek" in c or "WoW" in c else A.MONTHLY_THRESHOLD)
            sty = sty.map(lambda v, t=t: colour(v, t), subset=[c])
    num = {c: "{:,.2f}" for c in df.columns if df[c].dtype.kind == "f"}
    return sty.format(num, na_rep="–")


def news_cards(df: pd.DataFrame, limit: int = 30, extra: list[str] | None = None) -> None:
    for r in df.head(limit).to_dict("records"):
        when = f"{r['published']:%d %b %Y}" if pd.notna(r["published"]) else "date n/a"
        dn = ", ".join(k.split("|")[-1] for k in str(r.get("districts") or "").split(", ") if k)
        tags = " · ".join(x for x in [r.get("commodities"), r.get("states"), dn, r.get("themes")] if x)
        with st.container(border=True):
            st.markdown(f"**[{r['title']}]({r['link']})**")
            st.caption(f"{r['publisher']} · {when} · {r['language']} · *{r['evidence']}*" + (f" · {tags}" if tags else ""))
            if r.get("summary"):
                st.write(r["summary"])
            for c in extra or []:
                if r.get(c):
                    st.markdown(f"<small><b>{c.replace('_', ' ').title()}:</b> {r[c]}</small>", unsafe_allow_html=True)


@st.cache_data
def _view(level: str, state: str | None = None) -> tuple[dict, float]:
    """Centre and zoom that fit the chosen boundaries (no base-map tiles are used, so the map works offline)."""
    import math
    pts = []

    def walk(c):
        if isinstance(c[0], (int, float)):
            pts.append(c)
        else:
            for x in c:
                walk(x)
    for ft in geo(level)["features"]:
        if state is None or ft["properties"]["st_nm"] == state:
            walk(ft["geometry"]["coordinates"])
    lon, lat = [p[0] for p in pts], [p[1] for p in pts]
    span = max(max(lon) - min(lon), (max(lat) - min(lat)) * 1.15, 0.5)
    return {"lon": (max(lon) + min(lon)) / 2, "lat": (max(lat) + min(lat)) / 2}, span


def choropleth(data: pd.DataFrame, level: str, locations: str, color: str, state: str | None = None, height: int = 520,
               fit_px: int = 430, **kw):
    """Tile-free choropleth of India (states) or one state's districts. Areas without data are drawn in light grey."""
    import plotly.express as px
    gj = geo(level)
    if state is not None:
        gj = {"type": "FeatureCollection", "features": [f for f in gj["features"] if f["properties"]["st_nm"] == state]}
    import math
    centre, span = _view(level, state)
    zoom = math.log2(360 * min(fit_px, height) / (512 * span)) + 0.2  # fit the boundaries in the plot area
    fig = px.choropleth_map(data, geojson=gj, locations=locations, color=color, map_style="white-bg", center=centre,
                            zoom=zoom, **kw)
    fig.update_traces(marker_line_width=0.5, marker_line_color="#8a94a0")
    fig.update_layout(margin=dict(l=0, r=0, t=0, b=0), height=height,
                      map_layers=[{"sourcetype": "geojson", "source": gj, "type": "line", "below": "traces",
                                   "color": "#9aa3ad", "line": {"width": 0.7}}])
    return fig


@st.cache_data
def centroids() -> dict:
    """Approximate centre (lon, lat) of every state and district boundary, keyed 'State' or 'State|District'."""
    out = {}
    for level in ("states", "districts"):
        for ft in geo(level)["features"]:
            pts = []

            def walk(c):
                if isinstance(c[0], (int, float)):
                    pts.append(c)
                else:
                    for x in c:
                        walk(x)
            g = ft["geometry"]["coordinates"]
            # use the largest polygon so islands do not pull the centre into the sea
            polys = g if ft["geometry"]["type"] == "MultiPolygon" else [g]
            walk(max(polys, key=lambda p: len(p[0]))[0])
            out[ft["id"]] = (sum(p[0] for p in pts) / len(pts), sum(p[1] for p in pts) / len(pts))
    return out


def news_points(nw: pd.DataFrame, language_fallback: bool = False) -> pd.DataFrame:
    """One row per (article, place). District pointer when a district is named, otherwise the state's centre.

    With language_fallback, a regional-language article that names no place is put at the centre of that language's
    home state and marked 'Language region (approximate)'."""
    from .sources.news import LANGUAGE_HOME
    cen = centroids()
    rows = []
    for r in nw.to_dict("records"):
        spots = []
        for key in [k for k in r["districts"].split(", ") if k]:
            if "|" not in key:  # older stored snapshots hold bare district names
                key = f"{places()['districts'].get(key, '')}|{key}"
            spots.append((key, key.split("|", 1)[1], key.split("|", 1)[0], "District"))
        named = {s[2] for s in spots}
        spots += [(s, s, s, "State") for s in r["states"].split(", ") if s and s not in named]
        if not spots and language_fallback and r.get("language") in LANGUAGE_HOME:
            home = LANGUAGE_HOME[r["language"]]
            spots = [(home, home, home, "Language region (approximate)")]
        for key, place, state, precision in spots:
            if key in cen:
                rows.append({**r, "place": place, "state": state, "precision": precision, "lon": cen[key][0], "lat": cen[key][1]})
    return pd.DataFrame(rows)


CSS = """<style>
.stApp{background:#f4f6f9}
.block-container{padding-top:2.2rem;max-width:1400px}
h1{font-size:1.65rem!important} h2{font-size:1.2rem!important} h3{font-size:1.05rem!important;margin-bottom:.2rem}
[class*="st-key-card_"]{background:#fff;border:1px solid #e3e8ef!important;border-radius:12px;padding:1.1rem 1.25rem 1.2rem;
  box-shadow:0 2px 10px rgba(22,34,51,.08);margin-bottom:1.1rem}
[data-testid="stMetric"]{background:#fff;border:1px solid #e3e8ef;border-radius:10px;padding:.7rem .9rem;box-shadow:0 1px 6px rgba(22,34,51,.07)}
[data-testid="stMetricValue"]{font-size:1.45rem}
[data-testid="stMetricLabel"] p{white-space:normal;line-height:1.2}
.fci-wrap{overflow:auto;border:1px solid #e3e8ef;border-radius:8px;margin:.2rem 0 .6rem}
.fci-wrap table{border-collapse:collapse;width:100%;font-size:.86rem}
.fci-wrap th{position:sticky;top:0;background:#eaf0f7;color:#1f3a5f;text-align:left;padding:.5rem .6rem;white-space:normal;
  vertical-align:bottom;line-height:1.2;border-bottom:1px solid #cfd8e3;z-index:1}
.fci-wrap td{padding:.45rem .6rem;border-bottom:1px solid #eef1f5;vertical-align:top;white-space:normal;word-break:normal;
  overflow-wrap:break-word;line-height:1.35}
.fci-wrap td.num,.fci-wrap th.num{text-align:right;white-space:nowrap;overflow-wrap:normal}
.fci-wrap tr:nth-child(even) td{background:#fafbfd}
.fci-wrap td.wide{min-width:240px}
.fci-up{color:#c0392b;font-weight:600} .fci-down{color:#1f77b4;font-weight:600}
.fci-note{color:#6b7480;font-size:.8rem;margin:-.3rem 0 .5rem}
</style>"""


def card(title: str | None = None, key: str | None = None):
    """A white box with a soft shadow that groups one section of a page."""
    slug = re.sub(r"[^a-z0-9]+", "_", (key or title or "box").lower()).strip("_")[:40]
    n = st.session_state.get("_card_n", 0) + 1
    st.session_state["_card_n"] = n
    box = st.container(border=True, key=f"card_{slug}_{n}")
    if title:
        box.subheader(title)
    return box


def _pretty(name) -> str:
    n = str(name)
    known = {"price_cur": "Current price", "price_prev": "Previous price", "n_markets": "Markets", "n_series": "Series",
             "n_up": "Rising", "n_down": "Falling", "change_pct": "Change %", "max_change": "Largest change %",
             "arrivals_change_pct": "Arrivals change %", "score": "Pressure score"}
    if n in known:
        return known[n]
    return n if (" " in n or n[:1].isupper()) else n.replace("_pct", " %").replace("_", " ").capitalize()


def show(data, height: int | None = 420, thr: float | None = None, max_rows: int = 300, **_ignored) -> None:
    """Readable table: wrapped text, sticky header, right-aligned numbers, coloured change columns, clickable links.

    Accepts a DataFrame or a pandas Styler (its data is used). Extra st.dataframe keyword arguments are ignored.
    """
    import html as _h
    df = data.data if hasattr(data, "data") and not isinstance(data, pd.DataFrame) else data
    if df is None or not len(df):
        st.caption("No rows to show.")
        return
    total = len(df)
    df = df.head(max_rows)
    head, kinds = [], []
    for c in df.columns:
        col = df[c]
        kind = "num" if col.dtype.kind in "fiu" else "date" if col.dtype.kind == "M" else "text"
        if kind == "text" and col.astype(str).str.startswith("http").mean() > 0.5:
            kind = "link"
        kinds.append(kind)
        head.append(f'<th class="{"num" if kind == "num" else ""}">{_h.escape(_pretty(c))}</th>')
    rows = []
    for rec in df.itertuples(index=False):
        cells = []
        for c, kind, v in zip(df.columns, kinds, rec):
            name = str(c).lower()
            if v is None or (not isinstance(v, (list, tuple)) and pd.isna(v)):
                cells.append(f'<td class="{"num" if kind == "num" else ""}">–</td>')
            elif kind == "num":
                is_change = "%" in name or "change" in name or name.endswith("_pct")
                t = thr if thr is not None else (10.0 if ("mom" in name or "month" in name or "yoy" in name) else 5.0)
                cls = ("fci-up" if v > t else "fci-down" if v < -t else "") if is_change and "arrival" not in name else ""
                txt = f"{v:+,.2f}" if is_change else (f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}")
                cells.append(f'<td class="num {cls}">{txt}</td>')
            elif kind == "date":
                cells.append(f"<td>{pd.Timestamp(v):%d %b %Y}</td>")
            elif kind == "link":
                cells.append(f'<td><a href="{_h.escape(str(v), quote=True)}" target="_blank" rel="noopener">open</a></td>')
            else:
                txt = str(v)
                cells.append(f'<td class="{"wide" if len(txt) > 60 else ""}">{_h.escape(txt)}</td>')
        rows.append("<tr>" + "".join(cells) + "</tr>")
    style = f"max-height:{height}px" if height else ""
    st.markdown(f'<div class="fci-wrap" style="{style}"><table><thead><tr>{"".join(head)}</tr></thead><tbody>{"".join(rows)}</tbody></table></div>',
                unsafe_allow_html=True)
    if total > max_rows:
        st.markdown(f'<div class="fci-note">Showing the first {max_rows} of {total:,} rows. Use the download button for all rows.</div>', unsafe_allow_html=True)
