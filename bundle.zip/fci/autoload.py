"""Load AGMARKNET monthly mandi prices in the background the first time the app starts without them.

The hosted app's disk is temporary, so after a restart the data may be missing until the daily job has committed it to
the repository. One attempt is made per app process; the outcome is written to the refresh log and shown on screen.
"""
from __future__ import annotations
import threading
from . import store
from .sources import agmarknet

_lock = threading.Lock()
STATE = {"status": "idle", "detail": ""}  # idle | running | done | failed


def _have(year: int, month: int) -> bool:
    m = store.load_mandi(include_sample=False)
    if m.empty:
        return False
    return bool(((m["source"] == agmarknet.SOURCE) & (m["date"].dt.strftime("%Y-%m") == f"{year}-{month:02d}")).any())


def _work(year: int, month: int) -> None:
    try:
        df = agmarknet.fetch_month(year, month, log=lambda msg: None)
        r = store.save_mandi(df)
        fails = df.attrs.get("failed_requests", 0)
        store.log_refresh(f"{agmarknet.SOURCE} {year}-{month:02d}", "OK", f"automatic load; {fails} failed requests", r["rows_added"])
        STATE.update(status="done", detail=f"{r['rows_added']:,} rows")
    except Exception as e:
        store.log_refresh(f"{agmarknet.SOURCE} {year}-{month:02d}", "FAILED", f"{type(e).__name__}: {e}")
        STATE.update(status="failed", detail=f"{type(e).__name__}: {str(e)[:160]}")


def start_if_needed() -> dict:
    """Start the background load once per process when the last complete month is not stored. Returns the state."""
    with _lock:
        if STATE["status"] == "idle":
            y, m = agmarknet.last_complete_month()
            if _have(y, m):
                STATE.update(status="done", detail="already stored")
            else:
                STATE.update(status="running", detail=f"{y}-{m:02d}")
                threading.Thread(target=_work, args=(y, m), daemon=True, name="agmarknet-autoload").start()
    return dict(STATE)
