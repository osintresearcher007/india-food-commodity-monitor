"""Keep AGMARKNET monthly mandi prices loaded.

sync_month() fetches whatever commodity/state combinations of a month are not stored yet, saving after each commodity,
and repeats after a cool-down when the site refuses requests. The app runs it in a background thread on start (the
hosted disk is temporary until the daily job has committed the data); the daily job calls it directly.
"""
from __future__ import annotations
import threading
import time
from . import store
from .sources import agmarknet

_lock = threading.Lock()
STATE = {"status": "idle", "detail": ""}  # idle | running | done | partial | failed


def stored(year: int, month: int) -> set:
    """(commodity, state) pairs already stored for that month from AGMARKNET."""
    m = store.load_mandi(include_sample=False)
    if m.empty:
        return set()
    m = m[(m["source"] == agmarknet.SOURCE) & (m["date"].dt.strftime("%Y-%m") == f"{year}-{month:02d}")]
    return set(zip(m["commodity"], m["state"]))


def sync_month(year: int, month: int, rounds: int = 4, cooldown: float = 120, state: dict | None = None) -> dict:
    """Returns {'rows', 'failed', 'rounds', 'complete'} and writes one line to the refresh log."""
    rows = failed = done_rounds = 0
    complete = False
    label = f"{agmarknet.SOURCE} {year}-{month:02d}"
    try:
        for i in range(rounds):
            done_rounds = i + 1
            have = stored(year, month)
            if state is not None:
                state.update(status="running", detail=f"{len(have)} commodity/state combinations loaded so far")
            df = agmarknet.fetch_month(year, month, skip=have, on_batch=store.save_mandi, log=lambda msg: None)
            rows += len(df)
            failed = df.attrs.get("failed_requests", 0)
            if not failed and not df.attrs.get("stopped_early"):
                complete = True
                break
            if i < rounds - 1:
                time.sleep(cooldown)
        n = len(stored(year, month))
        store.log_refresh(label, "OK" if complete else "PARTIAL" if n else "FAILED",
                          f"{n} commodity/state combinations stored; {failed} requests still failing after {done_rounds} round(s)", rows)
    except Exception as e:
        n = len(stored(year, month))
        store.log_refresh(label, "PARTIAL" if n else "FAILED", f"{type(e).__name__}: {e}", rows)
        if state is not None:
            state.update(status="partial" if n else "failed", detail=f"{type(e).__name__}: {str(e)[:160]}")
        return {"rows": rows, "failed": failed, "rounds": done_rounds, "complete": False}
    if state is not None:
        state.update(status="done" if complete else "partial" if n else "failed",
                     detail=f"{n} commodity/state combinations loaded" + ("" if complete else f"; {failed} requests were refused by the site"))
    return {"rows": rows, "failed": failed, "rounds": done_rounds, "complete": complete}


REFRESH_HOURS = 6
QUICK = {"last": 0.0, "running": False, "all_india": "", "eggs": "", "news": ""}


def refresh_quick() -> None:
    """All-India daily prices, egg prices and the news snapshot (about half a minute in total)."""
    import json
    import pandas as pd
    from .config import DATA
    from .sources import doca, necc, news
    for key, label, fetch, save in (("all_india", doca.SOURCE, doca.fetch, store.save_national),
                                    ("eggs", necc.SOURCE, necc.fetch, store.save_mandi)):
        try:
            got = fetch()
            r = save(got)
            store.log_refresh(label, "OK" if len(got) else "EMPTY", f"automatic; latest {got['date'].max():%d %b %Y}" if len(got) else "no rows", r["rows_added"])
            QUICK[key] = f"OK, latest {got['date'].max():%d %b %Y}" if len(got) else "no rows returned"
        except Exception as e:
            store.log_refresh(label, "FAILED", f"{type(e).__name__}: {e}")
            QUICK[key] = f"failed: {type(e).__name__} {str(e)[:120]}"
    try:
        gj = json.loads((DATA / "geo" / "districts.geojson").read_text())
        keys = sorted({f"{f['properties']['st_nm']}|{f['properties']['district']}" for f in gj["features"]})
        places = {"states": sorted({k.split("|")[0] for k in keys}), "districts": {}, "district_keys": keys}
        df, fails = news.collect(days=14, places=places)
        if len(df):
            df.to_csv(DATA / "news.csv.gz", index=False)
            arch = DATA / "news_archive.csv.gz"
            if arch.exists():
                df = news.dedupe(pd.concat([df, pd.read_csv(arch, parse_dates=["published"]).fillna("")], ignore_index=True))
            df[df["published"].isna() | (df["published"] >= pd.Timestamp.now() - pd.Timedelta(days=400))].to_csv(arch, index=False)
        store.log_refresh("News feeds", "OK" if len(df) else "EMPTY", f"{len(fails)} feed failures", len(df))
        QUICK["news"] = f"{len(df)} items, {len(fails)} feeds failed"
    except Exception as e:
        store.log_refresh("News feeds", "FAILED", f"{type(e).__name__}: {e}")
        QUICK["news"] = f"failed: {type(e).__name__} {str(e)[:120]}"


def _cycle(with_mandi: bool) -> None:
    try:
        refresh_quick()
    finally:
        QUICK["running"] = False
    if with_mandi:
        y, m = agmarknet.last_complete_month()
        sync_month(y, m, state=STATE)


def start_if_needed(force: str | None = None) -> dict:
    """Start background refreshes: everything on first use, the quick sources again every REFRESH_HOURS.
    force = 'quick' or 'mandi' restarts that part on request. Returns the mandi-load state."""
    with _lock:
        due = time.time() - QUICK["last"] > REFRESH_HOURS * 3600
        mandi = STATE["status"] == "idle" or (force == "mandi" and STATE["status"] != "running")
        if (due or force == "quick" or mandi) and not QUICK["running"]:
            QUICK.update(last=time.time(), running=True)
            if mandi:
                y, m = agmarknet.last_complete_month()
                STATE.update(status="running", detail=f"{len(stored(y, m))} commodity/state combinations loaded so far")
            threading.Thread(target=_cycle, args=(mandi,), daemon=True, name="fci-refresh").start()
    return dict(STATE)
