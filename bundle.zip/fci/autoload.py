"""Keep AGMARKNET monthly mandi prices loaded.

sync_month() fetches whatever commodity/state combinations of a month are not stored yet, saving after each commodity,
and repeats after a cool-down when the site refuses requests. The app runs it in a background thread on start (the
hosted disk is temporary until the daily job has committed the data); the daily job calls it directly.
"""
from __future__ import annotations
import threading
import time
from . import store
from .sources import agmarknet

_lock = threading.Lock()
STATE = {"status": "idle", "detail": ""}  # idle | running | done | partial | failed


def stored(year: int, month: int) -> set:
    """(commodity, state) pairs already stored for that month from AGMARKNET."""
    m = store.load_mandi(include_sample=False)
    if m.empty:
        return set()
    m = m[(m["source"] == agmarknet.SOURCE) & (m["date"].dt.strftime("%Y-%m") == f"{year}-{month:02d}")]
    return set(zip(m["commodity"], m["state"]))


def sync_month(year: int, month: int, rounds: int = 4, cooldown: float = 120, state: dict | None = None) -> dict:
    """Returns {'rows', 'failed', 'rounds', 'complete'} and writes one line to the refresh log."""
    rows = failed = done_rounds = 0
    complete = False
    label = f"{agmarknet.SOURCE} {year}-{month:02d}"
    try:
        for i in range(rounds):
            done_rounds = i + 1
            have = stored(year, month)
            if state is not None:
                state.update(status="running", detail=f"{len(have)} commodity/state combinations loaded so far")
            df = agmarknet.fetch_month(year, month, skip=have, on_batch=store.save_mandi, log=lambda msg: None)
            rows += len(df)
            failed = df.attrs.get("failed_requests", 0)
            if not failed and not df.attrs.get("stopped_early"):
                complete = True
                break
            if i < rounds - 1:
                time.sleep(cooldown)
        n = len(stored(year, month))
        store.log_refresh(label, "OK" if complete else "PARTIAL" if n else "FAILED",
                          f"{n} commodity/state combinations stored; {failed} requests still failing after {done_rounds} round(s)", rows)
    except Exception as e:
        n = len(stored(year, month))
        store.log_refresh(label, "PARTIAL" if n else "FAILED", f"{type(e).__name__}: {e}", rows)
        if state is not None:
            state.update(status="partial" if n else "failed", detail=f"{type(e).__name__}: {str(e)[:160]}")
        return {"rows": rows, "failed": failed, "rounds": done_rounds, "complete": False}
    if state is not None:
        state.update(status="done" if complete else "partial" if n else "failed",
                     detail=f"{n} commodity/state combinations loaded" + ("" if complete else f"; {failed} requests were refused by the site"))
    return {"rows": rows, "failed": failed, "rounds": done_rounds, "complete": complete}


def start_if_needed() -> dict:
    """Start the background sync once per app process. Returns the current state."""
    with _lock:
        if STATE["status"] == "idle":
            y, m = agmarknet.last_complete_month()
            STATE.update(status="running", detail=f"{len(stored(y, m))} commodity/state combinations loaded so far")
            threading.Thread(target=sync_month, args=(y, m), kwargs={"state": STATE}, daemon=True, name="agmarknet-autoload").start()
    return dict(STATE)
