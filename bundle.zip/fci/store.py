"""File-based price store.

Durable storage is the Git repository itself: data/*.csv.gz files are committed (by you or by the scheduled
GitHub Action in .github/workflows/refresh.yml) and Streamlit Community Cloud redeploys from the repo.
Nothing here depends on the app server's local disk surviving a restart.
"""
from __future__ import annotations
import datetime as dt
import pandas as pd
from .config import DATA, SCHEMA, USER_CONFIG, classify_commodity, load_user_config, norm_place, norm_state, fix_text

NATIONAL = DATA / "doca_national.csv.gz"
MANDI_DIR = DATA / "mandi"
SAMPLE = DATA / "sample_mandi.csv.gz"
LOG = DATA / "refresh_log.csv"
KEYS = ["date", "state", "district", "market", "commodity", "variety", "grade", "market_type", "source"]


def _read(path) -> pd.DataFrame:
    df = pd.read_csv(path, dtype={"district": str, "market": str, "variety": str, "grade": str}, keep_default_na=True)
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in ["district", "market", "variety", "grade"]:
        df[c] = df[c].fillna("")
    return df


def standardise(df: pd.DataFrame) -> pd.DataFrame:
    """Coerce a frame to SCHEMA with cleaned text, numeric prices and normalised geography."""
    df = df.copy()
    for c in SCHEMA:
        if c not in df.columns:
            df[c] = False if c == "is_sample" else pd.NA
    df["date"] = pd.to_datetime(df["date"], errors="coerce").dt.normalize()
    for c in ["min_price", "max_price", "modal_price", "arrivals"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["state"] = df["state"].fillna("").map(norm_state)
    df["district"] = df["district"].fillna("").map(norm_place)
    df["market"] = df["market"].fillna("").map(lambda s: fix_text(s).title())
    for c in ["commodity", "variety", "grade", "unit", "source", "market_type", "level"]:
        df[c] = df[c].fillna("").map(fix_text)
    df["is_sample"] = df["is_sample"].fillna(False).astype(bool)
    return df.dropna(subset=["date"])[SCHEMA]


def dedupe(df: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Drop duplicate observations (same market, commodity, variety, date, source); the last one loaded wins."""
    n = len(df)
    df = df.drop_duplicates(subset=KEYS, keep="last")
    return df, n - len(df)


def quality_flags(df: pd.DataFrame) -> pd.DataFrame:
    """Add a 'quality' column: OK, or the reason an observation is excluded from alert calculations."""
    df = df.copy()
    q = pd.Series("OK", index=df.index)
    q[df["modal_price"].isna() | (df["modal_price"] <= 0)] = "Missing or non-positive price"
    bad = df["min_price"].notna() & df["max_price"].notna() & (df["min_price"] > df["max_price"])
    q[bad] = "Min above max"
    key = ["commodity", "market_type", "unit"]
    med = df[q == "OK"].groupby(key)["modal_price"].median().rename("_med")
    df = df.join(med, on=key)
    ratio = df["modal_price"] / df["_med"]
    q[(q == "OK") & ((ratio > 8) | (ratio < 0.125))] = "Implausible vs commodity median (possible unit/entry error)"
    df["quality"] = q
    return df.drop(columns="_med")


def add_taxonomy(df: pd.DataFrame, cfg: dict | None = None) -> pd.DataFrame:
    cfg = cfg if cfg is not None else load_user_config()
    df = df.copy()
    df["raw_commodity"] = df["commodity"]
    uniq = {c: classify_commodity(c, cfg) for c in df["commodity"].dropna().unique()}
    df["commodity"] = df["raw_commodity"].map(lambda c: uniq[c][0])
    df["group"] = df["raw_commodity"].map(lambda c: uniq[c][1])
    df["priority"] = df["raw_commodity"].map(lambda c: uniq[c][2])
    return df[~df["commodity"].isin(cfg.get("exclude", []))]


def load_national() -> pd.DataFrame:
    return _read(NATIONAL) if NATIONAL.exists() else pd.DataFrame(columns=SCHEMA)


def load_mandi(include_sample: bool = True) -> pd.DataFrame:
    parts = [_read(p) for p in sorted(MANDI_DIR.glob("*.csv.gz"))] if MANDI_DIR.exists() else []
    real = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=SCHEMA)
    if real.empty and include_sample and SAMPLE.exists():
        return _read(SAMPLE)
    return real


def save_national(new: pd.DataFrame) -> dict:
    cur = load_national()
    merged, dup = dedupe(pd.concat([cur, standardise(new)], ignore_index=True))
    merged = merged.sort_values(["date", "market_type", "commodity"])
    NATIONAL.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(NATIONAL, index=False)
    return {"rows_in": len(new), "rows_added": len(merged) - len(cur), "duplicates": dup, "total": len(merged)}


def save_mandi(new: pd.DataFrame) -> dict:
    """Merge new mandi rows into monthly partition files data/mandi/YYYY-MM.csv.gz."""
    new = standardise(new)
    new = new[~new["is_sample"]]
    MANDI_DIR.mkdir(parents=True, exist_ok=True)
    added = dup = 0
    for ym, part in new.groupby(new["date"].dt.strftime("%Y-%m")):
        path = MANDI_DIR / f"{ym}.csv.gz"
        cur = _read(path) if path.exists() else pd.DataFrame(columns=SCHEMA)
        merged, d = dedupe(pd.concat([cur, part], ignore_index=True))
        merged.sort_values(["date", "state", "district", "market", "commodity"]).to_csv(path, index=False)
        added += len(merged) - len(cur)
        dup += d
    return {"rows_in": len(new), "rows_added": added, "duplicates": dup}


def log_refresh(source: str, status: str, detail: str = "", rows: int = 0) -> None:
    row = pd.DataFrame([{"time_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
                         "source": source, "status": status, "rows": rows, "detail": str(detail)[:300]}])
    LOG.parent.mkdir(parents=True, exist_ok=True)
    row.to_csv(LOG, mode="a", header=not LOG.exists(), index=False)


def read_log() -> pd.DataFrame:
    if not LOG.exists():
        return pd.DataFrame(columns=["time_utc", "source", "status", "rows", "detail"])
    return pd.read_csv(LOG).iloc[::-1].reset_index(drop=True)


def missing_dates(df: pd.DataFrame) -> list:
    if df.empty:
        return []
    have = set(df["date"].dt.normalize().unique())
    full = pd.date_range(df["date"].min(), df["date"].max(), freq="D")
    return [d for d in full if d not in have]
